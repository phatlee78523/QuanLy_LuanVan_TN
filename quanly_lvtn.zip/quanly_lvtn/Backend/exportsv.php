<?php
session_start();
if (!isset($_SESSION["dangnhap"]) || $_SESSION["dangnhap"] !== true) {
    die("Bạn chưa đăng nhập.");
}
require 'db.php'; 
require '../vendor/autoload.php'; 

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Alignment;


$startRow = 9;

try {
    $spreadsheet = IOFactory::load($templatePath);
    $sheet = $spreadsheet->getActiveSheet();
    $sql = "
        SELECT 
            dt.tenDeTai, 
            gv.tenGV, 
            dt.diemGiuaKy, 
            dt.trangThaiGiuaKy, 
            dt.nhanXetGiuaKy,
            (SELECT GROUP_CONCAT(sv.hoTen SEPARATOR '\n')
             FROM SinhVien sv 
             WHERE sv.maDeTai = dt.maDeTai) AS thanhVien,
            (SELECT GROUP_CONCAT(sv.mssv SEPARATOR '\n') 
             FROM SinhVien sv 
             WHERE sv.maDeTai = dt.maDeTai) AS mssv_list,
            (SELECT GROUP_CONCAT(sv.lop SEPARATOR '\n') 
             FROM SinhVien sv 
             WHERE sv.maDeTai = dt.maDeTai) AS lop_list
        FROM DeTai dt
        LEFT JOIN GiangVien gv ON dt.maGV_HD = gv.maGV
        WHERE dt.maGV_HD IS NOT NULL
        ORDER BY dt.maDeTai ASC;
    ";
    $stmt = $pdo->query($sql);
    $theses = $stmt->fetchAll();
    $row = $startRow;
    $nhomCounter = 1;
    
    foreach ($theses as $thesis) {
        $sheet->setCellValue('A' . $row, $nhomCounter);
        $sheet->setCellValue('B' . $row, $thesis['mssv_list']);
        $sheet->setCellValue('C' . $row, $thesis['thanhVien']);
        $sheet->setCellValue('E' . $row, $thesis['lop_list']);
        
        $sheet->setCellValue('F' . $row, $thesis['tenDeTai']);
        
        $sheet->setCellValue('G' . $row, $thesis['tenGV']);
        $diemGK = $thesis['diemGiuaKy'];
        if (isset($diemGK) && $diemGK !== '') {
            $sheet->setCellValue('H' . $row, $diemGK . '%');
        } else {
            $sheet->setCellValue('H' . $row, ''); 
        }
        $sheet->setCellValue('I' . $row, $thesis['trangThaiGiuaKy']);
        $sheet->setCellValue('L' . $row, $thesis['nhanXetGiuaKy']);
        $sheet->getStyle('B' . $row)->getAlignment()->setWrapText(true); 
        $sheet->getStyle('C' . $row)->getAlignment()->setWrapText(true); 
        $sheet->getStyle('E' . $row)->getAlignment()->setWrapText(true); 
        
        $row++;
        $nhomCounter++;
    }

    $writer = new Xlsx($spreadsheet);
    $filename = 'danh-sach-danh-gia-GK.xlsx';

    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment;filename="'. $filename .'"');
    header('Cache-Control: max-age=0');

    $writer->save('php://output');
    exit;

} catch (Exception $e) {
    die("Lỗi: " . $e->getMessage() . ". Hãy chắc chắn rằng file '" . $templatePath . "' tồn tại.");
}
?>