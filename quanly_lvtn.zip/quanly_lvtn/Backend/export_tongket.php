<?php
session_start();
if (!isset($_SESSION["dangnhap"]) || $_SESSION["dangnhap"] !== true) { exit; }

require 'db.php';
require '../vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;

$type = $_GET['type'] ?? 'single';
$maHoiDong = $_GET['maHoiDong'] ?? 0;

try {
    $sql = "
        SELECT 
            dt.maMH AS Nhom,
            dt.tenDeTai,
            H.tenHoiDong,
            (SELECT GROUP_CONCAT(sv.mssv SEPARATOR '\n') FROM SinhVien sv WHERE sv.maDeTai = dt.maDeTai) AS MSSV,
            (SELECT GROUP_CONCAT(sv.hoTen SEPARATOR '\n') FROM SinhVien sv WHERE sv.maDeTai = dt.maDeTai) AS SinhVien,
            gv1.tenGV AS GVHD,
            gv2.tenGV AS GVPB,
            dt.diemHuongDan,
            dt.diemPhanBien,
            dt.diemHoiDong,
            dt.diemTongKet,
            dt.diemChu
        FROM DeTai dt
        LEFT JOIN HoiDong H ON dt.maHoiDong = H.maHoiDong
        LEFT JOIN GiangVien gv1 ON dt.maGV_HD = gv1.maGV
        LEFT JOIN GiangVien gv2 ON dt.maGV_PB = gv2.maGV
        WHERE dt.maHoiDong IS NOT NULL
    ";

    if ($type == 'single') {
        $sql .= " AND dt.maHoiDong = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$maHoiDong]);
        $filename = "Ket_Qua_Hoi_Dong_$maHoiDong.xlsx";
    } else {
        $sql .= " ORDER BY H.tenHoiDong ASC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $filename = "Tong_Ket_Khoa_Luan.xlsx";
    }

    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();

    $headers = [
        'A' => 'Hội đồng', 'B' => 'Nhóm', 'C' => 'Tên Đề tài', 
        'D' => 'MSSV', 'E' => 'Họ Tên', 'F' => 'GVHD', 'G' => 'GVPB',
        'H' => 'Điểm GVHD (20%)', 'I' => 'Điểm GVPB (20%)', 
        'J' => 'Điểm HĐ (60%)', 'K' => 'TỔNG KẾT', 'L' => 'Điểm Chữ'
    ];

    foreach ($headers as $col => $text) {
        $sheet->setCellValue($col . '1', $text);
        $sheet->getColumnDimension($col)->setAutoSize(true);
    }
    $sheet->getStyle('A1:L1')->getFont()->setBold(true);
    $sheet->getStyle('A1:L1')->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('FF10B981'); // Màu xanh
    $sheet->getStyle('A1:L1')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

    $row = 2;
    foreach ($data as $item) {
        $sheet->setCellValue('A' . $row, $item['tenHoiDong']);
        $sheet->setCellValue('B' . $row, $item['Nhom']);
        $sheet->setCellValue('C' . $row, $item['tenDeTai']);
        $sheet->setCellValue('D' . $row, $item['MSSV']);
        $sheet->setCellValue('E' . $row, $item['SinhVien']);
        $sheet->setCellValue('F' . $row, $item['GVHD']);
        $sheet->setCellValue('G' . $row, $item['GVPB']);
        $sheet->setCellValue('H' . $row, $item['diemHuongDan']);
        $sheet->setCellValue('I' . $row, $item['diemPhanBien']);
        $sheet->setCellValue('J' . $row, $item['diemHoiDong']);
        $sheet->setCellValue('K' . $row, $item['diemTongKet']);
        $sheet->setCellValue('L' . $row, $item['diemChu']);

        $sheet->getStyle('C' . $row)->getAlignment()->setWrapText(true);
        $sheet->getStyle('D' . $row)->getAlignment()->setWrapText(true);
        $sheet->getStyle('E' . $row)->getAlignment()->setWrapText(true);

        $sheet->getStyle('H' . $row . ':L' . $row)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

        $row++;
    }
    $lastRow = $row - 1;
    $sheet->getStyle('A1:L' . $lastRow)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN);
    $sheet->getStyle('A1:L' . $lastRow)->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);

    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment;filename="' . $filename . '"');
    header('Cache-Control: max-age=0');
    $writer = new Xlsx($spreadsheet);
    $writer->save('php://output');
    exit;

} catch (Exception $e) {
    die("Lỗi Xuất Excel: " . $e->getMessage());
}
?>