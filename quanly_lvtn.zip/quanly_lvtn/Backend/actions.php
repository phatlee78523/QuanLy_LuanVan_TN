<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require '../vendor/autoload.php';
require 'db.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

if (!isset($_SESSION["dangnhap"]) || $_SESSION["dangnhap"] !== true) {
    header("location: ../frontend/dangnhap.html");
    exit;
}

$action = $_POST['action'] ?? '';

// 1. QUẢN LÝ TIẾN ĐỘ / GIAI ĐOẠN
if ($action == 'update_stage') {
    try {
        $nextStage = isset($_POST['next_stage']) ? $_POST['next_stage'] : 1;
        if (isset($_POST['reset_stage'])) $nextStage = 1;

        $stmt = $pdo->prepare("UPDATE CauHinh SET giaiDoan = ? WHERE id = 1");
        $stmt->execute([$nextStage]);
        
        header("Location: ../frontend/index.php");
        exit;
    } catch (PDOException $e) {
        die("Lỗi cập nhật giai đoạn: " . $e->getMessage());
    }
}

// 2. QUẢN LÝ ĐỀ TÀI & PHÂN CÔNG GVHD

elseif ($action == 'add_detai') {
    try {
        $pdo->beginTransaction();
        
        $sql_detai = "INSERT INTO DeTai (tenDeTai, maMH, tenMonHoc, maGV_HD) VALUES (?, ?, ?, ?)";
        $stmt_detai = $pdo->prepare($sql_detai);
        $stmt_detai->execute([
            $_POST['tenDeTai'],
            $_POST['maMH'],
            $_POST['tenMonHoc'],
            $_POST['maGV_HD']
        ]);
        
        $maDeTai = $pdo->lastInsertId();

        if (!empty($_POST['mssv_list'])) {
            $mssv_list = $_POST['mssv_list'];
            $sql_sv = "UPDATE SinhVien SET maDeTai = ? WHERE mssv = ?";
            $stmt_sv = $pdo->prepare($sql_sv);
            
            foreach ($mssv_list as $mssv) {
                $stmt_sv->execute([$maDeTai, $mssv]);
            }
        }
        
        $pdo->commit();
        header('Location: ../frontend/phancong.php?status=group_added');
    } catch (Exception $e) {
        $pdo->rollBack();
        die("Lỗi thêm đề tài: " . $e->getMessage());
    }
    exit;
}

elseif ($action == 'create_group_assign') { 
    try {
        $student1 = $_POST['student_1'];
        $student2 = $_POST['student_2'];
        $maMH = $_POST['maMH'];
        $maGV_HD = $_POST['maGV_HD'];
        $tenDeTai = "Chưa cập nhật tên đề tài"; 
        $maGV_PB = NULL; 

        $pdo->beginTransaction();

        $sqlDeTai = "INSERT INTO DeTai (tenDeTai, maMH, maGV_HD, maGV_PB, trangThaiGiuaKy) VALUES (?, ?, ?, ?, 'Được làm tiếp')";
        $stmtDeTai = $pdo->prepare($sqlDeTai);
        $stmtDeTai->execute([$tenDeTai, $maMH, $maGV_HD, $maGV_PB]);
        
        $newMaDeTai = $pdo->lastInsertId();

        $sqlSV = "UPDATE SinhVien SET maDeTai = ? WHERE mssv = ?";
        $stmtSV = $pdo->prepare($sqlSV);
        
        $stmtSV->execute([$newMaDeTai, $student1]);
        if (!empty($student2) && $student1 != $student2) {
            $stmtSV->execute([$newMaDeTai, $student2]);
        }

        $pdo->commit();
        echo "<script>alert('Tạo nhóm thành công!'); window.location.href='../frontend/phanconggv.php';</script>";

    } catch (PDOException $e) {
        $pdo->rollBack();
        die("Lỗi tạo nhóm: " . $e->getMessage());
    }
}

elseif ($action == 'delete_detai') {
    try {
        $pdo->prepare("UPDATE SinhVien SET maDeTai = NULL WHERE maDeTai = ?")->execute([$_POST['maDeTai']]);
        $pdo->prepare("DELETE FROM DeTai WHERE maDeTai = ?")->execute([$_POST['maDeTai']]);
        header('Location: ../frontend/phancong.php?status=group_deleted');
    } catch (PDOException $e) {
        die("Lỗi xóa đề tài: " . $e->getMessage());
    }
    exit;
}

elseif ($action == 'delete_all_detai') {
    try {
        $pdo->beginTransaction();
        $pdo->exec("UPDATE SinhVien SET maDeTai = NULL");
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");
        $pdo->exec("TRUNCATE TABLE DeTai");
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");    
        $pdo->commit();
        header('Location: ../frontend/phancong.php?status=all_cleared');
    } catch (Exception $e) {
        $pdo->rollBack();
        die("Lỗi xóa tất cả: " . $e->getMessage());
    }
    exit;
}

elseif ($action == 'update_topic_name_gv') { 
    try {
        $maDeTai = $_POST['maDeTai'];
        $tenDeTai = $_POST['tenDeTai'];
        $nhom = $_POST['nhom']; 
        $redirect = $_POST['redirect_url'] ?? '../frontend/ds_sinhvien_gv.php';
        $tenMonHoc_Default = 'Đồ án / Khóa luận tốt nghiệp';

        $sql = "UPDATE DeTai SET tenDeTai = ?, maMH = ?, tenMonHoc = ? WHERE maDeTai = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$tenDeTai, $nhom, $tenMonHoc_Default, $maDeTai]);
        
        echo "<script>alert('Cập nhật thành công!'); window.location.href='$redirect';</script>";
        exit;
    } catch (PDOException $e) {
        die("Lỗi cập nhật: " . $e->getMessage());
    }
}

elseif ($action == 'assign_gv') { 
    try {
        $maDeTai = $_POST['maDeTai'];
        $maGV = $_POST['maGV'];
        $role = $_POST['role_assign'];

        $col = ($role == 'HD') ? 'maGV_HD' : 'maGV_PB';
        $sql = "UPDATE DeTai SET $col = ? WHERE maDeTai = ?";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$maGV, $maDeTai]);
        
        echo "<script>alert('Phân công thành công!'); window.location.href='../frontend/phanconggv.php?loai=$role';</script>";
    } catch (PDOException $e) {
        die("Lỗi phân công: " . $e->getMessage());
    }
}

// 3. QUẢN LÝ CHẤM ĐIỂM GIỮA KỲ 
elseif ($action == 'toggle_midterm') { 
    try {
        $trangThaiHienTai = $_POST['trangThaiHienTai'];
        $trangThaiMoi = ($trangThaiHienTai == 1) ? 0 : 1; 

        $pdo->prepare("UPDATE CauHinh SET trangThaiChamGK = ? WHERE id = 1")->execute([$trangThaiMoi]);
        $msg = ($trangThaiMoi == 1) ? "Đã MỞ hệ thống chấm điểm GK!" : "Đã ĐÓNG hệ thống chấm điểm GK!";
        echo "<script>alert('$msg'); window.location.href='../frontend/trangthaigk.php';</script>";
    } catch (PDOException $e) {
        die("Lỗi cấu hình: " . $e->getMessage());
    }
    exit;
}

elseif ($action == 'update_midterm') {
    try {
        $trangThaiHeThong = $pdo->query("SELECT trangThaiChamGK FROM CauHinh WHERE id = 1")->fetchColumn();
        
        if ($trangThaiHeThong == 0) {
            echo "<script>alert('Hệ thống chấm điểm ĐANG ĐÓNG!'); window.history.back();</script>";
            exit;
        }

        $trangThai = $_POST['trangThaiGiuaKy']; 

        $sql = "UPDATE DeTai SET diemGiuaKy = ?, trangThaiGiuaKy = ?, nhanXetGiuaKy = ? WHERE maDeTai = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            $_POST['diemGiuaKy'],
            $trangThai,           
            $_POST['nhanXetGiuaKy'] ?? '',
            $_POST['maDeTai']
        ]);
        
        $redirect = $_POST['redirect_url'] ?? '../frontend/ds_sinhvien_gv.php';
        header('Location: ' . $redirect . '?status=success');
    } catch (PDOException $e) {
        die("Lỗi CSDL: ". $e->getMessage());
    }
    exit;
}

// 4. QUẢN LÝ PHẢN BIỆN

elseif ($action == 'assign_reviewer') { // Gán GVPB
    try {
        $sql = "UPDATE DeTai SET maGV_PB = ?, ghiChu_PB = ? WHERE maDeTai = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            $_POST['maGV_PB'],
            $_POST['ghiChu_PB'] ?? null,
            $_POST['maDeTai']
        ]);
        header('Location: ../frontend/phancong_pb.php?status=reviewer_assigned');
    } catch (PDOException $e) {
        die("Lỗi gán PB: ". $e->getMessage());
    }
    exit;
}

elseif ($action == 'update_score_pb') { 
    try {
        $maDeTai = $_POST['maDeTai'];
        $diem = $_POST['diemPhanBien'];
        $nhanxet = $_POST['nhanXetPhanBien'];

        $sql = "UPDATE DeTai SET diemPhanBien = ?, nhanXetPhanBien = ? WHERE maDeTai = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$diem, $nhanxet, $maDeTai]);

        echo "<script>alert('Đánh giá phản biện thành công!'); window.location.href='../frontend/ds_phanbien.php';</script>";
    } catch (PDOException $e) {
        die("Lỗi chấm PB: " . $e->getMessage());
    }
    exit;
}

// 5. QUẢN LÝ HỘI ĐỒNG & CHẤM ĐIỂM CUỐI KỲ

elseif ($action == 'add_hoidong') {
    try {
        $tenHoiDong = $_POST['tenHoiDong'];
        $diaDiem = $_POST['diaDiem'];
        
        $members = [$_POST['chuTich'], $_POST['thuKy1'], $_POST['uyVien']];
        if (!empty($_POST['thuKy2'])) $members[] = $_POST['thuKy2'];

        if (count($members) !== count(array_unique($members))) {
            echo "<script>alert('Lỗi: Một giảng viên không thể giữ nhiều vai trò trong cùng một hội đồng!'); window.history.back();</script>";
            exit;
        }

        $pdo->beginTransaction();

        $stmt = $pdo->prepare("INSERT INTO HoiDong (tenHoiDong, diaDiem) VALUES (?, ?)");
        $stmt->execute([$tenHoiDong, $diaDiem]);
        $maHoiDong = $pdo->lastInsertId();

        $stmtMember = $pdo->prepare("INSERT INTO ThanhVienHoiDong (maHoiDong, maGV, vaiTro) VALUES (?, ?, ?)");
        $stmtMember->execute([$maHoiDong, $_POST['chuTich'], 'ChuTich']);
        $stmtMember->execute([$maHoiDong, $_POST['thuKy1'], 'ThuKy']);
        if (!empty($_POST['thuKy2'])) $stmtMember->execute([$maHoiDong, $_POST['thuKy2'], 'ThuKy']);
        $stmtMember->execute([$maHoiDong, $_POST['uyVien'], 'UyVien']);

        $pdo->commit();
        header("Location: ../frontend/hoidong.php");
    } catch (PDOException $e) {
        $pdo->rollBack();
        die("Lỗi tạo Hội đồng: " . $e->getMessage());
    }
    exit;
}

elseif ($action == 'update_hoidong') {
    try {
        $maHoiDong = $_POST['maHoiDong'];
        $tenHoiDong = $_POST['tenHoiDong'];
        $diaDiem = $_POST['diaDiem'];
        
        $members = [$_POST['chuTich'], $_POST['thuKy1'], $_POST['uyVien']];
        if (!empty($_POST['thuKy2'])) $members[] = $_POST['thuKy2'];

        if (count($members) !== count(array_unique($members))) {
            echo "<script>alert('Lỗi: Một giảng viên không thể giữ nhiều vai trò trong cùng một hội đồng!'); window.history.back();</script>";
            exit;
        }

        $pdo->beginTransaction();

        $stmt = $pdo->prepare("UPDATE HoiDong SET tenHoiDong = ?, diaDiem = ? WHERE maHoiDong = ?");
        $stmt->execute([$tenHoiDong, $diaDiem, $maHoiDong]);

        $pdo->prepare("DELETE FROM ThanhVienHoiDong WHERE maHoiDong = ?")->execute([$maHoiDong]);

        $stmtMember = $pdo->prepare("INSERT INTO ThanhVienHoiDong (maHoiDong, maGV, vaiTro) VALUES (?, ?, ?)");
        $stmtMember->execute([$maHoiDong, $_POST['chuTich'], 'ChuTich']);
        $stmtMember->execute([$maHoiDong, $_POST['thuKy1'], 'ThuKy']);
        if (!empty($_POST['thuKy2'])) $stmtMember->execute([$maHoiDong, $_POST['thuKy2'], 'ThuKy']);
        $stmtMember->execute([$maHoiDong, $_POST['uyVien'], 'UyVien']);

        $pdo->commit();
        header("Location: ../frontend/hoidong.php");
    } catch (PDOException $e) {
        $pdo->rollBack();
        die("Lỗi cập nhật Hội đồng: " . $e->getMessage());
    }
    exit;
}

elseif ($action == 'delete_hoidong') {
    try {
        $maHoiDong = $_POST['maHoiDong'];
        $pdo->prepare("UPDATE DeTai SET maHoiDong = NULL WHERE maHoiDong = ?")->execute([$maHoiDong]);
        $pdo->prepare("DELETE FROM ThanhVienHoiDong WHERE maHoiDong = ?")->execute([$maHoiDong]);
        $pdo->prepare("DELETE FROM HoiDong WHERE maHoiDong = ?")->execute([$maHoiDong]);
        
        header("Location: ../frontend/hoidong.php");
    } catch (PDOException $e) {
        die("Lỗi xóa Hội đồng: " . $e->getMessage());
    }
    exit;
}

elseif ($action == 'assign_detai_to_hoidong') { 
    try {
        $maDeTai = $_POST['maDeTai'];
        $maHoiDong = $_POST['maHoiDong'];

        if (empty($maHoiDong)) die("Lỗi: Chưa chọn Hội đồng.");

        $stmtCheck = $pdo->prepare("SELECT trangThaiGiuaKy, tenDeTai FROM DeTai WHERE maDeTai = ?");
        $listDeTai = is_array($maDeTai) ? $maDeTai : [$maDeTai];

        foreach ($listDeTai as $id) {
            $stmtCheck->execute([$id]);
            $dt = $stmtCheck->fetch();
            
            if ($dt && $dt['trangThaiGiuaKy'] == 'Đình chỉ') {
                echo "<script>alert('LỖI: Đề tài \"{$dt['tenDeTai']}\" bị ĐÌNH CHỈ, không thể bảo vệ!'); window.history.back();</script>";
                exit;
            }
            $pdo->prepare("UPDATE DeTai SET maHoiDong = ? WHERE maDeTai = ?")->execute([$maHoiDong, $id]);
        }

        header("Location: ../frontend/hoidong.php");
    } catch (PDOException $e) {
        die("Lỗi gán đề tài: " . $e->getMessage());
    }
    exit;
}

if ($action == 'update_council_score') {
    try {
        $scores = $_POST['scores'] ?? [];
        $redirectHD = $_POST['maHoiDong'] ?? '';

        if (empty($scores)) {
            echo "<script>alert('Không có dữ liệu điểm để lưu!'); window.history.back();</script>";
            exit;
        }

        $pdo->beginTransaction();
        $stmtGet = $pdo->prepare("SELECT diemHuongDan, diemPhanBien FROM DeTai WHERE maDeTai = ?");
        
        $stmtUpdate = $pdo->prepare("UPDATE DeTai SET diemHoiDong = ?, nhanXetHoiDong = ?, diemTongKet = ?, diemChu = ? WHERE maDeTai = ?");

        foreach ($scores as $maDeTai => $data) {
            $diemHoiDong = ($data['diem'] !== '') ? floatval($data['diem']) : 0;
            $nhanXet = $data['nx'] ?? '';

            $stmtGet->execute([$maDeTai]);
            $current = $stmtGet->fetch();
            
            $diemHD = ($current['diemHuongDan'] !== null) ? floatval($current['diemHuongDan']) : 0;
            $diemPB = ($current['diemPhanBien'] !== null) ? floatval($current['diemPhanBien']) : 0;

            $tongKet = ($diemHD * 0.2) + ($diemPB * 0.2) + ($diemHoiDong * 0.6);
            $tongKet = round($tongKet, 1);

            $diemChu = 'F';
            if ($tongKet >= 9.0) $diemChu = 'A+';
            elseif ($tongKet >= 8.5) $diemChu = 'A';
            elseif ($tongKet >= 8.0) $diemChu = 'B+';
            elseif ($tongKet >= 7.0) $diemChu = 'B';
            elseif ($tongKet >= 6.5) $diemChu = 'C+';
            elseif ($tongKet >= 5.5) $diemChu = 'C';
            elseif ($tongKet >= 5.0) $diemChu = 'D+';
            elseif ($tongKet >= 4.0) $diemChu = 'D';

            $stmtUpdate->execute([$diemHoiDong, $nhanXet, $tongKet, $diemChu, $maDeTai]);
        }

        $pdo->commit();
        
        header("Location: ../frontend/chamdiem_hoidong.php?hd=$redirectHD");
        exit;

    } catch (PDOException $e) {
        $pdo->rollBack();
        die("Lỗi SQL (Hội đồng): " . $e->getMessage());
    }
}


if ($action == 'save_score_gvhd') {
    try {
        $maDeTai = $_POST['maDeTai'];


        $maxPT = floatval($_POST['maxPhanTich']);
        $maxTK = floatval($_POST['maxThietKe']);
        $maxHT = floatval($_POST['maxHienThuc']);
        $maxBC = floatval($_POST['maxBaoCao']);
        $totalMax = $maxPT + $maxTK + $maxHT + $maxBC;
        if ($totalMax == 0) $totalMax = 10;

        $s1 = floatval($_POST['diemPhanTich1']) + floatval($_POST['diemThietKe1']) + floatval($_POST['diemHienThuc1']) + floatval($_POST['diemBaoCao1']);
        $final1 = ($s1 / $totalMax) * 10;

        $s2 = floatval($_POST['diemPhanTich2']) + floatval($_POST['diemThietKe2']) + floatval($_POST['diemHienThuc2']) + floatval($_POST['diemBaoCao2']);
        
        $diemTongKetHD = $final1;
        if ($s2 > 0) {
            $final2 = ($s2 / $totalMax) * 10;
            $diemTongKetHD = ($final1 + $final2) / 2;
        }

        $stmt = $pdo->prepare("UPDATE DeTai SET diemHuongDan = ? WHERE maDeTai = ?");
        $stmt->execute([$diemTongKetHD, $maDeTai]);

        header('Location: ../frontend/chamdiem.php?status=success');
        exit;

    } catch (PDOException $e) {
        die("Lỗi lưu điểm GVHD: " . $e->getMessage());
    }
}

elseif ($action == 'save_score_gvpb') {
    try {
        $maDeTai = $_POST['maDeTai'];

        $maxPT = floatval($_POST['maxPhanTich']);
        $maxTK = floatval($_POST['maxThietKe']);
        $maxHT = floatval($_POST['maxHienThuc']);
        $maxBC = floatval($_POST['maxBaoCao']);
        $totalMax = $maxPT + $maxTK + $maxHT + $maxBC;
        if ($totalMax == 0) $totalMax = 10;

        $s1 = floatval($_POST['diemPhanTich1_PB']) + floatval($_POST['diemThietKe1_PB']) + floatval($_POST['diemHienThuc1_PB']) + floatval($_POST['diemBaoCao1_PB']);
        $final1 = ($s1 / $totalMax) * 10;

        $s2 = floatval($_POST['diemPhanTich2_PB']) + floatval($_POST['diemThietKe2_PB']) + floatval($_POST['diemHienThuc2_PB']) + floatval($_POST['diemBaoCao2_PB']);

        $diemTongKetPB = $final1;
        if ($s2 > 0) {
            $final2 = ($s2 / $totalMax) * 10;
            $diemTongKetPB = ($final1 + $final2) / 2;
        }

        $stmt = $pdo->prepare("UPDATE DeTai SET diemPhanBien = ? WHERE maDeTai = ?");
        $stmt->execute([$diemTongKetPB, $maDeTai]);

        header('Location: ../frontend/chamdiem_pb.php?status=success');
        exit;

    } catch (PDOException $e) {
        die("Lỗi lưu điểm GVPB: " . $e->getMessage());
    }
}


// 6. QUẢN lý SINH VIÊN (CRUD & IMPORT)

elseif ($action == 'add_sinhvien') {
    try {
        $sql = "INSERT INTO SinhVien (mssv, hoTen, lop, soDienThoai, email) VALUES (?, ?, ?, ?, ?)";
        $pdo->prepare($sql)->execute([
            $_POST['mssv'], $_POST['hoTen'], $_POST['lop'],
            $_POST['soDienThoai'] ?? null, $_POST['email'] ?? null
        ]);
        header('Location: ../frontend/sinhvien.php?status=added');
    } catch (PDOException $e) {
        die("Lỗi thêm SV: " . $e->getMessage());
    }
    exit;
}

elseif ($action == 'update_sinhvien') {
     try {
        $sql = "UPDATE SinhVien SET mssv=?, hoTen=?, lop=?, soDienThoai=?, email=? WHERE mssv=?";
        $pdo->prepare($sql)->execute([
            $_POST['mssv_edit'], $_POST['hoTen_edit'], $_POST['lop_edit'],
            $_POST['soDienThoai_edit'] ?? null, $_POST['email_edit'] ?? null,
            $_POST['mssv_original']
        ]);
        header('Location: ../frontend/sinhvien.php?status=updated');
    } catch (PDOException $e) {
        die("Lỗi sửa SV: " . $e->getMessage());
    }
    exit;
}

elseif ($action == 'delete_sinhvien') {
    try {
        $pdo->prepare("DELETE FROM SinhVien WHERE mssv = ?")->execute([$_POST['mssv']]);
        header('Location: ../frontend/sinhvien.php?status=deleted');
    } catch (PDOException $e) {
        die("Lỗi xóa SV: " . $e->getMessage());
    }
    exit;
}

elseif ($action == 'delete_all_sinhvien') {
    try {
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");
        $pdo->exec("TRUNCATE TABLE SinhVien");
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
        header('Location: ../frontend/sinhvien.php?status=all_deleted');
    } catch (PDOException $e) {
        die("Lỗi xóa tất cả SV: " . $e->getMessage());
    }
    exit;
}

elseif ($action == 'import_sinhvien') {
    try {
        if (isset($_FILES['excel_file']) && $_FILES['excel_file']['error'] == 0) {
            $file = $_FILES['excel_file']['tmp_name'];
            $spreadsheet = IOFactory::load($file);
            $sheet = $spreadsheet->getActiveSheet();
            $highestRow = $sheet->getHighestDataRow();
            
            $stmtFind = $pdo->prepare("SELECT maDeTai FROM DeTai WHERE maMH = ? AND tenDeTai = ?");
            $stmtSv = $pdo->prepare("INSERT INTO SinhVien (mssv, hoTen, lop, soDienThoai, email, maDeTai) 
                       VALUES (?, ?, ?, ?, ?, ?)
                       ON DUPLICATE KEY UPDATE hoTen = VALUES(hoTen), lop = VALUES(lop), 
                       soDienThoai = VALUES(soDienThoai), email = VALUES(email), maDeTai = VALUES(maDeTai)");
            
            $pdo->beginTransaction(); 

            for ($row = 2; $row <= $highestRow; $row++) {
                $mssv = $sheet->getCell('B' . $row)->getValue();
                if (empty($mssv) || $mssv == 'MASV' || strpos($mssv, 'Dữ liệu') !== false) continue; 

                $ho = $sheet->getCell('C' . $row)->getValue();
                $ten = $sheet->getCell('D' . $row)->getValue();
                $hoTen = trim($ho . ' ' . $ten);
                $lop = $sheet->getCell('E' . $row)->getValue();
                
                $maMH_excel = $sheet->getCell('F' . $row)->getValue();
                $tenDeTai_excel = $sheet->getCell('G' . $row)->getValue();
                $soDienThoai = $sheet->getCell('H' . $row)->getValue();
                $email = $sheet->getCell('I' . $row)->getValue();

                $maDeTai_final = null; 
                if (!empty($maMH_excel) && !empty($tenDeTai_excel)) {
                    $stmtFind->execute([$maMH_excel, $tenDeTai_excel]);
                    $found = $stmtFind->fetchColumn();
                    if ($found) $maDeTai_final = $found;
                }
                
                $stmtSv->execute([$mssv, $hoTen, $lop, $soDienThoai, $email, $maDeTai_final]);
            }
            
            $pdo->commit(); 
            header('Location: ../frontend/sinhvien.php?status=import_success');
        } else {
            header('Location: ../frontend/sinhvien.php?status=import_failed');
        }
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack(); 
        die("Lỗi Import: ". $e->getMessage());
    }
    exit;
}

// 7. QUẢN LÝ GIẢNG VIÊN (CRUD)

elseif ($action == 'add_giangvien') {
    try {
        $sql = "INSERT INTO GiangVien (maGV, tenGV, email, soDienThoai, hocVi, matKhau) VALUES (?, ?, ?, ?, ?, ?)";
        $pdo->prepare($sql)->execute([
            $_POST['maGV'], $_POST['tenGV'], $_POST['email'], 
            $_POST['soDienThoai'], $_POST['hocVi'], $_POST['matKhau']
        ]);
        header("location: ../frontend/giangvien.php?status=added");
    } catch (PDOException $e) {
        die("Lỗi thêm GV: " . $e->getMessage());
    }
    exit;
}

elseif ($action == 'update_giangvien') {
    try {
        $sql = "UPDATE GiangVien SET maGV=?, tenGV=?, email=?, soDienThoai=?, hocVi=? WHERE maGV=?";
        $params = [
            $_POST['maGV'], $_POST['tenGV'], $_POST['email'], 
            $_POST['soDienThoai'], $_POST['hocVi'], $_POST['maGV_original']
        ];

        if (!empty($_POST['matKhau_new'])) {
            $sql = "UPDATE GiangVien SET maGV=?, tenGV=?, email=?, soDienThoai=?, hocVi=?, matKhau=? WHERE maGV=?";
            $params = [
                $_POST['maGV'], $_POST['tenGV'], $_POST['email'], 
                $_POST['soDienThoai'], $_POST['hocVi'], $_POST['matKhau_new'],
                $_POST['maGV_original']
            ];
        }
        
        $pdo->prepare($sql)->execute($params);
        header("location: ../frontend/giangvien.php?status=updated");
    } catch (PDOException $e) {
        die("Lỗi sửa GV: " . $e->getMessage());
    }
    exit;
}

elseif ($action == 'delete_giangvien') {
    try {
        $pdo->prepare("DELETE FROM GiangVien WHERE maGV = ?")->execute([$_POST['maGV']]);
        header("location: ../frontend/giangvien.php?status=deleted");
    } catch (PDOException $e) {
        die("Lỗi xóa GV: " . $e->getMessage());
    }
    exit;
}

elseif ($action == 'change_password') {
    try {
        $vaiTro = $_SESSION['role'];
        $table = ($vaiTro == 'admin') ? 'Admin' : 'GiangVien';
        $colUser = ($vaiTro == 'admin') ? 'username' : 'maGV';
        $colPass = ($vaiTro == 'admin') ? 'password' : 'matKhau';
        $user = ($vaiTro == 'admin') ? $_SESSION['username'] : $_SESSION['maGV'];

        $old = trim($_POST['old_pass']);
        $new = trim($_POST['new_pass']);
        $confirm = trim($_POST['confirm_pass']);

        if ($new !== $confirm) {
            header('Location: ../frontend/hoso.php?msg=error');
            exit;
        }

        $stmt = $pdo->prepare("SELECT $colPass FROM $table WHERE $colUser = ?");
        $stmt->execute([$user]);
        $row = $stmt->fetch();

        if ($row && $row[$colPass] == $old) {
            $pdo->prepare("UPDATE $table SET $colPass = ? WHERE $colUser = ?")->execute([$new, $user]);
            header('Location: ../frontend/hoso.php?msg=success');
        } else {
            header('Location: ../frontend/hoso.php?msg=error');
        }
    } catch (PDOException $e) {
        die("Lỗi đổi mật khẩu: " . $e->getMessage());
    }
    exit;
}
?>