<?php
session_start();
require 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    if ($username === 'admin' && $password === '123') {
        $_SESSION['dangnhap'] = true;
        $_SESSION['username'] = 'Admin';
        $_SESSION['role'] = 'admin';
        
        header('Location: ../frontend/index.php');
        exit;
    } 
    else {
        $stmt = $pdo->prepare("SELECT * FROM GiangVien WHERE maGV = ?");
        $stmt->execute([$username]);
        $gv = $stmt->fetch();
        if ($gv && $password === $gv['matKhau']) {
            $_SESSION['dangnhap'] = true;
            $_SESSION['username'] = $gv['tenGV'];
            $_SESSION['maGV'] = $gv['maGV'];
            $_SESSION['role'] = 'giangvien';      
            
            header('Location: ../frontend/index.php');
            exit;
        }
    }
    header('Location: ../frontend/dangnhap.html?error=1');
    exit;
}

header('Location: ../frontend/dangnhap.html');
exit;
?>