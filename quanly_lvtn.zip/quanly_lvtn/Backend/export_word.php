<?php
session_start();
require '../vendor/autoload.php'; 
require 'db.php';

if (!isset($_SESSION["dangnhap"]) || $_SESSION["dangnhap"] !== true) {
    die("Bạn chưa đăng nhập.");
}

use PhpOffice\PhpWord\TemplateProcessor;

$templateFile = '../template/phieu_giao_de_tai.docx';

try {
    $templateProcessor = new TemplateProcessor($templateFile);

    $hoTenSV1 = $_POST['hoTenSV1'] ?? '';
    $mssv1 = $_POST['mssv1'] ?? '';
    $lop1 = $_POST['lop1'] ?? '';
    
    $hoTenSV2 = $_POST['hoTenSV2'] ?? '';
    $mssv2 = $_POST['mssv2'] ?? '';
    $lop2 = $_POST['lop2'] ?? '';

    $tieuDe = $_POST['tieuDe'] ?? '';
    $nhiemVu_raw = $_POST['nhiemVu'] ?? '';
    $taiLieu_raw = $_POST['taiLieu'] ?? '';
    $tenGVHD = $_POST['tenGVHD'] ?? '';
    
    $ngayGiao_raw = $_POST['ngayGiao'] ?? '';
    $ngayHoanThanh_raw = $_POST['ngayHoanThanh'] ?? '';
    
    $nhiemVu_formatted = str_replace("\n", "<w:br/>", htmlspecialchars($nhiemVu_raw));
    $taiLieu_formatted = str_replace("\n", "<w:br/>", htmlspecialchars($taiLieu_raw));

    $ngayGiao_formatted = '';
    if ($ngayGiao_raw) {
        $date = new DateTime($ngayGiao_raw);
        $ngayGiao_formatted = $date->format('d/m/Y');
    }
    $ngayHoanThanh_formatted = '';
    if ($ngayHoanThanh_raw) {
        $date = new DateTime($ngayHoanThanh_raw);
        $ngayHoanThanh_formatted = $date->format('d/m/Y');
    }

    $templateProcessor->setValue('hoTenSV1', htmlspecialchars($hoTenSV1));
    $templateProcessor->setValue('mssv1', htmlspecialchars($mssv1));
    $templateProcessor->setValue('lop1', htmlspecialchars($lop1));
    
    $templateProcessor->setValue('hoTenSV2', htmlspecialchars($hoTenSV2));
    $templateProcessor->setValue('mssv2', htmlspecialchars($mssv2));
    $templateProcessor->setValue('lop2', htmlspecialchars($lop2));

    $templateProcessor->setValue('tieuDe', htmlspecialchars($tieuDe));
    $templateProcessor->setValue('nhiemVu', $nhiemVu_formatted);
    $templateProcessor->setValue('taiLieu', $taiLieu_formatted);
    $templateProcessor->setValue('tenGVHD', htmlspecialchars($tenGVHD));
    
    $templateProcessor->setValue('ngayGiao', $ngayGiao_formatted);
    $templateProcessor->setValue('ngayHoanThanh', $ngayHoanThanh_formatted);

    $filename = 'Phieu-Giao-De-Tai-' . date('Ymd-His') . '.docx';
    
    header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
    header('Content-Disposition: attachment;filename="' . $filename . '"');
    header('Cache-Control: max-age=0');
    
    $templateProcessor->saveAs('php://output');
    exit;

} catch (Exception $e) {
    die("Lỗi: " . $e->getMessage());
}
?>