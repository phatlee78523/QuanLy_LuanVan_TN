<?php
session_start();
require '../vendor/autoload.php';
require 'db.php';

if (!isset($_SESSION["dangnhap"]) || $_SESSION["dangnhap"] !== true) {
    die("Bạn chưa đăng nhập.");
}

use PhpOffice\PhpWord\TemplateProcessor;

$maDeTai = $_POST['maDeTai'] ?? 0;

$maxPhanTich = floatval($_POST['maxPhanTich'] ?? 0);
$maxThietKe  = floatval($_POST['maxThietKe'] ?? 0);
$maxHienThuc = floatval($_POST['maxHienThuc'] ?? 0);
$maxBaoCao   = floatval($_POST['maxBaoCao'] ?? 0);

$diemPhanTich1 = floatval($_POST['diemPhanTich1'] ?? 0);
$diemThietKe1  = floatval($_POST['diemThietKe1'] ?? 0);
$diemHienThuc1 = floatval($_POST['diemHienThuc1'] ?? 0);
$diemBaoCao1   = floatval($_POST['diemBaoCao1'] ?? 0);
$str_diemTongCong1 = $_POST['diemTongCong1'] ?? ''; 
$str_diemFinal1    = $_POST['diemFinal1'] ?? '';

$diemPhanTich2 = floatval($_POST['diemPhanTich2'] ?? 0);
$diemThietKe2  = floatval($_POST['diemThietKe2'] ?? 0);
$diemHienThuc2 = floatval($_POST['diemHienThuc2'] ?? 0);
$diemBaoCao2   = floatval($_POST['diemBaoCao2'] ?? 0);
$str_diemTongCong2 = $_POST['diemTongCong2'] ?? '';
$str_diemFinal2    = $_POST['diemFinal2'] ?? '';

$ndDieuChinh_raw = $_POST['ndDieuChinh'] ?? '...';
$nxTongQuat_raw  = $_POST['nxTongQuat'] ?? '...';
$uuDiem_raw      = $_POST['uuDiem'] ?? '...';
$thieuSot_raw    = $_POST['thieuSot'] ?? '...';
$cauHoi_raw      = $_POST['cauHoi'] ?? '...';

$thuyetMinh      = $_POST['thuyetMinh'] ?? 'dat';
$thuyetMinh_Dat       = ($thuyetMinh == 'dat') ? 'X' : '';
$thuyetMinh_KhongDat  = ($thuyetMinh == 'khongdat') ? 'X' : '';

$deNghi          = $_POST['deNghi'] ?? 'duoc';
$deNghi_Duoc     = ($deNghi == 'duoc') ? 'X' : '';
$deNghi_Khong    = ($deNghi == 'khong') ? 'X' : '';
$deNghi_BoSung   = ($deNghi == 'bosung') ? 'X' : '';


if ($_SERVER['REQUEST_METHOD'] == 'POST' && $maDeTai > 0) {
    try {

        $totalMax = $maxPT + $maxTK + $maxHT + $maxBC;
        $totalMax = $maxPhanTich + $maxThietKe + $maxHienThuc + $maxBaoCao;
        if ($totalMax == 0) $totalMax = 10;

        $sum1 = $diemPhanTich1 + $diemThietKe1 + $diemHienThuc1 + $diemBaoCao1;
        $finalScore1 = ($sum1 / $totalMax) * 10;

        $sum2 = $diemPhanTich2 + $diemThietKe2 + $diemHienThuc2 + $diemBaoCao2;
        
        $diemTongKetHD = $finalScore1;
        
        if ($sum2 > 0) {
            $finalScore2 = ($sum2 / $totalMax) * 10;
            $diemTongKetHD = ($finalScore1 + $finalScore2) / 2;
        }

        $stmtUpdate = $pdo->prepare("UPDATE DeTai SET diemHuongDan = ? WHERE maDeTai = ?");
        $stmtUpdate->execute([$diemTongKetHD, $maDeTai]);

    } catch (Exception $e) {
    }
}
$sql = "
    SELECT 
        dt.tenDeTai, 
        gv.tenGV AS tenGVHD,
        (SELECT hoTen FROM SinhVien WHERE maDeTai = ? LIMIT 1 OFFSET 0) AS hoTenSV1,
        (SELECT mssv FROM SinhVien WHERE maDeTai = ? LIMIT 1 OFFSET 0) AS mssv1,
        (SELECT lop FROM SinhVien WHERE maDeTai = ? LIMIT 1 OFFSET 0) AS lop1,
        (SELECT hoTen FROM SinhVien WHERE maDeTai = ? LIMIT 1 OFFSET 1) AS hoTenSV2,
        (SELECT mssv FROM SinhVien WHERE maDeTai = ? LIMIT 1 OFFSET 1) AS mssv2,
        (SELECT lop FROM SinhVien WHERE maDeTai = ? LIMIT 1 OFFSET 1) AS lop2
    FROM DeTai dt
    LEFT JOIN GiangVien gv ON dt.maGV_HD = gv.maGV
    WHERE dt.maDeTai = ?;
";
$stmt = $pdo->prepare($sql);
$stmt->execute([$maDeTai, $maDeTai, $maDeTai, $maDeTai, $maDeTai, $maDeTai, $maDeTai]);
$group = $stmt->fetch();

if (!$group) {
    die("Lỗi: Không tìm thấy nhóm.");
}

$hasStudent2 = !empty($group['hoTenSV2']);

if ($hasStudent2) {
    $templateFile = '../template/template_chamdiem_hd_2sv.docx';
} else {
    $templateFile = '../template/template_chamdiem_hd_1sv.docx';
}

if (!file_exists($templateFile)) {
    die("Lỗi: Không tìm thấy file mẫu '" . $templateFile . "'. Vui lòng kiểm tra lại thư mục template.");
}

try {
    $templateProcessor = new TemplateProcessor($templateFile);

    $ndDieuChinh = str_replace("\n", "<w:br/>", htmlspecialchars($ndDieuChinh_raw));
    $nxTongQuat  = str_replace("\n", "<w:br/>", htmlspecialchars($nxTongQuat_raw));
    $uuDiem      = str_replace("\n", "<w:br/>", htmlspecialchars($uuDiem_raw));
    $thieuSot    = str_replace("\n", "<w:br/>", htmlspecialchars($thieuSot_raw));
    $cauHoi      = str_replace("\n", "<w:br/>", htmlspecialchars($cauHoi_raw));

    $templateProcessor->setValue('tenDeTai', htmlspecialchars($group['tenDeTai']));
    $templateProcessor->setValue('tenGVHD', htmlspecialchars($group['tenGVHD']));
    $templateProcessor->setValue('ngayCham', date('d/m/Y'));

    $templateProcessor->setValue('maxPhanTich', $maxPhanTich);
    $templateProcessor->setValue('maxThietKe', $maxThietKe);
    $templateProcessor->setValue('maxHienThuc', $maxHienThuc);
    $templateProcessor->setValue('maxBaoCao', $maxBaoCao);
    
    $templateProcessor->setValue('hoTenSV1', htmlspecialchars($group['hoTenSV1'] ?? ''));
    $templateProcessor->setValue('mssv1', htmlspecialchars($group['mssv1'] ?? ''));
    $templateProcessor->setValue('lop1', htmlspecialchars($group['lop1'] ?? ''));

    $templateProcessor->setValue('diemPhanTich1', $diemPhanTich1);
    $templateProcessor->setValue('diemThietKe1', $diemThietKe1);
    $templateProcessor->setValue('diemHienThuc1', $diemHienThuc1);
    $templateProcessor->setValue('diemBaoCao1', $diemBaoCao1);
    $templateProcessor->setValue('diemTongCong1', htmlspecialchars($str_diemTongCong1));
    $templateProcessor->setValue('diemFinal1', htmlspecialchars($str_diemFinal1));
    
    if ($hasStudent2) {
        $templateProcessor->setValue('hoTenSV2', htmlspecialchars($group['hoTenSV2']));
        $templateProcessor->setValue('mssv2', htmlspecialchars($group['mssv2']));
        $templateProcessor->setValue('lop2', htmlspecialchars($group['lop2']));

        $templateProcessor->setValue('diemPhanTich2', $diemPhanTich2);
        $templateProcessor->setValue('diemThietKe2', $diemThietKe2);
        $templateProcessor->setValue('diemHienThuc2', $diemHienThuc2);
        $templateProcessor->setValue('diemBaoCao2', $diemBaoCao2);
        $templateProcessor->setValue('diemTongCong2', htmlspecialchars($str_diemTongCong2));
        $templateProcessor->setValue('diemFinal2', htmlspecialchars($str_diemFinal2));
    }

    $templateProcessor->setValue('ndDieuChinh', $ndDieuChinh);
    $templateProcessor->setValue('nxTongQuat', $nxTongQuat);
    $templateProcessor->setValue('uuDiem', $uuDiem);
    $templateProcessor->setValue('thieuSot', $thieuSot);
    $templateProcessor->setValue('cauHoi', $cauHoi);
    
    $templateProcessor->setValue('thuyetMinh_Dat', $thuyetMinh_Dat);
    $templateProcessor->setValue('thuyetMinh_KhongDat', $thuyetMinh_KhongDat);
    $templateProcessor->setValue('deNghi_Duoc', $deNghi_Duoc);
    $templateProcessor->setValue('deNghi_Khong', $deNghi_Khong);
    $templateProcessor->setValue('deNghi_BoSung', $deNghi_BoSung);

    $filename = 'Phieu-Cham-Diem-GVHD-' . $group['tenDeTai'] . '.docx';
    
    header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
    header('Content-Disposition: attachment;filename="' . $filename . '"');
    header('Cache-Control: max-age=0');
    
    $templateProcessor->saveAs('php://output');
    exit;

} catch (Exception $e) {
    die("Lỗi: " . $e->getMessage());
}
?>