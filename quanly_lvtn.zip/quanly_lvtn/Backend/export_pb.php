<?php
session_start();

if (!isset($_SESSION["dangnhap"]) || $_SESSION["dangnhap"] !== true) {
    echo "<script>alert('Vui lòng đăng nhập!'); window.location.href='../frontend/dangnhap.html';</script>";
    exit;
}

require 'db.php';
require '../vendor/autoload.php'; 

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;

$templatePath = '../template/template_phanbien.xlsx'; 

$startRow = 9; 

try {
    if (!file_exists($templatePath)) {
        die("Lỗi: Không tìm thấy file mẫu tại " . $templatePath);
    }

    $spreadsheet = IOFactory::load($templatePath);
    $sheet = $spreadsheet->getActiveSheet();

    $currentUser = $_SESSION['username'];
    $isAdmin = (isset($_SESSION['role']) && $_SESSION['role'] == 'admin');
    
    $maGV = $currentUser; 
    if (!$isAdmin) {
        $stmt_gv = $pdo->prepare("SELECT maGV FROM GiangVien WHERE maGV = ? OR email = ? OR tenGV = ?");
        $stmt_gv->execute([$currentUser, $currentUser, $currentUser]);
        $gvInfo = $stmt_gv->fetch();
        if ($gvInfo) {
            $maGV = $gvInfo['maGV'];
        }
    }

    $sql = "
        SELECT 
            dt.maMH AS Nhom,
            dt.tenDeTai, 
            dt.maDeTai, -- Lấy thêm để check cột
            gv_hd.tenGV AS tenGV_HD,
            gv_pb.tenGV AS tenGV_PB,
            (SELECT GROUP_CONCAT(CONCAT(sv.hoTen, ' (', sv.mssv, ')') SEPARATOR '\n')
             FROM SinhVien sv 
             WHERE sv.maDeTai = dt.maDeTai) AS thanhVien
        FROM DeTai dt
        LEFT JOIN GiangVien gv_hd ON dt.maGV_HD = gv_hd.maGV
        LEFT JOIN GiangVien gv_pb ON dt.maGV_PB = gv_pb.maGV
        WHERE 1=1 
    ";

    if ($isAdmin) {
        $sql .= " AND dt.maGV_PB IS NOT NULL ORDER BY dt.maMH ASC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
    } else {
        $sql .= " AND dt.maGV_PB = ? ORDER BY dt.maMH ASC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$maGV]);
    }

    $theses = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($theses)) {
        echo "<script>alert('Không có dữ liệu để xuất! Bạn chưa được phân công phản biện nhóm nào.'); window.history.back();</script>";
        exit;
    }

    $checkCol = $pdo->query("SHOW COLUMNS FROM DeTai LIKE 'diemPhanBien'")->fetch();
    $hasScoreCol = $checkCol ? true : false;

    $row = $startRow;
    $stt = 1;

    foreach ($theses as $thesis) {
        $diem = '';
        $nhanxet = '';
        
        if ($hasScoreCol) {
            $stmtScore = $pdo->prepare("SELECT diemPhanBien, nhanXetPhanBien FROM DeTai WHERE maDeTai = ?");
            $stmtScore->execute([$thesis['maDeTai']]);
            $scoreData = $stmtScore->fetch();
            $diem = $scoreData['diemPhanBien'] ?? '';
            $nhanxet = $scoreData['nhanXetPhanBien'] ?? '';
        }

        $sheet->setCellValue('A' . $row, $stt);
        $sheet->setCellValue('B' . $row, $thesis['tenDeTai']);
        $sheet->setCellValue('C' . $row, $thesis['thanhVien']);
        $sheet->getStyle('C' . $row)->getAlignment()->setWrapText(true);
        $sheet->setCellValue('D' . $row, $thesis['tenGV_HD']);
        $sheet->setCellValue('E' . $row, $thesis['tenGV_PB']);
        $sheet->setCellValue('F' . $row, $diem);
        $sheet->getStyle('F' . $row)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
        $sheet->setCellValue('G' . $row, $nhanxet);
        $sheet->getStyle('G' . $row)->getAlignment()->setWrapText(true);

        $sheet->getStyle('A' . $row . ':G' . $row)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN);
        $sheet->getStyle('A' . $row . ':G' . $row)->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);

        $row++;
        $stt++;
    }
    $filename = 'Danh_Sach_Phan_Bien_' . date('dmY_His') . '.xlsx';
    
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment;filename="'. $filename .'"');
    header('Cache-Control: max-age=0');
    
    $writer = new Xlsx($spreadsheet);
    $writer->save('php://output');
    exit;
} catch (Exception $e) {
    die("Lỗi xuất Excel: " . $e->getMessage());
}
?>