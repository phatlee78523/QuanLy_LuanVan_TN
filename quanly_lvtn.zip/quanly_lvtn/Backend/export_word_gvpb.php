<?php
session_start();
require '../vendor/autoload.php';
require 'db.php';

if (!isset($_SESSION["dangnhap"]) || $_SESSION["dangnhap"] !== true) {
    die("Bạn chưa đăng nhập.");
}

use PhpOffice\PhpWord\TemplateProcessor;

$maDeTai = $_POST['maDeTai'] ?? 0;

$maxPhanTich = floatval($_POST['maxPhanTich'] ?? 0);
$maxThietKe  = floatval($_POST['maxThietKe'] ?? 0);
$maxHienThuc = floatval($_POST['maxHienThuc'] ?? 0);
$maxBaoCao   = floatval($_POST['maxBaoCao'] ?? 0);

$diemPhanTich1_PB = floatval($_POST['diemPhanTich1_PB'] ?? 0);
$diemThietKe1_PB  = floatval($_POST['diemThietKe1_PB'] ?? 0);
$diemHienThuc1_PB = floatval($_POST['diemHienThuc1_PB'] ?? 0);
$diemBaoCao1_PB   = floatval($_POST['diemBaoCao1_PB'] ?? 0);

$str_diemTongCong1_PB = $_POST['diemTongCong1_PB'] ?? '';
$str_diemFinal1_PB    = $_POST['diemFinal1_PB'] ?? '';

$diemPhanTich2_PB = floatval($_POST['diemPhanTich2_PB'] ?? 0);
$diemThietKe2_PB  = floatval($_POST['diemThietKe2_PB'] ?? 0);
$diemHienThuc2_PB = floatval($_POST['diemHienThuc2_PB'] ?? 0);
$diemBaoCao2_PB   = floatval($_POST['diemBaoCao2_PB'] ?? 0);

$str_diemTongCong2_PB = $_POST['diemTongCong2_PB'] ?? '';
$str_diemFinal2_PB    = $_POST['diemFinal2_PB'] ?? '';

$nxTongQuat_raw = $_POST['nxTongQuat_PB'] ?? '...';
$uuDiem_raw     = $_POST['uuDiem_PB'] ?? '...';
$thieuSot_raw   = $_POST['thieuSot_PB'] ?? '...';
$cauHoi_raw     = $_POST['cauHoi_PB'] ?? '...';

$thuyetMinh      = $_POST['thuyetMinh_PB'] ?? 'dat';
$thuyetMinh_Dat_PB       = ($thuyetMinh == 'dat') ? 'X' : '';
$thuyetMinh_KhongDat_PB  = ($thuyetMinh == 'khongdat') ? 'X' : '';

$deNghi          = $_POST['deNghi_PB'] ?? 'duoc';
$deNghi_Duoc_PB    = ($deNghi == 'duoc') ? 'X' : '';
$deNghi_Khong_PB   = ($deNghi == 'khong') ? 'X' : '';
$deNghi_BoSung_PB  = ($deNghi == 'bosung') ? 'X' : '';


if ($_SERVER['REQUEST_METHOD'] == 'POST' && $maDeTai > 0) {
    try {
        $totalMax = $maxPhanTich + $maxThietKe + $maxHienThuc + $maxBaoCao;
        if ($totalMax == 0) $totalMax = 10;

        $sum1 = $diemPhanTich1_PB + $diemThietKe1_PB + $diemHienThuc1_PB + $diemBaoCao1_PB;
        $finalScore1 = ($sum1 / $totalMax) * 10;

        $sum2 = $diemPhanTich2_PB + $diemThietKe2_PB + $diemHienThuc2_PB + $diemBaoCao2_PB;
        
        $diemTongKetPB = $finalScore1;
        
        if ($sum2 > 0) {
            $finalScore2 = ($sum2 / $totalMax) * 10;
            $diemTongKetPB = ($finalScore1 + $finalScore2) / 2;
        }

        $stmtUpdate = $pdo->prepare("UPDATE DeTai SET diemPhanBien = ? WHERE maDeTai = ?");
        $stmtUpdate->execute([$diemTongKetPB, $maDeTai]);

    } catch (Exception $e) {
    }
}


$sql = "
    SELECT 
        dt.tenDeTai, 
        gv.tenGV AS tenGVPB,
        (SELECT hoTen FROM SinhVien WHERE maDeTai = ? LIMIT 1 OFFSET 0) AS hoTenSV1,
        (SELECT mssv FROM SinhVien WHERE maDeTai = ? LIMIT 1 OFFSET 0) AS mssv1,
        (SELECT lop FROM SinhVien WHERE maDeTai = ? LIMIT 1 OFFSET 0) AS lop1,
        (SELECT hoTen FROM SinhVien WHERE maDeTai = ? LIMIT 1 OFFSET 1) AS hoTenSV2,
        (SELECT mssv FROM SinhVien WHERE maDeTai = ? LIMIT 1 OFFSET 1) AS mssv2,
        (SELECT lop FROM SinhVien WHERE maDeTai = ? LIMIT 1 OFFSET 1) AS lop2
    FROM DeTai dt
    LEFT JOIN GiangVien gv ON dt.maGV_PB = gv.maGV
    WHERE dt.maDeTai = ?;
";
$stmt = $pdo->prepare($sql);
$stmt->execute([$maDeTai, $maDeTai, $maDeTai, $maDeTai, $maDeTai, $maDeTai, $maDeTai]);
$group = $stmt->fetch();

if (!$group) { die("Lỗi: Không tìm thấy nhóm."); }

$hasStudent2 = !empty($group['hoTenSV2']);

if ($hasStudent2) {
    $templateFile = '../template/template_chamdiem_pb_2sv.docx';
} else {
    $templateFile = '../template/template_chamdiem_pb_1sv.docx';
}

if (!file_exists($templateFile)) { 
    die("Lỗi: Không tìm thấy file mẫu '" . $templateFile . "'. Hãy tạo file này trong thư mục template."); 
}

try {
    $templateProcessor = new TemplateProcessor($templateFile);

    $nxTongQuat = str_replace("\n", "<w:br/>", htmlspecialchars($nxTongQuat_raw));
    $uuDiem     = str_replace("\n", "<w:br/>", htmlspecialchars($uuDiem_raw));
    $thieuSot   = str_replace("\n", "<w:br/>", htmlspecialchars($thieuSot_raw));
    $cauHoi     = str_replace("\n", "<w:br/>", htmlspecialchars($cauHoi_raw));

    $templateProcessor->setValue('tenDeTai', htmlspecialchars($group['tenDeTai']));
    $templateProcessor->setValue('tenGVPB', htmlspecialchars($group['tenGVPB']));
    $templateProcessor->setValue('ngayCham', date('d/m/Y'));

    $templateProcessor->setValue('maxPhanTich', $maxPhanTich);
    $templateProcessor->setValue('maxThietKe', $maxThietKe);
    $templateProcessor->setValue('maxHienThuc', $maxHienThuc);
    $templateProcessor->setValue('maxBaoCao', $maxBaoCao);
    
    $templateProcessor->setValue('hoTenSV1', htmlspecialchars($group['hoTenSV1'] ?? ''));
    $templateProcessor->setValue('mssv1', htmlspecialchars($group['mssv1'] ?? ''));
    $templateProcessor->setValue('lop1', htmlspecialchars($group['lop1'] ?? ''));
    
    $templateProcessor->setValue('diemPhanTich1_PB', $diemPhanTich1_PB);
    $templateProcessor->setValue('diemThietKe1_PB', $diemThietKe1_PB);
    $templateProcessor->setValue('diemHienThuc1_PB', $diemHienThuc1_PB);
    $templateProcessor->setValue('diemBaoCao1_PB', $diemBaoCao1_PB);
    $templateProcessor->setValue('diemTongCong1_PB', htmlspecialchars($str_diemTongCong1_PB));
    $templateProcessor->setValue('diemFinal1_PB', htmlspecialchars($str_diemFinal1_PB));
    
    if ($hasStudent2) {
        $templateProcessor->setValue('hoTenSV2', htmlspecialchars($group['hoTenSV2']));
        $templateProcessor->setValue('mssv2', htmlspecialchars($group['mssv2']));
        $templateProcessor->setValue('lop2', htmlspecialchars($group['lop2']));

        $templateProcessor->setValue('diemPhanTich2_PB', $diemPhanTich2_PB);
        $templateProcessor->setValue('diemThietKe2_PB', $diemThietKe2_PB);
        $templateProcessor->setValue('diemHienThuc2_PB', $diemHienThuc2_PB);
        $templateProcessor->setValue('diemBaoCao2_PB', $diemBaoCao2_PB);
        $templateProcessor->setValue('diemTongCong2_PB', htmlspecialchars($str_diemTongCong2_PB));
        $templateProcessor->setValue('diemFinal2_PB', htmlspecialchars($str_diemFinal2_PB));
    }

    $templateProcessor->setValue('nxTongQuat_PB', $nxTongQuat);
    $templateProcessor->setValue('uuDiem_PB', $uuDiem);
    $templateProcessor->setValue('thieuSot_PB', $thieuSot);
    $templateProcessor->setValue('cauHoi_PB', $cauHoi);
    
    $templateProcessor->setValue('thuyetMinh_Dat_PB', $thuyetMinh_Dat_PB);
    $templateProcessor->setValue('thuyetMinh_KhongDat_PB', $thuyetMinh_KhongDat_PB);
    $templateProcessor->setValue('deNghi_Duoc_PB', $deNghi_Duoc_PB);
    $templateProcessor->setValue('deNghi_Khong_PB', $deNghi_Khong_PB);
    $templateProcessor->setValue('deNghi_BoSung_PB', $deNghi_BoSung_PB);

    $filename = 'Phieu-Cham-Diem-GVPB-' . $group['tenDeTai'] . '.docx';
    
    header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
    header('Content-Disposition: attachment;filename="' . $filename . '"');
    header('Cache-Control: max-age=0');
    
    $templateProcessor->saveAs('php://output');
    exit;

} catch (Exception $e) {
    die("Lỗi: " . $e->getMessage());
}
?>