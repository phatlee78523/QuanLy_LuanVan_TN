<?php
session_start();

if (!isset($_SESSION["dangnhap"]) || $_SESSION["dangnhap"] !== true) {
    echo "<script>alert('Vui lòng đăng nhập!'); window.location.href='../frontend/dangnhap.html';</script>";
    exit;
}

require 'db.php';
require '../vendor/autoload.php'; 

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;

$templatePath = '../template/template_hoidong.xlsx'; 
$startRow = 8; 

try {
    if (!file_exists($templatePath)) {
        die("Lỗi: Không tìm thấy file template tại '" . $templatePath . "'");
    }

    $spreadsheet = IOFactory::load($templatePath);
    $sheet = $spreadsheet->getActiveSheet();
    $sql = "
        SELECT 
            H.tenHoiDong, 
            H.diaDiem,
            sv.mssv,
            sv.hoTen,
            sv.lop,
            dt.tenDeTai,
            gv.tenGV AS tenGVHD
        FROM HoiDong H
        JOIN DeTai dt ON dt.maHoiDong = H.maHoiDong  -- Chỉ lấy đề tài đã gán HĐ
        JOIN SinhVien sv ON sv.maDeTai = dt.maDeTai  -- Lấy sinh viên của đề tài đó
        LEFT JOIN GiangVien gv ON dt.maGV_HD = gv.maGV
        ORDER BY H.tenHoiDong ASC, dt.tenDeTai ASC, sv.mssv ASC
    ";
    
    $stmt = $pdo->query($sql);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if (empty($rows)) {
        echo "<script>
                alert('Không có dữ liệu để xuất! Nguyên nhân: Chưa có Đề tài nào được gán vào Hội đồng.'); 
                window.history.back();
              </script>";
        exit;
    }

    $row = $startRow;
    $stt = 1;
    
    foreach ($rows as $data) {
        $fullName = trim($data['hoTen']);
        $parts = explode(' ', $fullName);
        if (count($parts) > 1) {
            $ten = array_pop($parts); 
            $ho = implode(' ', $parts); 
        } else {
            $ten = $fullName;
            $ho = '';
        }

        $sheet->setCellValue('A' . $row, $stt++);
        $sheet->setCellValue('B' . $row, $data['tenHoiDong']);
        $sheet->setCellValue('C' . $row, $data['mssv']);
        $sheet->setCellValue('D' . $row, $ho);
        $sheet->setCellValue('E' . $row, $ten);
        $sheet->setCellValue('F' . $row, $data['lop']);
        $sheet->setCellValue('G' . $row, $data['tenGVHD']);
        $sheet->setCellValue('H' . $row, $data['tenDeTai']);
        $sheet->setCellValue('I' . $row, $data['diaDiem']);
        $sheet->getStyle('H' . $row)->getAlignment()->setWrapText(true); 
        $sheet->getStyle('A' . $row . ':I' . $row)->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
        $sheet->getStyle('A' . $row . ':I' . $row)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN);
        
        $row++;
    }
    foreach (range('A', 'I') as $col) {
        if ($col != 'H') { 
            $sheet->getColumnDimension($col)->setAutoSize(true);
        }
    }
    $sheet->getColumnDimension('H')->setWidth(40); 
    $filename = 'Danh_Sach_Hoi_Dong_' . date('dmY_His') . '.xlsx';
    if (ob_get_length()) ob_end_clean();
    
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment;filename="'. $filename .'"');
    header('Cache-Control: max-age=0');
    
    $writer = new Xlsx($spreadsheet);
    $writer->save('php://output');
    exit;

} catch (Exception $e) {
    die("Lỗi hệ thống: " . $e->getMessage());
}
?>