<?php
session_start();
if (!isset($_SESSION["dangnhap"]) || $_SESSION["dangnhap"] !== true) {
    header("location: dangnhap.html");
    exit;
}
require '../backend/db.php';
$vaiTro = $_SESSION['role'];
$thongTinCaNhan = [];

if ($vaiTro == 'admin') {
    $thongTinCaNhan['hoTen'] = "Quản trị viên";
    $thongTinCaNhan['maSo'] = $_SESSION['username'];
} else {
    $maGiangVien = $_SESSION['maGV']; 
    
    $command = $pdo->prepare("SELECT * FROM GiangVien WHERE maGV = ?");
    $command->execute([$maGiangVien]);
    $giangVien = $command->fetch();
    
    if ($giangVien) {
        $thongTinCaNhan['hoTen'] = $giangVien['tenGV'];
        $thongTinCaNhan['maSo'] = $giangVien['maGV'];
        $thongTinCaNhan['email'] = $giangVien['email'] ?? 'Chưa cập nhật';
        $thongTinCaNhan['sdt'] = $giangVien['soDienThoai'] ?? 'Chưa cập nhật';
    } else {
        $thongTinCaNhan['hoTen'] = $_SESSION['username'];
        $thongTinCaNhan['maSo'] = $maGiangVien;
        $thongTinCaNhan['email'] = '';
        $thongTinCaNhan['sdt'] = '';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Hồ sơ cá nhân</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="icon" type="image/png" href="../images/STU.webp" />
    <link rel="stylesheet" href="../style/style.css">
    <link rel="stylesheet" href="../style/hoso.css">
</head>
<body>
    <div class="app-layout">
        
        <aside class="sidebar">
            <div class="sidebar-header"><img src="../images/Logo_STU.png" alt="Logo STU" class="sidebar-logo"></div>
            <nav class="sidebar-nav">
                <a href="index.php" class="nav-item"><i class="fa-solid fa-tachometer-alt"></i><span>Dashboard</span></a>
                <a href="javascript:history.back()" class="nav-item" style="margin-top: 20px; color: #94a3b8;">
                    <i class="fa-solid fa-arrow-left"></i><span>Quay lại</span>
                </a>
            </nav>
        </aside>

        <div class="main-content-wrapper">
            <header class="header">
                <h1>Hệ thống Quản lý Luận văn Tốt nghiệp</h1>
                <div class="user-actions">
                    <span>Chào, <strong><?= $_SESSION["username"]; ?></strong></span>
                    
                    <a href="../backend/dangxuat.php" class="button danger">
                        <i class="fa-solid fa-door-open"></i> Đăng xuất
                    </a>
                </div>
            </header>

            <main class="content">
                <h2>Hồ sơ cá nhân</h2>
                
                <?php if(isset($_GET['msg']) && $_GET['msg'] == 'success'): ?>
                    <div style="background: #dcfce7; color: #166534; padding: 15px; margin-bottom: 20px; border-radius: 6px;">
                        <i class="fa-solid fa-check-circle"></i> Đổi mật khẩu thành công!
                    </div>
                <?php elseif(isset($_GET['msg']) && $_GET['msg'] == 'error'): ?>
                    <div style="background: #fee2e2; color: #991b1b; padding: 15px; margin-bottom: 20px; border-radius: 6px;">
                        <i class="fa-solid fa-triangle-exclamation"></i> Mật khẩu cũ không đúng hoặc xác nhận mật khẩu sai.
                    </div>
                <?php endif; ?>

                <div class="profile-container">
                    
                    <div class="profile-card">
                        <h3><i class="fa-solid fa-id-card"></i> Thông tin tài khoản</h3>
                        <hr style="margin: 15px 0; border: 0; border-top: 1px solid #eee;">
                        
                        <div class="avatar-placeholder">
                            <i class="fa-solid fa-user"></i>
                        </div>

                        <div class="info-row">
                            <strong>Họ và Tên:</strong>
                            <span><?= ($thongTinCaNhan['hoTen']) ?></span>
                        </div>
                        <div class="info-row">
                            <strong>Mã số:</strong>
                            <span><?= ($thongTinCaNhan['maSo']) ?></span>
                        </div>
                        
                        <?php if ($vaiTro != 'admin'): ?>
                        <div class="info-row">
                            <strong>Email:</strong>
                            <span><?= ($thongTinCaNhan['email']) ?></span>
                        </div>
                        <div class="info-row">
                            <strong>Số điện thoại:</strong>
                            <span><?= ($thongTinCaNhan['sdt']) ?></span>
                        </div>
                        <?php endif; ?>
                        
                        <div class="info-row">
                            <strong>Vai trò:</strong>
                            <span style="text-transform: capitalize; color: #2563eb;"><?= ($vaiTro) ?></span>
                        </div>
                    </div>

                    <div class="password-card">
                        <h3><i class="fa-solid fa-key"></i> Đổi mật khẩu</h3>
                        <hr style="margin: 15px 0; border: 0; border-top: 1px solid #eee;">
                        
                        <form action="../backend/actions.php" method="post">
                            <input type="hidden" name="action" value="change_password">
                            
                            <div class="form-group">
                                <label>Mật khẩu cũ</label>
                                <input type="password" name="old_pass" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px;">
                            </div>
                            
                            <div class="form-group">
                                <label>Mật khẩu mới</label>
                                <input type="password" name="new_pass" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px;">
                            </div>
                            
                            <div class="form-group">
                                <label>Nhập lại mật khẩu mới</label>
                                <input type="password" name="confirm_pass" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px;">
                            </div>
                            
                            <button type="submit" class="button primary" style="width: 100%; margin-top: 10px;">
                                Lưu thay đổi
                            </button>
                        </form>
                    </div>

                </div>
            </main>
        </div>
    </div>
</body>
</html>