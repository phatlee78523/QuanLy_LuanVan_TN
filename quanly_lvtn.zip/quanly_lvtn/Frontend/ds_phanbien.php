<?php
session_start();
if (!isset($_SESSION["dangnhap"]) || $_SESSION["dangnhap"] !== true) {
    header("location: dangnhap.html");
    exit;
}
require '../backend/db.php';

$currentUser = $_SESSION['username'];
$stmt_gv = $pdo->prepare("SELECT maGV FROM GiangVien WHERE maGV = ? OR email = ?");
$stmt_gv->execute([$currentUser, $currentUser]);
$gv = $stmt_gv->fetch();
$maGV = $gv ? $gv['maGV'] : $currentUser;

$sql = "
    SELECT 
        dt.maDeTai, dt.tenDeTai, dt.maMH,
        dt.diemPhanBien, dt.nhanXetPhanBien,
        gv.tenGV as tenGV_HD,
        (SELECT GROUP_CONCAT(CONCAT(sv.hoTen, ' (', sv.mssv, ')') SEPARATOR '<br>') 
         FROM SinhVien sv WHERE sv.maDeTai = dt.maDeTai) AS thanhVien
    FROM DeTai dt
    LEFT JOIN GiangVien gv ON dt.maGV_HD = gv.maGV
    WHERE dt.maGV_PB = ? 
    ORDER BY dt.maMH ASC
";
$stmt = $pdo->prepare($sql);
$stmt->execute([$maGV]);
$groups = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Chấm Phản Biện</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="icon" type="image/png" href="../images/STU.webp" />
    <link rel="stylesheet" href="../style/style.css">
    <style>
        * { box-sizing: border-box; } body { font-size: 13px; background-color: #f8fafc; margin: 0; padding: 0; }
        .app-layout { display: block; width: 100%; min-height: 100vh; }
        .content { padding: 30px; max-width: 1200px; margin: 0 auto; }
        
        .card-container { display: grid; grid-template-columns: 1fr; gap: 20px; }
        .group-card { background: #fff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.02); }
        .group-header { display: flex; justify-content: space-between; margin-bottom: 15px; border-bottom: 1px dashed #e2e8f0; padding-bottom: 10px; }
        .group-badge { background: #10b981; color: white; padding: 4px 10px; border-radius: 20px; font-weight: 700; font-size: 11px; }
        
        .btn-grade { background: #f59e0b; color: white; border: none; padding: 8px 15px; border-radius: 5px; cursor: pointer; display: inline-flex; align-items: center; gap: 5px; font-weight: 600; }
        .btn-word { background: #2563eb; color: white; border: none; padding: 8px 15px; border-radius: 5px; cursor: pointer; text-decoration: none; display: inline-flex; align-items: center; gap: 5px; font-weight: 600; font-size: 13px; }
        .btn-word:hover { background: #1d4ed8; }

        .modal-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 2000; display: none; align-items: center; justify-content: center; }
        .modal-overlay.active { display: flex; }
        .modal-content { background: #fff; padding: 25px; border-radius: 10px; width: 500px; }
        .form-group { margin-bottom: 15px; } .form-group label { display: block; margin-bottom: 5px; font-weight: 600; }
        .form-group input, .form-group textarea { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 5px; }
    </style>
</head>
<body>
    <div class="app-layout">
        <header class="header" style="background:#fff; height:60px; padding:0 20px; display:flex; align-items:center; justify-content:space-between; border-bottom:1px solid #eee;">
            <div style="display: flex; align-items: center; gap: 10px;">
                <img src="../images/STU.webp" style="height: 38px;">
                <h1 style="font-size: 18px; margin: 0; font-weight: 700; color: #1e293b;">Giảng viên Phản biện</h1>
            </div>
            <div style="margin-bottom: 20px; display: flex; justify-content: space-between; align-items: end;">
            <div>
                <h2 style="margin: 0; color: #1e293b;">Đánh giá & Phản biện (Tuần 5)</h2>
                <p style="color: #64748b; margin: 5px 0 0 0;">Danh sách các nhóm được phân công phản biện.</p>
            </div>
            
            <a href="../backend/export_pb.php" class="btn-word" style="background: #10b981; text-decoration: none; color: white;">
                <i class="fa-solid fa-file-excel"></i> Xuất Excel DS
            </a>
           </div>
        </header>

        <div class="main-content-wrapper" style="margin-top: 60px;">
            <main class="content">
                <div style="margin-bottom: 20px;">
                    <h2 style="margin: 0; color: #1e293b;">Đánh giá & Phản biện (Tuần 5)</h2>
                    <p style="color: #64748b;">Danh sách các nhóm được phân công phản biện.</p>
                </div>

                <div class="card-container">
                    <?php if (empty($groups)): ?>
                        <div style="text-align:center; padding:40px; background:#fff; border-radius:8px; border:1px solid #eee;">
                            <i class="fa-solid fa-clipboard-list" style="font-size:40px; color:#ccc; margin-bottom:10px;"></i>
                            <p style="color:#64748b;">Bạn chưa được phân công phản biện nhóm nào.</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($groups as $group): ?>
                        <div class="group-card">
                            <div class="group-header">
                                <div>
                                    <span class="group-badge">NHÓM <?= htmlspecialchars($group['maMH'] ?? '?') ?></span>
                                    <div style="margin-top: 8px; font-weight: 700; font-size: 16px; color: #1e293b;">
                                        <?= htmlspecialchars($group['tenDeTai']) ?>
                                    </div>
                                    <div style="font-size: 12px; color: #64748b; margin-top: 5px;">
                                        <i class="fa-solid fa-user-tie"></i> GVHD: <?= htmlspecialchars($group['tenGV_HD']) ?>
                                    </div>
                                </div>
                                <div style="text-align: right;">
                                    <?php if(isset($group['diemPhanBien'])): ?>
                                        <div style="font-size: 24px; font-weight: 700; color: #10b981;"><?= $group['diemPhanBien'] ?></div>
                                        <span style="font-size: 11px; color: #64748b;">Điểm PB</span>
                                    <?php else: ?>
                                        <span style="font-size: 12px; color: #94a3b8; font-style: italic;">Chưa chấm</span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div style="background: #f8fafc; padding: 15px; border-radius: 6px; margin-bottom: 15px; border: 1px solid #f1f5f9; line-height:1.6;">
                                <strong><i class="fa-solid fa-users"></i> Thành viên:</strong><br>
                                <?= $group['thanhVien'] ?>
                            </div>

                            <div style="display: flex; justify-content: flex-end; gap: 10px;">
                                <a href="../backend/export_word_pb.php?maDeTai=<?= $group['maDeTai'] ?>" class="btn-word">
                                    <i class="fa-solid fa-file-word"></i> Xuất Phiếu
                                </a>

                                <button class="btn-grade" 
                                    onclick="openGradeModal('<?= $group['maDeTai'] ?>', '<?= $group['diemPhanBien'] ?? '' ?>', '<?= htmlspecialchars($group['nhanXetPhanBien'] ?? '') ?>')">
                                    <i class="fa-solid fa-pen-to-square"></i> Đánh giá
                                </button>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </main>
        </div>
    </div>

    <div id="pb-modal" class="modal-overlay">
        <div class="modal-content">
            <h2>Đánh giá Phản biện</h2>
            <form action="../backend/actions.php" method="post">
                <input type="hidden" name="action" value="update_score_pb">
                <input type="hidden" id="pb_madetai" name="maDeTai">
                
                <div class="form-group">
                    <label>Điểm số (Thang 10)</label>
                    <input type="number" id="pb_diem" name="diemPhanBien" min="0" max="10" step="0.1" required placeholder="Ví dụ: 8.5">
                </div>

                <div class="form-group">
                    <label>Nhận xét / Câu hỏi phản biện</label>
                    <textarea id="pb_nhanxet" name="nhanXetPhanBien" rows="5" placeholder="Nhập nhận xét chi tiết..."></textarea>
                </div>

                <div style="text-align: right; margin-top: 20px;">
                    <button type="button" onclick="document.getElementById('pb-modal').classList.remove('active')" style="padding: 8px 15px; cursor: pointer; background: white; border: 1px solid #ccc; border-radius: 4px;">Hủy</button>
                    <button type="submit" style="padding: 8px 15px; background: #10b981; color: white; border: none; border-radius: 4px; cursor: pointer;">Lưu kết quả</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function openGradeModal(id, diem, nhanxet) {
            document.getElementById('pb_madetai').value = id;
            document.getElementById('pb_diem').value = diem;
            document.getElementById('pb_nhanxet').value = nhanxet;
            document.getElementById('pb-modal').classList.add('active');
        }
        
        window.onclick = function(event) {
            const modal = document.getElementById('pb-modal');
            if (event.target == modal) {
                modal.classList.remove('active');
            }
        }
    </script>
</body>
</html>