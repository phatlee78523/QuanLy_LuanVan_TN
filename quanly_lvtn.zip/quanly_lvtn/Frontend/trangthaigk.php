<?php
session_start();
if (!isset($_SESSION["dangnhap"]) || $_SESSION["dangnhap"] !== true) {
    header("location: dangnhap.html");
    exit;
}
if (isset($_SESSION['role']) && $_SESSION['role'] != 'admin') {
    header("location: index.php");
    exit;
}

require '../backend/db.php';

$statusGK = $pdo->query("SELECT trangThaiChamGK FROM CauHinh WHERE id = 1")->fetchColumn();


$totalGroups = $pdo->query("SELECT COUNT(*) FROM DeTai")->fetchColumn();
$gradedGroups = $pdo->query("SELECT COUNT(*) FROM DeTai WHERE diemGiuaKy IS NOT NULL")->fetchColumn();
$passGroups = $pdo->query("SELECT COUNT(*) FROM DeTai WHERE trangThaiGiuaKy = 'Được làm tiếp'")->fetchColumn();
$failGroups = $pdo->query("SELECT COUNT(*) FROM DeTai WHERE trangThaiGiuaKy = 'Đình chỉ'")->fetchColumn();


$sql = "
    SELECT 
        dt.maDeTai, dt.tenDeTai, dt.maMH,
        gv.tenGV, 
        dt.diemGiuaKy, dt.trangThaiGiuaKy, dt.nhanXetGiuaKy,
        (SELECT COUNT(*) FROM SinhVien sv WHERE sv.maDeTai = dt.maDeTai) AS soLuongSV
    FROM DeTai dt
    LEFT JOIN GiangVien gv ON dt.maGV_HD = gv.maGV
    ORDER BY dt.maDeTai ASC;
";
$theses = $pdo->query($sql)->fetchAll();
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản lý Trạng thái Giữa kỳ</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="icon" type="image/png" href="../images/STU.webp" />
    <link rel="stylesheet" href="../style/style.css">
    <link rel="stylesheet" href="../style/trangthaigk.css">
</head>
<body>
    <div class="app-layout">
        <header class="header">
            <div style="display:flex; gap:10px; align-items:center;">
                <img src="../images/STU.webp" style="height:38px;"> 
                <h1 style="font-size:18px; margin:0; color: #1e293b; font-weight: 700;">QUẢN LÝ TRẠNG THÁI GIỮA KỲ</h1>
            </div>
        </header>

        <div class="main-content-wrapper">
            <main class="content">
                
                <div class="control-panel">
                    <div class="status-display">
                        <div class="status-icon <?= $statusGK == 1 ? 'status-open' : 'status-closed' ?>">
                            <i class="fa-solid <?= $statusGK == 1 ? 'fa-unlock' : 'fa-lock' ?>"></i>
                        </div>
                        <div>
                            <h3 style="margin:0; font-size:16px; color:#1e293b;">Hệ thống Chấm điểm</h3>
                            <span style="color: <?= $statusGK == 1 ? '#16a34a' : '#dc2626' ?>; font-weight:600;">
                                <?= $statusGK == 1 ? 'ĐANG MỞ (Giảng viên có thể chấm)' : 'ĐANG ĐÓNG (Chỉ xem)' ?>
                            </span>
                        </div>
                    </div>
                    
                    <form action="../backend/actions.php" method="post" onsubmit="return confirm('Bạn có chắc muốn thay đổi trạng thái hệ thống?');">
                        <input type="hidden" name="action" value="toggle_midterm">
                        <input type="hidden" name="trangThaiHienTai" value="<?= $statusGK ?>">
                        <button type="submit" class="btn-toggle <?= $statusGK == 1 ? 'btn-off' : 'btn-on' ?>">
                            <?= $statusGK == 1 ? '<i class="fa-solid fa-lock"></i> KHOÁ HỆ THỐNG' : '<i class="fa-solid fa-unlock"></i> MỞ HỆ THỐNG' ?>
                        </button>
                    </form>
                </div>

                <div class="stats-grid">
                    <div class="stat-card">
                        <span class="stat-num"><?= $totalGroups ?></span>
                        <span class="stat-label">Tổng nhóm</span>
                    </div>
                    <div class="stat-card">
                        <span class="stat-num" style="color:#2563eb;"><?= $gradedGroups ?> / <?= $totalGroups ?></span>
                        <span class="stat-label">Đã chấm điểm</span>
                    </div>
                    <div class="stat-card">
                        <span class="stat-num" style="color:#16a34a;"><?= $passGroups ?></span>
                        <span class="stat-label">Được làm tiếp</span>
                    </div>
                    <div class="stat-card">
                        <span class="stat-num" style="color:#dc2626;"><?= $failGroups ?></span>
                        <span class="stat-label">Bị đình chỉ</span>
                    </div>
                </div>

                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                    <h3 style="margin:0; color:#334155;">Chi tiết kết quả đánh giá</h3>
                    <a href="../backend/export_sv.php" style="text-decoration:none; color:#16a34a; font-weight:600; font-size:13px;">
                        <i class="fa-solid fa-file-excel"></i> Xuất Excel
                    </a>
                </div>

                <div class="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th style="width: 80px;">Nhóm</th>
                                <th style="width: 25%;">Tên Đề tài</th>
                                <th style="width: 15%;">GV Hướng dẫn</th>
                                <th style="width: 10%; text-align:center;">Tiến độ</th>
                                <th style="width: 15%; text-align:center;">Trạng thái</th>
                                <th>Nhận xét</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($theses as $row): ?>
                            <tr>
                                <td>
                                    <span style="font-weight:700; color:#2563eb;">#<?= $row['maMH'] ?></span>
                                    <div style="font-size:10px; color:#94a3b8;"><?= $row['soLuongSV'] ?> SV</div>
                                </td>
                                <td style="font-weight:500;">
                                    <?= htmlspecialchars($row['tenDeTai']) ?>
                                    <?php if(empty($row['tenDeTai'])) echo '<i style="color:#94a3b8">(Chưa có tên)</i>'; ?>
                                </td>
                                <td><?= htmlspecialchars($row['tenGV']) ?></td>
                                <td style="text-align:center; font-weight:700;">
                                    <?= isset($row['diemGiuaKy']) ? $row['diemGiuaKy'].'%' : '-' ?>
                                </td>
                                <td style="text-align:center;">
                                    <?php 
                                        if($row['trangThaiGiuaKy'] == 'Được làm tiếp') echo '<span class="badge bg-pass">Được làm tiếp</span>';
                                        elseif($row['trangThaiGiuaKy'] == 'Đình chỉ') echo '<span class="badge bg-fail">Đình chỉ</span>';
                                        else echo '<span class="badge bg-wait">Chưa đánh giá</span>';
                                    ?>
                                </td>
                                <td style="font-size:12px; color:#64748b;"><?= htmlspecialchars($row['nhanXetGiuaKy'] ?? '') ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

            </main>
        </div>
    </div>
</body>
</html>