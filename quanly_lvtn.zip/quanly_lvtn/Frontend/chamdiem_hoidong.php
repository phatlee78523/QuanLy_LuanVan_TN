<?php
session_start();
if (!isset($_SESSION["dangnhap"]) || $_SESSION["dangnhap"] !== true) {
    header("location: dangnhap.html");
    exit;
}
require '../backend/db.php';

$currentUser = $_SESSION['username']; 

$stmt_gv = $pdo->prepare("SELECT * FROM GiangVien WHERE maGV = ? OR email = ? OR tenGV = ?");
$stmt_gv->execute([$currentUser, $currentUser, $currentUser]);
$gvInfo = $stmt_gv->fetch(PDO::FETCH_ASSOC);

if (!$gvInfo) {
    $maGV = $currentUser;
    $tenGV = $currentUser;
    $emailGV = $currentUser;
} else {
    $maGV = $gvInfo['maGV'];
    $tenGV = $gvInfo['tenGV'];
    $emailGV = $gvInfo['email'];
}

$sql_hd = "
    SELECT DISTINCT H.maHoiDong, H.tenHoiDong, H.diaDiem, TV.vaiTro
    FROM HoiDong H
    JOIN ThanhVienHoiDong TV ON H.maHoiDong = TV.maHoiDong
    WHERE 
       TV.maGV = ? OR TV.maGV = ? OR TV.maGV = ?       
    ORDER BY H.maHoiDong ASC
";

$stmt = $pdo->prepare($sql_hd);
$stmt->execute([$maGV, $tenGV, $currentUser]);
$myCouncils = $stmt->fetchAll(PDO::FETCH_ASSOC);
$selectedHD = isset($_GET['hd']) ? $_GET['hd'] : ($myCouncils[0]['maHoiDong'] ?? 0);

$currentCouncilInfo = null;
if (!empty($myCouncils)) {
    foreach ($myCouncils as $c) {
        if ($c['maHoiDong'] == $selectedHD) {
            $currentCouncilInfo = $c;
            break;
        }
    }
    if (!$currentCouncilInfo) {
        $currentCouncilInfo = $myCouncils[0];
        $selectedHD = $currentCouncilInfo['maHoiDong'];
    }
}

$theses = [];
if ($selectedHD) {
    $sql_detai = "
        SELECT 
            dt.maDeTai, dt.tenDeTai, 
            dt.diemHuongDan, dt.diemPhanBien, 
            dt.diemHoiDong, dt.nhanXetHoiDong, dt.diemTongKet, dt.diemChu,
            gv1.tenGV AS tenGVHD, 
            gv2.tenGV AS tenGVPB,
            (SELECT GROUP_CONCAT(CONCAT(sv.hoTen, ' (', sv.mssv, ')') SEPARATOR '<br>') 
             FROM SinhVien sv WHERE sv.maDeTai = dt.maDeTai) AS dsSinhVien
        FROM DeTai dt
        LEFT JOIN GiangVien gv1 ON dt.maGV_HD = gv1.maGV
        LEFT JOIN GiangVien gv2 ON dt.maGV_PB = gv2.maGV
        WHERE dt.maHoiDong = ? 
        ORDER BY dt.maDeTai ASC
    ";
    $stmt = $pdo->prepare($sql_detai);
    $stmt->execute([$selectedHD]);
    $theses = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Chấm điểm Hội đồng</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="../style/style.css">
    <link rel="stylesheet" href="../style/chamdiem_hoidong.css">    
</head>
<body>
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <div>
            <h2 style="margin: 0; color: #1e293b; display: flex; align-items: center; font-size: 22px;">
                <i class="fa-solid fa-gavel" style="margin-right: 10px; color: #2563eb;"></i> Chấm điểm Hội đồng
            </h2>
            <p style="margin: 5px 0 0 0; color: #64748b; font-size: 14px;">Giảng viên: <strong><?= htmlspecialchars($tenGV) ?></strong></p>
        </div>
        <a href="index.php" class="button" style="background: #fff; border: 1px solid #cbd5e1; color: #64748b; text-decoration: none; padding: 8px 15px; border-radius: 6px; font-weight: 600;">
            <i class="fa-solid fa-arrow-left"></i> Quay lại
        </a>
    </div>

    <?php if(!empty($myCouncils)): ?>
    <div class="tabs">
        <?php foreach($myCouncils as $hd): ?>
            <a href="?hd=<?= $hd['maHoiDong'] ?>" class="tab-item <?= ($selectedHD == $hd['maHoiDong']) ? 'active' : '' ?>">
                <i class="fa-solid fa-users-rectangle"></i> <?= htmlspecialchars($hd['tenHoiDong']) ?>
            </a>
        <?php endforeach; ?>
    </div>

    <div class="info-bar">
        <div>
            <span style="color: #64748b;">Đang làm việc tại:</span>
            <strong style="color: #1e293b; font-size: 16px; margin-left: 5px;"><?= htmlspecialchars($currentCouncilInfo['tenHoiDong']) ?></strong>
            <span style="margin: 0 10px; color: #cbd5e1;">|</span>
            <i class="fa-solid fa-location-dot" style="color: #ef4444;"></i> <?= htmlspecialchars($currentCouncilInfo['diaDiem']) ?>
            <span class="badge-role">Vai trò: <?= $currentCouncilInfo['vaiTro'] ?></span>
        </div>
        
        <div style="display: flex; gap: 10px;">
            <a href="../backend/export_tongket.php?type=single&maHoiDong=<?= $selectedHD ?>" class="button" style="background: #10b981; color: white; text-decoration: none; padding: 8px 15px; border-radius: 6px; font-size: 13px; font-weight: 600;">
                <i class="fa-solid fa-file-excel"></i> Xuất Kết quả
            </a>
        </div>
    </div>
    <?php endif; ?>

    <?php if(empty($theses)): ?>
        <div class="card" style="text-align: center; padding: 60px 20px;">
            <i class="fa-regular fa-folder-open" style="font-size: 48px; color: #cbd5e1; margin-bottom: 15px;"></i>
            <p style="color: #64748b; font-weight: 600; margin: 0; font-size: 16px;">Hội đồng này chưa được phân công đề tài nào hoặc bạn chưa tham gia hội đồng nào.</p>
        </div>
    <?php else: ?>
        <div class="card">
            <form action="../backend/actions.php" method="post">
                <input type="hidden" name="action" value="update_council_score">
                <input type="hidden" name="maHoiDong" value="<?= $selectedHD ?>">
                
                <table>
                    <thead>
                        <tr>
                            <th style="width: 40px;">#</th>
                            <th>Đề tài / Sinh viên</th>
                            <th style="width: 80px;">GVHD<br><span style="font-size:11px; font-weight:normal;">(20%)</span></th>
                            <th style="width: 80px;">GVPB<br><span style="font-size:11px; font-weight:normal;">(20%)</span></th>
                            
                            <th style="width: 110px; background: #fff7ed; border-bottom: 3px solid #f97316;">Điểm HĐ<br><span style="font-size:11px; font-weight:normal;">(60%)</span></th>
                            <th style="width: 250px;">Nhận xét Hội đồng</th>
                            <th style="width: 90px;">Tổng kết</th>
                            <th style="width: 50px;">Chữ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $stt = 1; foreach($theses as $dt): 
                            $diemHD = $dt['diemHuongDan'] !== null ? floatval($dt['diemHuongDan']) : 0;
                            $diemPB = $dt['diemPhanBien'] !== null ? floatval($dt['diemPhanBien']) : 0;
                            
                            $showHD = $dt['diemHuongDan'] !== null ? $dt['diemHuongDan'] : '-';
                            $showPB = $dt['diemPhanBien'] !== null ? $dt['diemPhanBien'] : '-';
                        ?>
                        <tr class="row-score">
                            <td style="font-weight: bold; color: #94a3b8;"><?= $stt++ ?></td>
                            <td class="text-left">
                                <div style="font-weight: bold; color: #2563eb; margin-bottom: 5px; font-size: 14px;"><?= htmlspecialchars($dt['tenDeTai']) ?></div>
                                <div style="font-size: 12px; line-height: 1.5; color: #475569;">
                                    <?= $dt['dsSinhVien'] ?>
                                </div>
                            </td>
                            
                            <td class="hd-score" style="color: #64748b;"><?= $showHD ?></td>
                            <td class="pb-score" style="color: #64748b;"><?= $showPB ?></td>
                            
                            <td style="background: #fff7ed;">
                                <input type="number" 
                                       class="council-input"
                                       name="scores[<?= $dt['maDeTai'] ?>][diem]" 
                                       value="<?= $dt['diemHoiDong'] ?>" 
                                       step="0.01" min="0" max="10" 
                                       placeholder="0.0"
                                       data-hd="<?= $diemHD ?>"
                                       data-pb="<?= $diemPB ?>"
                                >
                            </td>
                            <td>
                                <textarea name="scores[<?= $dt['maDeTai'] ?>][nx]" rows="3" placeholder="Nhập nhận xét..."><?= htmlspecialchars($dt['nhanXetHoiDong'] ?? '') ?></textarea>
                            </td>
                            
                            <td class="final-score" style="font-weight:bold; font-size:16px; color:#2563eb;">
                                <?= $dt['diemTongKet'] !== null ? number_format($dt['diemTongKet'], 1) : '--' ?>
                            </td>
                            <td class="final-char" style="font-weight: bold; font-size: 15px; color: <?= ($dt['diemChu'] == 'F') ? '#ef4444' : '#10b981' ?>">
                                <?= $dt['diemChu'] ?? '' ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <div style="margin-top: 30px; text-align: right;">
                    <button type="submit" class="button" style="background: #2563eb; color: white; padding: 12px 30px; border: none; border-radius: 6px; font-weight: bold; cursor: pointer; box-shadow: 0 4px 6px -1px rgba(37, 99, 235, 0.3);">
                        <i class="fa-solid fa-save"></i> Lưu & Tính Điểm
                    </button>
                </div>
            </form>
        </div>
    <?php endif; ?>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const inputs = document.querySelectorAll('.council-input');

            inputs.forEach(input => {
                input.addEventListener('input', function() {
                    const row = this.closest('tr');
                    const finalScoreEl = row.querySelector('.final-score');
                    const finalCharEl = row.querySelector('.final-char');

                    const hd = parseFloat(this.dataset.hd) || 0;
                    const pb = parseFloat(this.dataset.pb) || 0;
                    const hdong = parseFloat(this.value) || 0;

                    let total = (hd * 0.2) + (pb * 0.2) + (hdong * 0.6);
                    
                    total = Math.round(total * 10) / 10;

                    finalScoreEl.textContent = total.toFixed(1);

                    let char = 'F';
                    let color = '#ef4444'; 

                    if (total >= 9.0) char = 'A+';
                    else if (total >= 8.5) char = 'A';
                    else if (total >= 8.0) char = 'B+';
                    else if (total >= 7.0) char = 'B';
                    else if (total >= 6.5) char = 'C+';
                    else if (total >= 5.5) char = 'C';
                    else if (total >= 5.0) char = 'D+';
                    else if (total >= 4.0) char = 'D';

                    if (char !== 'F') color = '#10b981';

                    finalCharEl.textContent = char;
                    finalCharEl.style.color = color;
                });
            });
        });
    </script>
</body>
</html>