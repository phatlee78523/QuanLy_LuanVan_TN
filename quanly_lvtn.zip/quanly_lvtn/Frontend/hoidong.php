<?php
session_start();
if (!isset($_SESSION["dangnhap"]) || $_SESSION["dangnhap"] !== true) {
    header("location: dangnhap.html");
    exit;
}
require '../backend/db.php';


$lecturers = $pdo->query("SELECT maGV, tenGV FROM GiangVien ORDER BY tenGV ASC")->fetchAll();

$sql_hoidong = "
    SELECT 
        H.maHoiDong, H.tenHoiDong, H.diaDiem,
        (SELECT gv.tenGV FROM ThanhVienHoiDong tv JOIN GiangVien gv ON tv.maGV = gv.maGV WHERE tv.maHoiDong = H.maHoiDong AND tv.vaiTro = 'ChuTich' LIMIT 1) AS tenChuTich,
        (SELECT tv.maGV FROM ThanhVienHoiDong tv WHERE tv.maHoiDong = H.maHoiDong AND tv.vaiTro = 'ChuTich' LIMIT 1) AS maChuTich,
        (SELECT gv.tenGV FROM ThanhVienHoiDong tv JOIN GiangVien gv ON tv.maGV = gv.maGV WHERE tv.maHoiDong = H.maHoiDong AND tv.vaiTro = 'ThuKy' ORDER BY tv.id ASC LIMIT 1) AS tenThuKy1,
        (SELECT tv.maGV FROM ThanhVienHoiDong tv WHERE tv.maHoiDong = H.maHoiDong AND tv.vaiTro = 'ThuKy' ORDER BY tv.id ASC LIMIT 1) AS maThuKy1,
        (SELECT gv.tenGV FROM ThanhVienHoiDong tv JOIN GiangVien gv ON tv.maGV = gv.maGV WHERE tv.maHoiDong = H.maHoiDong AND tv.vaiTro = 'ThuKy' ORDER BY tv.id ASC LIMIT 1 OFFSET 1) AS tenThuKy2,
        (SELECT tv.maGV FROM ThanhVienHoiDong tv WHERE tv.maHoiDong = H.maHoiDong AND tv.vaiTro = 'ThuKy' ORDER BY tv.id ASC LIMIT 1 OFFSET 1) AS maThuKy2,
        (SELECT gv.tenGV FROM ThanhVienHoiDong tv JOIN GiangVien gv ON tv.maGV = gv.maGV WHERE tv.maHoiDong = H.maHoiDong AND tv.vaiTro = 'UyVien' LIMIT 1) AS tenUyVien,
        (SELECT tv.maGV FROM ThanhVienHoiDong tv WHERE tv.maHoiDong = H.maHoiDong AND tv.vaiTro = 'UyVien' LIMIT 1) AS maUyVien
    FROM HoiDong H
    ORDER BY H.tenHoiDong ASC
";
$hoiDongList = $pdo->query($sql_hoidong)->fetchAll(PDO::FETCH_ASSOC);

$sql_detai = "SELECT dt.maDeTai, dt.tenDeTai, dt.maHoiDong, gv.tenGV as tenGVHD, (SELECT GROUP_CONCAT(CONCAT(sv.hoTen, ' (', sv.mssv, ')') SEPARATOR '<br>') FROM SinhVien sv WHERE sv.maDeTai = dt.maDeTai) AS dsSinhVien FROM DeTai dt LEFT JOIN GiangVien gv ON dt.maGV_HD = gv.maGV WHERE dt.maHoiDong IS NOT NULL";
$allDeTai = $pdo->query($sql_detai)->fetchAll(PDO::FETCH_ASSOC);
$detaiByHoiDong = [];
foreach ($allDeTai as $dt) { $detaiByHoiDong[$dt['maHoiDong']][] = $dt; }

$sql_filter = "
    SELECT maDeTai, tenDeTai 
    FROM DeTai 
    WHERE maHoiDong IS NULL 
    AND maGV_HD IS NOT NULL
    AND (trangThaiGiuaKy = 'Được làm tiếp' OR trangThaiGiuaKy IS NULL OR trangThaiGiuaKy != 'Đình chỉ')
";

$sql_strict = "
    SELECT maDeTai, tenDeTai 
    FROM DeTai 
    WHERE maHoiDong IS NULL 
    AND maGV_HD IS NOT NULL
    AND trangThaiGiuaKy = 'Được làm tiếp'
";

$luanVanChuaCB = $pdo->query($sql_strict)->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản lý Hội đồng</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="../style/style.css">
    <link rel="stylesheet" href="../style/hoidong.css">
</head>
<body>
    <div class="app-layout">
        <header class="header">
            <div style="display: flex; align-items: center; gap: 15px;">
                <a href="index.php" style="color: #64748b; font-size: 18px;"><i class="fa-solid fa-arrow-left"></i></a>
                <h2 style="margin:0; font-size: 18px; color: #1e293b;">Quản lý Hội đồng LVTN</h2>
            </div>
        </header>

        <div class="main-content-wrapper">
            <main class="content">
                <div class="toolbar" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                    <p style="margin:0;color:#64748b;">Danh sách các hội đồng.</p>
                    <div style="display: flex; gap: 10px;">
                        <button id="add-hD-btn" class="primary"><i class="fa-solid fa-plus"></i> Tạo Hội đồng</button>
                        <a href="../backend/export_hoidong.php" class="button" style="background:#10b981;color:white;padding:8px 15px;border-radius:6px;text-decoration:none;"><i class="fa-solid fa-file-excel"></i> Export Excel</a>
                    </div>
                </div>

                <div class="council-grid">
                    <?php foreach ($hoiDongList as $hD): ?>
                    <div class="council-card">
                        <div class="card-header">
                            <h3 style="margin:0;font-size:16px;"><?= htmlspecialchars($hD['tenHoiDong']) ?></h3>
                            <span style="font-size:12px;background:#fff;padding:3px 8px;border:1px solid #ccc;border-radius:12px;"><?= htmlspecialchars($hD['diaDiem']) ?></span>
                        </div>
                        <div class="card-body">
                            <div style="margin-bottom: 15px;">
                                <div class="member-line"><span style="font-weight:bold;color:#d32f2f;">Chủ tịch:</span> <span><?= htmlspecialchars($hD['tenChuTich'] ?? '---') ?></span></div>
                                <div class="member-line"><span style="font-weight:bold;color:#1976d2;">Thư ký 1:</span> <span><?= htmlspecialchars($hD['tenThuKy1'] ?? '---') ?></span></div>
                                <div class="member-line"><span style="font-weight:bold;color:#1976d2;">Thư ký 2:</span> <span><?= htmlspecialchars($hD['tenThuKy2'] ?? '---') ?></span></div>
                                <div class="member-line"><span style="font-weight:bold;color:#388e3c;">Ủy viên:</span> <span><?= htmlspecialchars($hD['tenUyVien'] ?? '---') ?></span></div>
                            </div>
                            <h4 style="font-size:12px;text-transform:uppercase;color:#94a3b8;border-bottom:1px solid #eee;padding-bottom:5px;">Đề tài</h4>
                            <?php $dsDeTai = $detaiByHoiDong[$hD['maHoiDong']] ?? []; ?>
                            <?php if (count($dsDeTai) > 0): foreach ($dsDeTai as $dt): ?>
                                <div style="background:#fff;border:1px dashed #e2e8f0;padding:8px;margin-bottom:8px;border-radius:6px;">
                                    <div style="font-weight:bold;color:#2563eb;font-size:13px;"><?= htmlspecialchars($dt['tenDeTai']) ?></div>
                                    <div style="color:#64748b;font-size:12px;">SV: <?= $dt['dsSinhVien'] ?></div>
                                </div>
                            <?php endforeach; else: ?>
                                <div style="text-align:center;color:#ccc;font-style:italic;">Trống</div>
                            <?php endif; ?>
                        </div>
                        <div class="card-footer">
                            <button class="edit-council-btn" style="padding:5px 10px;border:1px solid #ccc;background:#fff;border-radius:4px;cursor:pointer;"
                                data-id="<?= $hD['maHoiDong'] ?>"
                                data-ten="<?= htmlspecialchars($hD['tenHoiDong']) ?>"
                                data-diadiem="<?= htmlspecialchars($hD['diaDiem']) ?>"
                                data-chutich="<?= $hD['maChuTich'] ?>"
                                data-thuky1="<?= $hD['maThuKy1'] ?>"
                                data-thuky2="<?= $hD['maThuKy2'] ?>"
                                data-uyvien="<?= $hD['maUyVien'] ?>">
                                <i class="fa-solid fa-pen"></i> Sửa
                            </button>
                            <form action="../backend/actions.php" method="post" onsubmit="return confirm('Xóa?');" style="margin:0;display:inline;">
                                <input type="hidden" name="action" value="delete_hoidong">
                                <input type="hidden" name="maHoiDong" value="<?= $hD['maHoiDong'] ?>">
                                <button type="submit" style="padding:5px 10px;border:1px solid #fee2e2;background:#fee2e2;color:#ef4444;border-radius:4px;cursor:pointer;"><i class="fa-solid fa-trash"></i></button>
                            </form>
                            <button class="assign-luanVan-btn" data-mahoidong="<?= $hD['maHoiDong'] ?>" style="padding:5px 10px;background:#e0f2fe;color:#0284c7;border:1px solid #bae6fd;border-radius:4px;cursor:pointer;">+ Đề tài</button>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </main>
        </div>
    </div>

    <div id="themModalHD" class="modal-overlay">
        <div class="modal-content">
            <h2>Tạo Hội đồng</h2>
            <form action="../backend/actions.php" method="post">
                <input type="hidden" name="action" value="add_hoidong">
                <div class="form-group"><label>Tên</label><input type="text" name="tenHoiDong" required></div>
                <div class="form-group"><label>Địa điểm</label><input type="text" name="diaDiem" required></div>
                <div class="form-group"><label>Chủ tịch</label><select name="chuTich" required><option value="">-- Chọn --</option><?php foreach($lecturers as $gv) echo "<option value='{$gv['maGV']}'>{$gv['tenGV']}</option>"; ?></select></div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
                    <div class="form-group"><label>Thư ký 1</label><select name="thuKy1" required><option value="">-- Chọn --</option><?php foreach($lecturers as $gv) echo "<option value='{$gv['maGV']}'>{$gv['tenGV']}</option>"; ?></select></div>
                    <div class="form-group"><label>Thư ký 2</label><select name="thuKy2"><option value="">-- Chọn (Tùy chọn) --</option><?php foreach($lecturers as $gv) echo "<option value='{$gv['maGV']}'>{$gv['tenGV']}</option>"; ?></select></div>
                </div>
                <div class="form-group"><label>Ủy viên</label><select name="uyVien" required><option value="">-- Chọn --</option><?php foreach($lecturers as $gv) echo "<option value='{$gv['maGV']}'>{$gv['tenGV']}</option>"; ?></select></div>
                <div class="modal-actions"><button type="button" class="btn-cancel">Hủy</button><button type="submit" class="primary">Lưu</button></div>
            </form>
        </div>
    </div>

    <div id="editModalHD" class="modal-overlay">
        <div class="modal-content">
            <h2>Sửa Hội đồng</h2>
            <form action="../backend/actions.php" method="post">
                <input type="hidden" name="action" value="update_hoidong">
                <input type="hidden" id="edit_maHoiDong" name="maHoiDong">
                <div class="form-group"><label>Tên</label><input type="text" id="edit_tenHoiDong" name="tenHoiDong" required></div>
                <div class="form-group"><label>Địa điểm</label><input type="text" id="edit_diaDiem" name="diaDiem" required></div>
                <div class="form-group"><label>Chủ tịch</label><select id="edit_chuTich" name="chuTich" required><option value="">-- Chọn --</option><?php foreach($lecturers as $gv) echo "<option value='{$gv['maGV']}'>{$gv['tenGV']}</option>"; ?></select></div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
                    <div class="form-group"><label>Thư ký 1</label><select id="edit_thuKy1" name="thuKy1" required><option value="">-- Chọn --</option><?php foreach($lecturers as $gv) echo "<option value='{$gv['maGV']}'>{$gv['tenGV']}</option>"; ?></select></div>
                    <div class="form-group"><label>Thư ký 2</label><select id="edit_thuKy2" name="thuKy2"><option value="">-- Chọn (Tùy chọn) --</option><?php foreach($lecturers as $gv) echo "<option value='{$gv['maGV']}'>{$gv['tenGV']}</option>"; ?></select></div>
                </div>
                <div class="form-group"><label>Ủy viên</label><select id="edit_uyVien" name="uyVien" required><option value="">-- Chọn --</option><?php foreach($lecturers as $gv) echo "<option value='{$gv['maGV']}'>{$gv['tenGV']}</option>"; ?></select></div>
                <div class="modal-actions"><button type="button" class="btn-cancel">Hủy</button><button type="submit" class="primary">Cập nhật</button></div>
            </form>
        </div>
    </div>

    <div id="modalLuanVan" class="modal-overlay">
        <div class="modal-content">
            <h2>Gán Đề tài</h2>
            <form action="../backend/actions.php" method="post">
                <input type="hidden" name="action" value="assign_detai_to_hoidong">
                <input type="hidden" id="assign_detai_mahoidong" name="maHoiDong">
                <div class="form-group"><label>Chọn Đề tài</label>
                    <select name="maDeTai" required style="width:100%;height:150px;" multiple>
                        <?php foreach($luanVanChuaCB as $lv): ?>
                            <option value="<?= $lv['maDeTai'] ?>"><?= htmlspecialchars($lv['tenDeTai']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="modal-actions"><button type="button" class="btn-cancel">Hủy</button><button type="submit" class="primary">Gán</button></div>
            </form>
        </div>
    </div>

    <script>
        // Xử lý đóng/mở Modal
        const addM = document.getElementById('themModalHD');
        const editM = document.getElementById('editModalHD');
        const assignM = document.getElementById('modalLuanVan');
        
        function closeM() { 
            if(addM) addM.classList.remove('active'); 
            if(editM) editM.classList.remove('active'); 
            if(assignM) assignM.classList.remove('active'); 
        }

        // Gán sự kiện click cho nút đóng
        document.querySelectorAll('.btn-cancel').forEach(b => b.addEventListener('click', (e) => { e.preventDefault(); closeM(); }));
        
        // Nút Mở Modal Thêm
        const addBtn = document.getElementById('add-hD-btn');
        if(addBtn) addBtn.addEventListener('click', () => addM.classList.add('active'));

        // Nút Mở Modal Sửa
        document.querySelectorAll('.edit-council-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.getElementById('edit_maHoiDong').value = btn.dataset.id;
                document.getElementById('edit_tenHoiDong').value = btn.dataset.ten;
                document.getElementById('edit_diaDiem').value = btn.dataset.diadiem;
                document.getElementById('edit_chuTich').value = btn.dataset.chutich;
                document.getElementById('edit_thuKy1').value = btn.dataset.thuky1;
                document.getElementById('edit_thuKy2').value = btn.dataset.thuky2;
                document.getElementById('edit_uyVien').value = btn.dataset.uyvien;
                editM.classList.add('active');
            });
        });

        // Nút Mở Modal Gán Đề tài
        document.querySelectorAll('.assign-luanVan-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.getElementById('assign_detai_mahoidong').value = btn.dataset.mahoidong;
                assignM.classList.add('active');
            });
        });

        // Xử lý chống chọn trùng giảng viên (Chạy an toàn)
        function setupDuplicatePrevention(modalId) {
            const modal = document.getElementById(modalId);
            if (!modal) return; // Nếu không tìm thấy modal thì bỏ qua

            const selects = modal.querySelectorAll('select');
            
            function updateOptions() {
                const selectedValues = [];
                // Lấy danh sách đã chọn
                selects.forEach(sel => {
                    if (sel.value) selectedValues.push(sel.value);
                });

                // Cập nhật từng select
                selects.forEach(sel => {
                    const currentVal = sel.value;
                    Array.from(sel.options).forEach(opt => {
                        if (selectedValues.includes(opt.value) && opt.value !== currentVal && opt.value !== "") {
                            opt.disabled = true;
                            opt.style.color = '#ccc';
                            if (!opt.text.includes('(Đã chọn)')) opt.text += ' (Đã chọn)';
                        } else {
                            opt.disabled = false;
                            opt.style.color = '#000';
                            opt.text = opt.text.replace(' (Đã chọn)', '');
                        }
                    });
                });
            }

            // Gán sự kiện change
            selects.forEach(sel => sel.addEventListener('change', updateOptions));
            
            // Theo dõi khi modal mở để update lại
            const observer = new MutationObserver((mutations) => {
                mutations.forEach((mutation) => {
                    if (mutation.attributeName === "class" && modal.classList.contains('active')) {
                        updateOptions();
                    }
                });
            });
            observer.observe(modal, { attributes: true });
        }

        // Kích hoạt chống trùng
        setupDuplicatePrevention('themModalHD');
        setupDuplicatePrevention('editModalHD');
    </script>
</body>
</html>