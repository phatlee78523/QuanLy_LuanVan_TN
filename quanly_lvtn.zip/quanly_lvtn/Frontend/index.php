<?php
session_start();
if (!isset($_SESSION["dangnhap"]) || $_SESSION["dangnhap"] !== true) { header("location: dangnhap.html"); exit; }
require '../backend/db.php';

$isAdmin = ($_SESSION['role'] == 'admin');
$config = $pdo->query("SELECT giaiDoan FROM CauHinh WHERE id = 1")->fetch();
$currentStage = $config['giaiDoan'] ?? 1;

$stats = ['sv' => 0, 'dt' => 0, 'hd' => 0];
if ($isAdmin) {
    try {
        $stats['sv'] = $pdo->query("SELECT COUNT(*) FROM SinhVien")->fetchColumn();
        $stats['dt'] = $pdo->query("SELECT COUNT(*) FROM DeTai")->fetchColumn();
        $checkHD = $pdo->query("SHOW TABLES LIKE 'HoiDong'")->rowCount();
        if ($checkHD > 0) $stats['hd'] = $pdo->query("SELECT COUNT(*) FROM HoiDong")->fetchColumn();
    } catch (Exception $e) {}
}

$menus = [
    ['step' => 1, 'label' => 'Nhập liệu',    'link' => 'sinhvien.php',       'icon' => 'user-plus',        'admin' => true],
    ['step' => 2, 'label' => 'Phân công GV', 'link' => $isAdmin ? 'phanconggv.php' : 'sinhvienphancong.php', 'icon' => 'chalkboard-user', 'admin' => false],
    ['step' => 3, 'label' => 'Giữa kỳ',      'link' => $isAdmin ? 'trangthaigk.php' : 'ds_sinhvien_gv.php', 'icon' => 'file-pen',        'admin' => false],
    ['step' => 4, 'label' => 'Phản biện',    'link' => $isAdmin ? 'phancong_pb.php' : 'chamdiem_pb.php',   'icon' => 'people-arrows',   'admin' => false],
    ['step' => 5, 'label' => 'Hội đồng',   'link' => $isAdmin ? 'hoidong.php' : 'chamdiem_hoidong.php',  'icon' => 'gavel',           'admin' => false]
];

function getMenuClass($step, $current) {
    if ($step < $current) return 'completed';
    if ($step == $current) return 'active';
    return 'disabled';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Hệ thống Quản lý Khóa luận</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="icon" type="image/png" href="../images/STU.webp" />
    <link rel="stylesheet" href="../style/style.css">
    <link rel="stylesheet" href="../style/index.css">    
</head>
<body>
    <div class="app-container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <img src="../images/STU.webp" alt="Logo"> <h3>Quản lý LVTN</h3>
            </div>
            
            <nav class="sidebar-menu">
                <div class="menu-label">Tổng quan</div>
                <div class="menu-item active" onclick="resetView()">
                    <span class="icon-box"><i class="fa-solid fa-house"></i></span> 
                    <span>Dashboard</span>
                </div>

                <div class="menu-label">Quy trình (Giai đoạn: <?= $currentStage ?>)</div>
                <?php foreach ($menus as $m): ?>
                    <?php if ($m['admin'] && !$isAdmin) continue; ?>
                    <div class="menu-item <?= getMenuClass($m['step'], $currentStage) ?>" onclick="loadFrame('<?= $m['link'] ?>', this)">
                        <span class="icon-box"><i class="fa-solid fa-<?= $m['icon'] ?>"></i></span>
                        <span><?= $m['label'] ?></span>
                        <?php if($currentStage > $m['step']): ?>
                            <i class="fa-solid fa-check" style="margin-left:auto; font-size:12px;"></i>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </nav>

            <div class="user-profile">
                <div><div class="user-info"><?= $_SESSION['username'] ?></div><div class="user-role"><?= $isAdmin ? 'Admin' : 'Giảng viên' ?></div></div>
                <a href="../backend/dangxuat.php" class="btn-logout"><i class="fa-solid fa-right-from-bracket"></i></a>
            </div>
        </aside>

        <main class="main-content">
            <div id="dashboard-overview" class="dashboard-container">
                <div class="welcome-banner">
                    <h2 style="margin:0 0 10px;">Xin chào, <?= $_SESSION['username'] ?>!</h2>
                    <p style="margin:0; opacity: 0.9;">Giai đoạn hiện tại: <strong> <?= $currentStage ?></strong></p>
                </div>

                <?php if ($isAdmin): ?>
                    <div class="stats-grid">
                        <div class="stat-card"><div class="stat-icon bg-blue"><i class="fa-solid fa-users"></i></div><div><h3><?= $stats['sv'] ?></h3><span>Sinh viên</span></div></div>
                        <div class="stat-card"><div class="stat-icon bg-green"><i class="fa-solid fa-book"></i></div><div><h3><?= $stats['dt'] ?></h3><span>Đề tài</span></div></div>
                        <div class="stat-card"><div class="stat-icon bg-orange"><i class="fa-solid fa-gavel"></i></div><div><h3><?= $stats['hd'] ?></h3><span>Hội đồng</span></div></div>
                        <div class="stat-card"><div class="stat-icon bg-purple"><i class="fa-solid fa-calendar-check"></i></div><div><h3><?= $currentStage ?>/5</h3><span>Tiến độ</span></div></div>
                    </div>

                    <div class="control-panel">
                        <h3 style="margin-top:0;">Điều khiển Tiến độ</h3>
                        <form action="../backend/actions.php" method="POST">
                            <input type="hidden" name="action" value="update_stage">
                            <?php if ($currentStage < 5): ?>
                                <button type="submit" name="next_stage" value="<?= $currentStage + 1 ?>" class="btn-next" onclick="return confirm('Xác nhận chuyển giai đoạn?');">Mở khóa Tuần tiếp theo <i class="fa-solid fa-arrow-right"></i></button>
                            <?php else: ?>
                                <button type="button" disabled class="btn-next"><i class="fa-solid fa-check"></i> Hoàn tất</button>
                            <?php endif; ?>
                            <button type="submit" name="reset_stage" value="1" class="btn-reset" onclick="return confirm('Reset về Tuần 1?');"><i class="fa-solid fa-rotate-left"></i> Reset</button>
                        </form>
                    </div>
                <?php else: ?>
                    <div style="text-align:center; padding: 50px; background:white; border-radius:10px; border:1px solid #e2e8f0;">
                        <img src="https://cdn-icons-png.flaticon.com/512/7486/7486744.png" width="100" style="opacity:0.6; margin-bottom:20px;">
                        <h3 style="color:#475569;">Khu vực làm việc của Giảng viên</h3>
                        <p style="color:#94a3b8;">Vui lòng chọn chức năng từ menu bên trái.</p>
                    </div>
                <?php endif; ?>
            </div>

            <div id="workspace-wrapper">
                <iframe id="main-frame" name="main-frame" src=""></iframe>
            </div>
        </main>
    </div>

    <script>
        const overview = document.getElementById('dashboard-overview');
        const workspace = document.getElementById('workspace-wrapper');
        const frame = document.getElementById('main-frame');
        
        function loadFrame(url, el) {
            if (el.classList.contains('disabled')) return;

            document.querySelectorAll('.menu-item').forEach(item => item.classList.remove('active'));
            el.classList.add('active');

            overview.style.display = 'none';
            workspace.classList.add('show');
            frame.src = url;
        }

        function resetView() {
            overview.style.display = 'block';
            workspace.classList.remove('show');
            frame.src = ""; 
            document.querySelectorAll('.menu-item').forEach(item => item.classList.remove('active'));
            document.querySelector('.menu-item:first-child').classList.add('active');
        }

        frame.onload = function() {
            try {
                const doc = frame.contentDocument || frame.contentWindow.document;
                
                let customCSS = `
                    html, body { background-color: #f1f5f9 !important; margin: 0 !important; padding: 0 !important; }
                    .app-layout, .main-content-wrapper, .content, .container { width: 100% !important; max-width: 100% !important; margin: 0 !important; padding: 20px !important; box-shadow: none !important; min-height: 100vh !important; }
                    /* Ẩn các nút back thừa nếu có */
                    .back-btn, .quick-logout { display: none !important; }
                `;

                const activeItem = document.querySelector('.menu-item.active');
                if (activeItem && activeItem.classList.contains('completed')) {
                    customCSS += `
                        button[type="submit"]:not(.primary), .btn-save, .btn-update, .btn-delete, button.success {
                            display: none !important;
                        }
                        
                        input:not([type="hidden"]), textarea, select {
                            pointer-events: none !important;
                            background-color: #f3f4f6 !important;
                            color: #64748b !important;
                            border: 1px solid #e2e8f0 !important;
                        }

                        body::before {
                            content: "BẠN CHỈ ĐƯỢC XEM TRANG NÀY, VÌ ĐÃ QUA GIAI ĐOẠN";
                            display: block;
                            background: #fff7ed; color: #c2410c;
                            text-align: center; padding: 8px;
                            font-weight: bold; font-family: sans-serif; font-size: 13px;
                            border-bottom: 1px solid #fdba74;
                        }
                    `;
                }

                const style = doc.createElement('style');
                style.textContent = customCSS;
                doc.head.appendChild(style);

            } catch(e) {
                console.log('Lỗi CSS Iframe (có thể do cross-origin nếu khác domain): ' + e.message);
            }
        }
    </script>
</body>
</html>