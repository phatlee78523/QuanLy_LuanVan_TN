<?php
session_start();
// Kiểm tra đăng nhập và quyền Admin
if (!isset($_SESSION["dangnhap"]) || $_SESSION["dangnhap"] !== true) {
    header("location: dangnhap.html");
    exit;
}
if (isset($_SESSION['role']) && $_SESSION['role'] != 'admin') {
    header("location: index.php");
    exit;
}

require '../backend/db.php';

// 1. Lấy danh sách Giảng viên
$lecturers = $pdo->query("SELECT maGV, tenGV FROM GiangVien ORDER BY tenGV ASC")->fetchAll();

// 2. Lấy danh sách Đề tài
$sql = "
    SELECT 
        dt.maDeTai, dt.tenDeTai, dt.maMH,
        gv1.tenGV AS tenGVHD, dt.maGV_HD,
        gv2.tenGV AS tenGVPB, dt.maGV_PB, 
        dt.ghiChu_PB,
        (SELECT GROUP_CONCAT(CONCAT(sv.hoTen, '<br>') SEPARATOR '') 
         FROM SinhVien sv WHERE sv.maDeTai = dt.maDeTai) AS thanhVien
    FROM DeTai dt
    LEFT JOIN GiangVien gv1 ON dt.maGV_HD = gv1.maGV 
    LEFT JOIN GiangVien gv2 ON dt.maGV_PB = gv2.maGV 
    WHERE dt.maGV_HD IS NOT NULL 
    ORDER BY dt.maMH ASC
";
$theses = $pdo->query($sql)->fetchAll();
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Phân công Phản biện</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="icon" type="image/png" href="../images/STU.webp" />
    <link rel="stylesheet" href="../style/style.css">
    <link rel="stylesheet" href="../style/phancong_pb.css">
</head>
<body>
    <div class="app-layout">
        
        <header class="header">
            <div style="display: flex; align-items: center; gap: 15px;">
                <a href="index.php" style="color: #64748b; font-size: 18px; text-decoration: none;">
                    <i class="fa-solid fa-arrow-left"></i>
                </a>
                <h2 style="margin:0; font-size: 18px; color: #1e293b;">Phân công Giảng viên Phản biện</h2>
            </div>
        </header>

        <div class="main-content-wrapper">
            <main class="content">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                    <p style="color: #64748b; margin: 0;">Danh sách các nhóm đã có GVHD, cần phân công GVPB.</p>
                    <a href="../backend/export_pb.php" class="btn-assign" style="background: #10b981;">
                        <i class="fa-solid fa-file-excel"></i> Xuất Excel
                    </a>
                </div>

                <table>
                    <thead>
                        <tr>
                            <th style="width: 60px;">Nhóm</th>
                            <th>Tên Đề tài</th>
                            <th>Thành viên</th>
                            <th>GV Hướng dẫn (HD)</th>
                            <th>GV Phản biện (PB)</th>
                            <th>Ghi chú</th>
                            <th style="width: 120px; text-align: center;">Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($theses as $row): ?>
                        <tr>
                            <td style="text-align: center; font-weight: bold;"><?= htmlspecialchars($row['maMH'] ?? $row['maDeTai']) ?></td>
                            <td><?= htmlspecialchars($row['tenDeTai']) ?></td>
                            <td style="font-size: 12px;"><?= $row['thanhVien'] ?></td>
                            
                            <td>
                                <span class="badge bg-gray"><i class="fa-solid fa-user-tie"></i> <?= htmlspecialchars($row['tenGVHD']) ?></span>
                            </td>

                            <td>
                                <?php if ($row['tenGVPB']): ?>
                                    <span class="badge bg-green"><i class="fa-solid fa-user-shield"></i> <?= htmlspecialchars($row['tenGVPB']) ?></span>
                                <?php else: ?>
                                    <span class="badge" style="background: #fee2e2; color: #ef4444;">Chưa phân công</span>
                                <?php endif; ?>
                            </td>
                            
                            <td><?= htmlspecialchars($row['ghiChu_PB'] ?? '') ?></td>

                            <td style="text-align: center;">
                                <button class="btn-assign" 
                                    onclick="openModal(
                                        '<?= $row['maDeTai'] ?>', 
                                        '<?= $row['maGV_PB'] ?? '' ?>', 
                                        '<?= htmlspecialchars($row['ghiChu_PB'] ?? '') ?>',
                                        '<?= $row['maGV_HD'] ?>' 
                                    )">
                                    <i class="fa-solid fa-pen"></i> Phân công
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </main>
        </div>
    </div>

    <div id="assign-modal" class="modal-overlay">
        <div class="modal-content">
            <h3 style="margin-top: 0; color: #1e293b;">Phân công Phản biện</h3>
            <form action="../backend/actions.php" method="post">
                <input type="hidden" name="action" value="assign_reviewer">
                <input type="hidden" id="modal_madetai" name="maDeTai">
                
                <div class="form-group">
                    <label>Chọn Giảng viên Phản biện:</label>
                    <select id="modal_magv" name="maGV_PB" required>
                        <option value="">-- Chọn Giảng viên --</option>
                        <?php foreach($lecturers as $gv): ?>
                            <option value="<?= $gv['maGV'] ?>"><?= htmlspecialchars($gv['tenGV']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <p style="margin: 5px 0 0 0; font-size: 11px; color: #ef4444; font-style: italic;">
                        * GVHD của nhóm này sẽ bị khóa không cho chọn.
                    </p>
                </div>
                
                <div class="form-group">
                    <label>Ghi chú (Tùy chọn):</label>
                    <input type="text" id="modal_ghichu" name="ghiChu_PB" placeholder="Nhập ghi chú...">
                </div>
                
                <div class="modal-actions">
                    <button type="button" class="btn-modal btn-cancel" onclick="closeModal()">Hủy</button>
                    <button type="submit" class="btn-modal btn-save">Lưu lại</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        const modal = document.getElementById('assign-modal');
        const selectBox = document.getElementById('modal_magv');

        function openModal(maDeTai, currentGVPB, ghiChu, maGVHD) {
            document.getElementById('modal_madetai').value = maDeTai;
            document.getElementById('modal_ghichu').value = ghiChu;
            
            const options = selectBox.options;
            for (let i = 0; i < options.length; i++) {
                options[i].disabled = false;
                options[i].text = options[i].text.replace(' (GVHD - Không chọn)', '');
                options[i].style.color = '#000';

                if (options[i].value == maGVHD) {
                    options[i].disabled = true;
                    options[i].text += ' (GVHD - Không chọn)';
                    options[i].style.color = '#ccc';
                }
            }
            selectBox.value = currentGVPB;
            modal.classList.add('active');
        }

        function closeModal() {
            modal.classList.remove('active');
        }

        window.onclick = function(event) {
            if (event.target == modal) closeModal();
        }
    </script>
</body>
</html>