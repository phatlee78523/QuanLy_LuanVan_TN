<?php
session_start();
if (!isset($_SESSION["dangnhap"]) || $_SESSION["dangnhap"] !== true) { header("location: dangnhap.html"); exit; }
require '../backend/db.php';

$currentUser = $_SESSION['username'];

$stmt_gv = $pdo->prepare("SELECT maGV FROM GiangVien WHERE maGV = ? OR tenGV = ? OR email = ?");
$stmt_gv->execute([$currentUser, $currentUser, $currentUser]);
$gvInfo = $stmt_gv->fetch();
$maGV = $gvInfo ? $gvInfo['maGV'] : $currentUser;

$sql_groups = "
    SELECT dt.maDeTai, dt.tenDeTai, gv.tenGV,
           (SELECT GROUP_CONCAT(sv.hoTen SEPARATOR ', ') FROM SinhVien sv WHERE sv.maDeTai = dt.maDeTai) AS dsSinhVien
    FROM DeTai dt
    LEFT JOIN GiangVien gv ON dt.maGV_HD = gv.maGV
    WHERE dt.maGV_HD = ? 
    ORDER BY dt.tenDeTai ASC
";
$stmt = $pdo->prepare($sql_groups);
$stmt->execute([$maGV]);
$groups = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Chấm điểm Hướng dẫn</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="../style/style.css">
    <link rel="stylesheet" href="../style/chamdiem.css">
    <style>
        body { background-color: #fff; padding: 20px; }
        .switcher { display: flex; justify-content: flex-end; margin-bottom: 20px; }
        .switcher a { padding: 8px 15px; border-radius: 5px; font-weight: 600; font-size: 13px; text-decoration: none; border: 1px solid #ccc; background: #f8fafc; color: #64748b; }
        .switcher a.active { background: #2563eb; color: white; border-color: #2563eb; }

        .no-data { text-align: center; color: #ef4444; font-weight: bold; margin-top: 20px; padding: 20px; background: #fef2f2; border-radius: 8px; border: 1px dashed #fecaca; }

        .form-group label { font-weight: 600; margin-bottom: 5px; display: block; }
        .common-scale, .student-divider { background: #f8fafc; padding: 15px; border-radius: 8px; border: 1px solid #e2e8f0; margin-bottom: 20px; }
        .grade-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; }
        input[type="number"], select, textarea { width: 100%; padding: 8px; border: 1px solid #cbd5e1; border-radius: 4px; }
        hr { border: 0; border-top: 1px solid #eee; margin: 20px 0; }
    </style>
</head>
<body>
    <div class="switcher">
        <a href="chamdiem_pb.php" style="margin-right: 10px;">Chấm Phản Biện</a>
        <a href="chamdiem.php" class="active">Chấm Hướng Dẫn</a>
    </div>

    <h2 style="color: #1e293b; border-bottom: 2px solid #e2e8f0; padding-bottom: 10px;">
        <i class="fa-solid fa-chalkboard-user"></i> Giảng Viên Hướng Dẫn Chấm Điểm
    </h2>
    
    <?php if(empty($groups)): ?>
        <div class="no-data">
            <i class="fa-solid fa-circle-exclamation"></i> Không tìm thấy nhóm nào do bạn (<?= htmlspecialchars($maGV) ?>) hướng dẫn.
        </div>
    <?php else: ?>
        <form action="../backend/export_word_gvhd.php" method="post" target="_blank" style="margin-top: 20px;">
            
            <div class="form-group">
                <label style="font-size: 14px;">Chọn Nhóm / Đề tài:</label>
                <select name="maDeTai" required>
                    <option value="">-- Chọn một nhóm --</option>
                    <?php foreach ($groups as $group): ?>
                        <option value="<?= $group['maDeTai'] ?>">
                            <?= htmlspecialchars($group['tenDeTai']) ?> (SV: <?= htmlspecialchars($group['dsSinhVien'] ?? 'Chưa có SV') ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <hr>

            <div class="common-scale">
                <h4 style="margin-top: 0; color: #2563eb;">Thang điểm</h4>
                <div class="grade-grid">
                    <div class="form-group"> <label>1. Phân tích vấn đề</label> <input type="number" id="maxPhanTich" name="maxPhanTich" value="2.5" min="0" max="10" step="0.5" class="max-input"> </div>
                    <div class="form-group"> <label>2. Thiết kế vấn đề</label> <input type="number" id="maxThietKe" name="maxThietKe" value="2.5" min="0" max="10" step="0.5" class="max-input"> </div>
                    <div class="form-group"> <label>3. Hiện thực vấn đề</label> <input type="number" id="maxHienThuc" name="maxHienThuc" value="2.5" min="0" max="10" step="0.5" class="max-input"> </div>
                    <div class="form-group"> <label>4. Báo cáo/Tài liệu</label> <input type="number" id="maxBaoCao" name="maxBaoCao" value="2.5" min="0" max="10" step="0.5" class="max-input"> </div>
                </div>
            </div>

            <div class="student-divider">
                <h4 style="margin-top: 0; color: #2563eb;">Sinh viên 1</h4>
                <div class="grade-grid">
                    <div class="form-group"><label>1. Phân tích</label><input type="number" class="grade-input-1" name="diemPhanTich1" min="0" step="0.1" value="0"></div>
                    <div class="form-group"><label>2. Thiết kế</label><input type="number" class="grade-input-1" name="diemThietKe1" min="0" step="0.1" value="0"></div>
                    <div class="form-group"><label>3. Hiện thực</label><input type="number" class="grade-input-1" name="diemHienThuc1" min="0" step="0.1" value="0"></div>
                    <div class="form-group"><label>4. Báo cáo</label><input type="number" class="grade-input-1" name="diemBaoCao1" min="0" step="0.1" value="0"></div>
                </div>
                <div class="form-group" style="margin-top: 10px;">
                    <label>Tổng cộng (%)</label> 
                    <input type="text" id="diemTongCong1" value="0%" readonly style="background-color: #eee; font-weight: bold;">
                </div>
                <div class="form-group">
                    <label>Điểm chấm</label>
                    <input type="number" id="diemFinal1" name="diemFinal1" min="0" max="10" step="0.1" value="0" required style="font-weight:bold; color:blue;">
                </div>
            </div>

            <div class="student-divider">
                <h4 style="margin-top: 0; color: #2563eb;">Sinh viên 2 (Nếu có)</h4>
                <div class="grade-grid">
                    <div class="form-group"><label>1. Phân tích</label><input type="number" class="grade-input-2" name="diemPhanTich2" min="0" step="0.1" value="0"></div>
                    <div class="form-group"><label>2. Thiết kế</label><input type="number" class="grade-input-2" name="diemThietKe2" min="0" step="0.1" value="0"></div>
                    <div class="form-group"><label>3. Hiện thực</label><input type="number" class="grade-input-2" name="diemHienThuc2" min="0" step="0.1" value="0"></div>
                    <div class="form-group"><label>4. Báo cáo</label><input type="number" class="grade-input-2" name="diemBaoCao2" min="0" step="0.1" value="0"></div>
                </div>
                <div class="form-group" style="margin-top: 10px;">
                    <label>Tổng cộng (%)</label> 
                    <input type="text" id="diemTongCong2" value="0%" readonly style="background-color: #eee; font-weight: bold;">
                </div>
                <div class="form-group">
                    <label>Điểm chấm</label>
                    <input type="number" id="diemFinal2" name="diemFinal2" min="0" max="10" step="0.1" value="0" style="font-weight:bold; color:blue;">
                </div>
            </div>

            <hr>

            <h4 style="color: #1e293b;">Nhận xét chi tiết</h4>
            <div class="form-group"><label>Nội dung điều chỉnh</label><textarea name="ndDieuChinh" rows="2"></textarea></div>
            <div class="form-group"><label>Nhận xét tổng quát</label><textarea name="nxTongQuat" rows="2"></textarea></div>
            
            <div class="form-group" style="margin-top: 10px;">
                <label style="display:inline-block; margin-right: 15px;">Thuyết minh:</label>
                <label style="display:inline-block; margin-right: 15px;"><input type="radio" name="thuyetMinh" value="dat" checked> Đạt</label>
                <label style="display:inline-block;"><input type="radio" name="thuyetMinh" value="khongdat"> Không đạt</label>
            </div>

            <div class="form-group"><label>Ưu điểm</label><textarea name="uuDiem" rows="2"></textarea></div>
            <div class="form-group"><label>Thiếu sót</label><textarea name="thieuSot" rows="2"></textarea></div>
            <div class="form-group"><label>Câu hỏi (nếu có)</label><textarea name="cauHoi" rows="2"></textarea></div>
            
            <div class="form-group" style="margin-top: 10px;">
                <label style="display:inline-block; margin-right: 15px;">Đề nghị:</label>
                <label style="display:inline-block; margin-right: 15px;"><input type="radio" name="deNghi" value="duoc" checked> Được bảo vệ</label>
                <label style="display:inline-block; margin-right: 15px;"><input type="radio" name="deNghi" value="khong"> Không Bảo Vệ</label>
                <label style="display:inline-block;"><input type="radio" name="deNghi" value="bosung"> Bổ sung</label>
            </div>

            <div style="margin-top: 25px;">
                <button type="submit" class="button primary" style="background:#2563eb; color:white; padding:12px 30px; border:none; border-radius:5px; cursor:pointer; font-weight: bold; font-size: 15px; display: flex; align-items: center; gap: 8px;">
                    <i class="fa-solid fa-file-word"></i> Lưu điểm & Xuất Phiếu (HD)
                </button>
            </div>
        </form>
    <?php endif; ?>

    <script>
        const maxInputs = document.querySelectorAll('.max-input');
        
        function calculate(inputs, finalEl, totalEl) {
            let total = 0; 
            let totalMax = 0;
            
            inputs.forEach((input, i) => {
                let max = parseFloat(maxInputs[i].value) || 0;
                let val = parseFloat(input.value) || 0;
                if(val > max) { input.value = max; val = max; }
                
                total += val; 
                totalMax += max;
            });
            let finalScore10 = (totalMax > 0) ? (total / totalMax) * 10 : 0;
            
            if(finalEl) finalEl.value = finalScore10.toFixed(1);
            if(totalEl) totalEl.value = (finalScore10 * 10).toFixed(0) + '%';
        }
        const inputs1 = document.querySelectorAll('.grade-input-1');
        const diemFinal1 = document.getElementById('diemFinal1');
        const diemTongCong1 = document.getElementById('diemTongCong1');
        inputs1.forEach(el => el.addEventListener('input', () => calculate(inputs1, diemFinal1, diemTongCong1)));
        const inputs2 = document.querySelectorAll('.grade-input-2');
        const diemFinal2 = document.getElementById('diemFinal2');
        const diemTongCong2 = document.getElementById('diemTongCong2');
        inputs2.forEach(el => el.addEventListener('input', () => calculate(inputs2, diemFinal2, diemTongCong2)));
        maxInputs.forEach(el => el.addEventListener('input', () => {
            calculate(inputs1, diemFinal1, diemTongCong1);
            calculate(inputs2, diemFinal2, diemTongCong2);
        }));
    </script>
</body>
</html>