<?php
session_start();
if (!isset($_SESSION["dangnhap"]) || $_SESSION["dangnhap"] !== true) {
    header("location: dangnhap.html");
    exit;
}
if (isset($_SESSION['role']) && $_SESSION['role'] != 'admin') {
    header("location: index.php");
    exit;
}

require '../backend/db.php';

$keyword = isset($_GET['q']) ? trim($_GET['q']) : '';
$sql = "
    SELECT sv.*, dt.tenDeTai, dt.maMH, dt.tenMonHoc 
    FROM SinhVien sv 
    LEFT JOIN DeTai dt ON sv.maDeTai = dt.maDeTai 
";

if ($keyword) {
    $sql .= " WHERE sv.mssv LIKE :kw OR sv.hoTen LIKE :kw OR sv.lop LIKE :kw";
}
$sql .= " ORDER BY sv.mssv ASC";

$stmt = $pdo->prepare($sql);
if ($keyword) {
    $stmt->execute(['kw' => "%$keyword%"]);
} else {
    $stmt->execute();
}
$students = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Quản lý Sinh viên</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="icon" type="image/png" href="../images/STU.webp" />
    <link rel="stylesheet" href="../style/style.css">
    <link rel="stylesheet" href="../style/sinhvien.css">    
</head>
<body>
    <div class="app-layout">
        <header class="header">
            <div style="display:flex; gap:10px; align-items:center;">
                <img src="../images/STU.webp" style="height:38px;"> 
                <h1 style="font-size:18px; margin:0; color:#1e293b; text-transform:uppercase; font-weight:700;">Quản lý Sinh viên</h1>
            </div>
        </header>

        <div class="main-content-wrapper">
            <main class="content">
                <div class="page-header">
                    <div class="search-box">
                    </div>
                    <div class="toolbar">
                        <button onclick="openAddModal()" class="button primary"><i class="fa-solid fa-plus"></i> Thêm mới</button>
                        
                        <button type="button" class="button success" onclick="openImportModal()" style="color:white;">
                            <i class="fa-solid fa-file-excel"></i> Import Excel
                        </button>

                        <a href="giangvien.php" class="button purple" style="color:white;"><i class="fa-solid fa-chalkboard-user"></i> DS Giảng viên</a>
                        <form action="../backend/actions.php" method="post" style="display:inline;" onsubmit="return confirm('Xóa TẤT CẢ sinh viên?');">
                            <input type="hidden" name="action" value="delete_all_sinhvien">
                            <button type="submit" class="button danger"><i class="fa-solid fa-trash"></i> Xóa tất cả</button>
                        </form>
                    </div>
                </div>

                <div class="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th>MSSV</th>
                                <th>Họ và Tên</th>
                                <th>Lớp</th>
                                <th>Mã MH</th>
                                <th>Tên Môn Học</th>
                                <th>SĐT</th>
                                <th>Email</th>
                                <th class="col-action">Hành động</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($students as $sv): ?>
                            <tr>
                                <td style="font-weight:bold; color:#2563eb;"><?= htmlspecialchars($sv['mssv']) ?></td>
                                <td><?= htmlspecialchars($sv['hoTen']) ?></td>
                                <td><?= htmlspecialchars($sv['lop']) ?></td>
                                <td style="font-weight:600; color:#64748b;">CS03153</td>
                                <td style="color:#64748b;">Đồ án / Khóa luận tốt nghiệp</td>
                                
                                <td><?= htmlspecialchars($sv['soDienThoai']) ?></td>
                                <td><?= htmlspecialchars($sv['email']) ?></td>
                                <td class="col-action">
                                    <div style="display:flex; justify-content:center; gap:5px;">
                                        <button class="button" style="padding:4px 8px; color:#f59e0b; border-color:#f59e0b;" 
                                            onclick="openEditModal('<?= $sv['mssv'] ?>', '<?= $sv['hoTen'] ?>', '<?= $sv['lop'] ?>', '<?= $sv['soDienThoai'] ?>', '<?= $sv['email'] ?>')">
                                            <i class="fa-solid fa-pen"></i>
                                        </button>
                                        <form action="../backend/actions.php" method="post" style="margin:0;" onsubmit="return confirm('Xóa SV này?');">
                                            <input type="hidden" name="action" value="delete_sinhvien">
                                            <input type="hidden" name="mssv" value="<?= $sv['mssv'] ?>">
                                            <button type="submit" class="button danger" style="padding:4px 8px;"><i class="fa-solid fa-trash"></i></button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </main>
        </div>
    </div>

    <div id="add-modal" class="modal-overlay">
        <div class="modal-content">
            <h2>Thêm Sinh viên Mới</h2>
            <form action="../backend/actions.php" method="post">
                <input type="hidden" name="action" value="add_sinhvien">
                
                <div style="display:grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div class="form-group">
                        <label>MSSV</label>
                        <input type="text" name="mssv" required>
                    </div>
                    <div class="form-group">
                        <label>Lớp</label>
                        <input type="text" name="lop" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Họ và Tên</label>
                    <input type="text" name="hoTen" required>
                </div>

                <div style="display:grid; grid-template-columns: 1fr 2fr; gap: 15px; background: #f8fafc; padding: 10px; border-radius: 6px; margin-bottom: 15px;">
                    <div class="form-group" style="margin-bottom:0;">
                        <label style="font-size:11px; color:#64748b;">Mã Môn Học</label>
                        <input type="text" value="CS03153" readonly style="background:#e2e8f0; color:#475569; font-weight:bold;">
                    </div>
                    <div class="form-group" style="margin-bottom:0;">
                        <label style="font-size:11px; color:#64748b;">Tên Môn Học</label>
                        <input type="text" value="Đồ án / Khóa luận tốt nghiệp" readonly style="background:#e2e8f0; color:#475569; font-weight:bold;">
                    </div>
                </div>

                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email">
                </div>
                <div class="form-group">
                    <label>Số điện thoại</label>
                    <input type="text" name="soDienThoai">
                </div>

                <div class="modal-actions">
                    <button type="button" class="button" onclick="closeModal('add-modal')">Hủy</button>
                    <button type="submit" class="button primary">Lưu lại</button>
                </div>
            </form>
        </div>
    </div>

    <div id="edit-modal" class="modal-overlay">
        <div class="modal-content">
            <h2>Cập nhật thông tin Sinh viên</h2>
            <form action="../backend/actions.php" method="post">
                <input type="hidden" name="action" value="update_sinhvien">
                <input type="hidden" name="mssv_original" id="edit_mssv_original">
                
                <div style="display:grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div class="form-group">
                        <label>MSSV</label>
                        <input type="text" name="mssv_edit" id="edit_mssv" required>
                    </div>
                    <div class="form-group">
                        <label>Lớp</label>
                        <input type="text" name="lop_edit" id="edit_lop" required>
                    </div>
                </div>
                <div class="form-group">
                    <label>Họ và Tên</label>
                    <input type="text" name="hoTen_edit" id="edit_hoten" required>
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email_edit" id="edit_email">
                </div>
                <div class="form-group">
                    <label>Số điện thoại</label>
                    <input type="text" name="soDienThoai_edit" id="edit_sdt">
                </div>

                <div class="modal-actions">
                    <button type="button" class="button" onclick="closeModal('edit-modal')">Hủy</button>
                    <button type="submit" class="button primary">Cập nhật</button>
                </div>
            </form>
        </div>
    </div>

    <div id="import-modal" class="modal-overlay">
        <div class="modal-content">
            <h2>Nhập dữ liệu từ Excel</h2>
            <form action="../backend/actions.php" method="post" enctype="multipart/form-data">
                <input type="hidden" name="action" value="import_sinhvien">
                
                <div class="form-group">
                    <label>Chọn file Excel (.xlsx)</label>
                    <input type="file" name="excel_file" accept=".xlsx, .xls" required style="padding: 10px; border: 1px dashed #ccc; width: 100%;">
                </div>

                <div class="modal-actions">
                    <button type="button" class="button" onclick="closeModal('import-modal')">Hủy</button>
                    <button type="submit" class="button success">Import</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function openAddModal() {
            document.getElementById('add-modal').classList.add('active');
        }
        
        // FIXED: Added function to open Import Modal
        function openImportModal() {
            document.getElementById('import-modal').classList.add('active');
        }

        function openEditModal(mssv, hoten, lop, sdt, email) {
            document.getElementById('edit_mssv_original').value = mssv;
            document.getElementById('edit_mssv').value = mssv;
            document.getElementById('edit_hoten').value = hoten;
            document.getElementById('edit_lop').value = lop;
            document.getElementById('edit_sdt').value = sdt;
            document.getElementById('edit_email').value = email;
            document.getElementById('edit-modal').classList.add('active');
        }
        function closeModal(modalId) {
            document.getElementById(modalId).classList.remove('active');
        }
        window.onclick = function(event) {
            if (event.target.classList.contains('modal-overlay')) {
                event.target.classList.remove('active');
            }
        }
    </script>
</body>
</html>