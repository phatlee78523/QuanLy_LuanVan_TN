<?php
session_start();
if (!isset($_SESSION["dangnhap"]) || $_SESSION["dangnhap"] !== true) {
    header("location: dangnhap.html");
    exit;
}

require '../backend/db.php';
$stmt = $pdo->query("SELECT * FROM GiangVien ORDER BY maGV ASC");
$lecturers = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Quản lý Giảng viên</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="icon" type="image/png" href="../images/STU.webp" />
    <link rel="stylesheet" href="../style/style.css">
    <link rel="stylesheet" href="../style/giangvien.css">
</head>
<body>
    <div class="app-layout">

        <header class="header">
            <div class="header-logo" onclick="window.location.href='index.php'">
                <img src="../images/STU.webp" alt="Logo" style="height: 38px;">
                <h1 style="font-size: 18px; margin: 0; font-weight: 700; color: #1e293b; text-transform: uppercase;">Quản lý Giảng viên</h1>
            </div>
        </header>

        <div class="main-content-wrapper">
            <main class="content">
                
                <div class="page-header">
                    <h2>Danh sách Giảng viên</h2>
                    <div class="toolbar">
                        <button type="button" id="add-lecturer-btn" class="button primary">
                            <i class="fa-solid fa-plus"></i> Thêm giảng viên
                        </button>
                        
                        <a href="sinhvien.php" class="button" style="background: #6366f1; color: white; border-color: #6366f1;">
                            <i class="fa-solid fa-user-graduate"></i> DS Sinh viên
                        </a>
                    </div>
                </div>

                <div class="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th class="col-code">Mã GV</th>
                                <th class="col-wrap">Họ và Tên</th>
                                <th class="col-contact">Email</th>
                                <th class="col-contact">SĐT</th>
                                <th class="col-wrap">Học vị</th>
                                <th class="col-wrap">Mật khẩu</th>
                                <th class="col-action">Hành động</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($lecturers as $lecturer): ?>
                            <tr>
                                <td><b><?= htmlspecialchars($lecturer['maGV']) ?></b></td>
                                <td><?= htmlspecialchars($lecturer['tenGV']) ?></td>
                                <td><?= htmlspecialchars($lecturer['email'] ?? '') ?></td>
                                <td><?= htmlspecialchars($lecturer['soDienThoai'] ?? '') ?></td>
                                <td><?= htmlspecialchars($lecturer['hocVi'] ?? '') ?></td>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 5px;">
                                        <input type="password" value="<?= htmlspecialchars($lecturer['matKhau'] ?? '') ?>" readonly style="border: none; background: transparent; width: 80px; font-size: 12px;">
                                        <i class="fa-solid fa-eye toggle-password" style="cursor: pointer; color: #94a3b8; font-size: 12px;"></i>
                                    </div>
                                </td>
                                <td class="col-action">
                                    <div style="display: flex; gap: 5px; justify-content: center;">
                                        <button class="edit-btn btn-sm" style="background: #e0f2fe; color: #0284c7; border: 1px solid #bae6fd;"
                                            data-magv="<?= $lecturer['maGV'] ?>" 
                                            data-tengv="<?= htmlspecialchars($lecturer['tenGV']) ?>" 
                                            data-email="<?= htmlspecialchars($lecturer['email'] ?? '') ?>" 
                                            data-sdt="<?= htmlspecialchars($lecturer['soDienThoai'] ?? '') ?>"
                                            data-hocvi="<?= htmlspecialchars($lecturer['hocVi'] ?? '') ?>">
                                            <i class="fa-solid fa-pen"></i>
                                        </button>
                                        <form action="../backend/actions.php" method="post" onsubmit="return confirm('Bạn có chắc muốn xóa giảng viên này?');" style="margin:0;">
                                            <input type="hidden" name="action" value="delete_giangvien">
                                            <input type="hidden" name="maGV" value="<?= $lecturer['maGV'] ?>">
                                            <button type="submit" class="btn-sm danger"><i class="fa-solid fa-trash"></i></button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </main>
        </div>
    </div>

    <div id="edit-modal" class="modal-overlay">
        <div class="modal-content">
            <h2>Sửa thông tin giảng viên</h2>
            <form action="../backend/actions.php" method="post">
                <input type="hidden" name="action" value="update_giangvien">
                <input type="hidden" id="maGV_original" name="maGV_original">
                <div class="form-group"><label>Mã GV</label><input type="text" id="maGV_edit" name="maGV" required></div>
                <div class="form-group"><label>Họ và Tên</label><input type="text" id="tenGV_edit" name="tenGV" required></div>
                <div class="form-group"><label>Email</label><input type="email" id="email_edit" name="email"></div>
                <div class="form-group"><label>Số điện thoại</label><input type="text" id="soDienThoai_edit" name="soDienThoai"></div>
                <div class="form-group"><label>Học vị</label><input type="text" id="hocVi_edit" name="hocVi"></div>
                <div class="form-group">
                    <label style="color: #2563eb;">Mật khẩu mới (Để trống nếu không đổi)</label>
                    <input type="text" name="matKhau_new" placeholder="Nhập mật khẩu mới...">
                </div>
                <div class="modal-actions">
                    <button type="button" class="cancel-btn button">Hủy</button>
                    <button type="submit" class="button primary">Cập nhật</button>
                </div>
            </form>
        </div>
    </div>

    <div id="add-modal" class="modal-overlay">
        <div class="modal-content">
            <h2>Thêm giảng viên mới</h2>
            <form action="../backend/actions.php" method="post">
                <input type="hidden" name="action" value="add_giangvien">
                <div class="form-group"><label>Mã GV</label><input type="text" name="maGV" required></div>
                <div class="form-group"><label>Họ và Tên</label><input type="text" name="tenGV" required></div>
                <div class="form-group"><label>Email</label><input type="email" name="email"></div>
                <div class="form-group"><label>Số điện thoại</label><input type="text" name="soDienThoai"></div>
                <div class="form-group"><label>Học vị</label><input type="text" name="hocVi"></div>
                <div class="form-group">
                    <label>Mật khẩu đăng nhập</label>
                    <input type="text" name="matKhau" required placeholder="Nhập mật khẩu cho GV">
                </div>
                <div class="modal-actions">
                    <button type="button" class="cancel-btn button">Hủy</button>
                    <button type="submit" class="button primary">Thêm</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        const editModal = document.getElementById('edit-modal');
        const addModal = document.getElementById('add-modal');
        const btnAdd = document.getElementById('add-lecturer-btn');
        const btnsEdit = document.querySelectorAll('.edit-btn');
        const btnsClose = document.querySelectorAll('.cancel-btn');

        function openModal(modal) {
            if(modal) {
                modal.style.display = 'flex';
                setTimeout(() => modal.classList.add('active'), 10);
            }
        }

        function closeModal() {
            [editModal, addModal].forEach(m => {
                if(m) {
                    m.classList.remove('active');
                    setTimeout(() => m.style.display = 'none', 300);
                }
            });
        }

        if(btnAdd) btnAdd.addEventListener('click', () => openModal(addModal));

        btnsEdit.forEach(btn => {
            btn.addEventListener('click', () => {
                document.getElementById('maGV_original').value = btn.dataset.magv;
                document.getElementById('maGV_edit').value = btn.dataset.magv;
                document.getElementById('tenGV_edit').value = btn.dataset.tengv;
                document.getElementById('email_edit').value = btn.dataset.email;
                document.getElementById('soDienThoai_edit').value = btn.dataset.sdt;
                document.getElementById('hocVi_edit').value = btn.dataset.hocvi;
                openModal(editModal);
            });
        });

        btnsClose.forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                closeModal();
            });
        });

        window.addEventListener('click', (e) => {
            if (e.target == addModal || e.target == editModal) closeModal();
        });
        document.querySelectorAll('.toggle-password').forEach(icon => {
            icon.addEventListener('click', function() {
                const input = this.previousElementSibling;
                if (input.type === 'password') {
                    input.type = 'text';
                    this.classList.replace('fa-eye', 'fa-eye-slash');
                } else {
                    input.type = 'password';
                    this.classList.replace('fa-eye-slash', 'fa-eye');
                }
            });
        });
    </script>
</body>
</html>