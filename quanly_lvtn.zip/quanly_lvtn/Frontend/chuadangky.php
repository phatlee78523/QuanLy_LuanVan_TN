<?php
session_start();
if (!isset($_SESSION["dangnhap"]) || $_SESSION["dangnhap"] !== true) {
    header("location: dangnhap.html");
    exit;
}
require '../backend/db.php';
$sql = "
    SELECT sv.mssv, sv.hoTen, sv.lop, sv.soDienThoai, sv.email 
    FROM SinhVien sv
    WHERE sv.maDeTai IS NULL
    ORDER BY sv.mssv ASC
";
$stmt = $pdo->query($sql);
$students_no_group = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>SV chưa đăng ký - Quản lý LVTN</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="icon" type="image/png" href="../images/STU.webp" />
    <link rel="stylesheet" href="../style/style.css">
</head>
<body>
    <div class="app-layout">
        
        <aside class="sidebar">
            <div class="sidebar-header"><img src="../images/Logo_STU.png" alt="Logo STU" class="sidebar-logo"></div>
            <nav class="sidebar-nav">
                
                <a href="index.php" class="nav-item <?php echo (basename($_SERVER['PHP_SELF']) == 'index.php') ? 'active' : ''; ?>">
                    <i class="fa-solid fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>                
                <?php if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin'): ?>
                    
                    <?php
                        $isSV = (basename($_SERVER['PHP_SELF']) == 'sinhvien.php' 
                                    || basename($_SERVER['PHP_SELF']) == 'chuadangky.php'
                                    || basename($_SERVER['PHP_SELF']) == 'phancong.php');
                    ?>
                    <div class="nav-item-dropdown">
                        <button type="button" class="nav-item-toggle <?php echo $isSV ? 'active' : ''; ?>">
                            <span><i class="fa-solid fa-users"></i><span>Quản lý Sinh viên</span></span>
                            <span class="arrow">&#9662;</span>
                        </button>
                        <div class="nav-submenu" <?php echo $isSV ? 'style="display: block;"' : 'style="display: none;"'; ?>>
                            <a href="sinhvien.php" class="nav-sub-item <?php echo (basename($_SERVER['PHP_SELF']) == 'sinhvien.php') ? 'active' : ''; ?>">Danh sách sinh viên</a>
                            <a href="phancong.php" class="nav-sub-item <?php echo (basename($_SERVER['PHP_SELF']) == 'phancong.php') ? 'active' : ''; ?>">Phân công sinh viên</a>
                            <a href="chuadangky.php" class="nav-sub-item <?php echo (basename($_SERVER['PHP_SELF']) == 'chuadangky.php') ? 'active' : ''; ?>">Sinh viên chưa đăng ký</a>
                        </div>
                    </div>

                    <?php
                        $isGV = (basename($_SERVER['PHP_SELF']) == 'giangvien.php'
                                        || basename($_SERVER['PHP_SELF']) == 'phancong_pb.php'); 
                    ?>
                    <div class="nav-item-dropdown">
                        <button type="button" class="nav-item-toggle <?php echo $isGV ? 'active' : ''; ?>">
                            <span><i class="fa-solid fa-chalkboard-teacher"></i><span>Quản lý Giảng viên</span></span>
                            <span class="arrow">&#9662;</span>
                        </button>
                        <div class="nav-submenu" <?php echo $isGV ? 'style="display: block;"' : 'style="display: none;"'; ?>>
                            <a href="giangvien.php" class="nav-sub-item <?php echo (basename($_SERVER['PHP_SELF']) == 'giangvien.php') ? 'active' : ''; ?>">Danh sách Giảng viên</a>
                            <a href="phancong_pb.php" class="nav-sub-item <?php echo (basename($_SERVER['PHP_SELF']) == 'phancong_pb.php') ? 'active' : ''; ?>">Phân công Phản biện</a>
                        </div>
                    </div>

                    <a href="hoidong.php" class="nav-item <?php echo (basename($_SERVER['PHP_SELF']) == 'hoidong.php') ? 'active' : ''; ?>">
                        <i class="fa-solid fa-landmark"></i>
                        <span>Hội đồng LVTN</span>
                    </a>

                <?php else: ?>
                    <a href="ds_sinhvien_gv.php" class="nav-item <?php echo (basename($_SERVER['PHP_SELF']) == 'ds_sinhvien_gv.php') ? 'active' : ''; ?>">
                        <i class="fa-solid fa-users"></i>
                        <span>Sinh viên Hướng dẫn</span>
                    </a>

                    <a href="ds_phanbien_gv.php" class="nav-item <?php echo (basename($_SERVER['PHP_SELF']) == 'ds_phanbien_gv.php') ? 'active' : ''; ?>">
                        <i class="fa-solid fa-gavel"></i>
                        <span>Danh sách Phản biện</span>
                    </a>

                    <?php
                        $isNhapLieu = (basename($_SERVER['PHP_SELF']) == 'chamdiem.php'
                                    || basename($_SERVER['PHP_SELF']) == 'nhaplieu_sv.php'
                                    || basename($_SERVER['PHP_SELF']) == 'chamdiem_pb.php'); 
                    ?>
                    <div class="nav-item-dropdown">
                        <button type="button" class="nav-item-toggle <?php echo $isNhapLieu ? 'active' : ''; ?>">
                            <span><i class="fa-solid fa-file-pen"></i><span>Nhập Liệu</span></span>
                            <span class="arrow">&#9662;</span>
                        </button>
                        <div class="nav-submenu" <?php echo $isNhapLieu ? 'style="display: block;"' : 'style="display: none;"'; ?>>
                            <a href="nhaplieu_sv.php" class="nav-sub-item <?php echo (basename($_SERVER['PHP_SELF']) == 'nhaplieu_sv.php') ? 'active' : ''; ?>">Tạo Phiếu Giao Đề Tài</a>
                            <a href="chamdiem.php" class="nav-sub-item <?php echo (basename($_SERVER['PHP_SELF']) == 'chamdiem.php') ? 'active' : ''; ?>">GVHD Chấm Điểm</a>
                            <a href="chamdiem_pb.php" class="nav-sub-item <?php echo (basename($_SERVER['PHP_SELF']) == 'chamdiem_pb.php') ? 'active' : ''; ?>">GVPB Chấm Điểm</a>
                        </div>
                    </div>
                <?php endif; ?>
                
            </nav>
        </aside>

        <div class="main-content-wrapper">
            <header class="header">
                <h1>Hệ thống Quản lý Luận văn Tốt nghiệp</h1>
                <div class="user-actions">
                    <span>Chào, <strong><?= $_SESSION["username"]; ?></strong></span>
                    
                    <a href="hoso.php" class="button" style="background-color: #64748b; color: white;">
                        <i class="fa-solid fa-user"></i> Hồ sơ
                    </a>
                    <a href="../backend/dangxuat.php" class="button danger">
                        <i class="fa-solid fa-door-open"></i> Đăng xuất
                    </a>
                </div>
            </header>

            <main class="content">
                <h2>Danh sách sinh viên chưa đăng ký</h2>

                <div class="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th class="col-code">MSSV</th>
                                <th class="col-wrap">Họ và Tên</th>
                                <th class="col-code">Lớp</th>
                                <th class="col-contact">SĐT</th>
                                <th class="col-contact">Email</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($students_no_group as $student): ?>
                            <tr>
                                <td><?= htmlspecialchars($student['mssv']) ?></td>
                                <td><?= htmlspecialchars($student['hoTen']) ?></td>
                                <td><?= htmlspecialchars($student['lop']) ?></td>
                                <td><?= htmlspecialchars($student['soDienThoai'] ?? '') ?></td>
                                <td><?= htmlspecialchars($student['email'] ?? '') ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </main>
        </div>
    </div>

    <script>
        document.querySelectorAll('.nav-item-toggle').forEach(button => {
            button.addEventListener('click', (e) => {
                e.preventDefault(); 
                const submenu = button.nextElementSibling;
                const isVisible = submenu.style.display === 'block';
                submenu.style.display = isVisible ? 'none' : 'block';
            });
        });
    </script>
</body>
</html>