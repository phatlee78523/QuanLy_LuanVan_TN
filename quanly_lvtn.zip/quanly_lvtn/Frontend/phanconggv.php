<?php
session_start();
if (!isset($_SESSION["dangnhap"]) || $_SESSION["dangnhap"] !== true || $_SESSION['role'] != 'admin') {
    header("location: dangnhap.html");
    exit;
}
require '../backend/db.php';

$mode = isset($_GET['loai']) && $_GET['loai'] == 'PB' ? 'PB' : 'HD';
$pageTitle = ($mode == 'PB') ? 'Phân công Giảng viên Phản biện (Tuần 5)' : 'Phân công Giảng viên Hướng dẫn (Tuần 2)';

$lecturers = $pdo->query("SELECT maGV, tenGV FROM GiangVien ORDER BY tenGV ASC")->fetchAll();

$freeStudents = $pdo->query("SELECT mssv, hoTen FROM SinhVien WHERE maDeTai IS NULL ORDER BY hoTen ASC")->fetchAll();

$sql = "
    SELECT 
        dt.maDeTai, dt.tenDeTai, dt.maMH,
        gv1.tenGV AS tenGV_HD, dt.maGV_HD,
        gv2.tenGV AS tenGV_PB, dt.maGV_PB,
        (SELECT GROUP_CONCAT(CONCAT(sv.hoTen, '<br>') SEPARATOR '') 
         FROM SinhVien sv WHERE sv.maDeTai = dt.maDeTai) AS thanhVien
    FROM DeTai dt
    LEFT JOIN GiangVien gv1 ON dt.maGV_HD = gv1.maGV
    LEFT JOIN GiangVien gv2 ON dt.maGV_PB = gv2.maGV
    ORDER BY dt.maMH ASC
";
$groups = $pdo->query($sql)->fetchAll();
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title><?= $pageTitle ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="icon" type="image/png" href="../images/STU.webp" />
    <link rel="stylesheet" href="../style/style.css">
    <link rel="stylesheet" href="../style/phanconggv.css">
</head>
<body>
    <div class="app-layout">
        <header class="header">
            <div style="display: flex; align-items: center; gap: 15px;">
                <a href="index.php" style="color: #64748b; font-size: 18px;"><i class="fa-solid fa-arrow-left"></i></a>
                <h2 style="margin:0; font-size: 18px; color: #1e293b;"><?= $pageTitle ?></h2>
            </div>
        </header>

        <div class="main-content-wrapper">
            <main class="content">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                    <p style="color: #64748b; margin: 0;">Quản lý và phân công đề tài.</p>
                    <button class="btn-add" onclick="openAddModal()">
                        <i class="fa-solid fa-users-viewfinder"></i> Tạo Nhóm & Phân công
                    </button>
                </div>

                <table>
                    <thead>
                        <tr>
                            <th style="width: 60px; text-align: center;">Nhóm</th>
                            <th>Tên Đề tài</th>
                            <th>Sinh viên</th>
                            <th>GV Hướng dẫn</th>
                            <?php if ($mode == 'PB'): ?><th>GV Phản biện</th><?php endif; ?>
                            <th style="width: 100px; text-align: center;">Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($groups as $row): ?>
                        <tr>
                            <td style="font-weight: bold; text-align: center; color: #2563eb;"><?= htmlspecialchars($row['maMH'] ?? $row['maDeTai']) ?></td>
                            <td><?= htmlspecialchars($row['tenDeTai'] ?: 'Chưa có tên') ?></td>
                            <td style="font-size: 12px;"><?= $row['thanhVien'] ?></td>
                            <td>
                                <?php if ($row['tenGV_HD']): ?>
                                    <span class="badge bg-orange"><i class="fa-solid fa-user-tie"></i> <?= htmlspecialchars($row['tenGV_HD']) ?></span>
                                <?php else: ?>
                                    <span class="badge bg-gray">Chưa phân công</span>
                                <?php endif; ?>
                            </td>
                            <?php if ($mode == 'PB'): ?>
                            <td>
                                <?php if ($row['tenGV_PB']): ?>
                                    <span class="badge bg-green"><i class="fa-solid fa-user-shield"></i> <?= htmlspecialchars($row['tenGV_PB']) ?></span>
                                <?php else: ?>
                                    <span class="badge bg-gray">Chưa phân công</span>
                                <?php endif; ?>
                            </td>
                            <?php endif; ?>
                            <td style="text-align: center;">
                                <button class="btn-assign" onclick="openModal('<?= $row['maDeTai'] ?>', '<?= $mode ?>', '<?= $row['maGV_HD'] ?>', '<?= ($mode == 'HD') ? $row['maGV_HD'] : $row['maGV_PB'] ?>')">
                                    <i class="fa-solid fa-pen"></i> Sửa
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </main>
        </div>
    </div>

    <div id="assign-modal" class="modal-overlay">
        <div class="modal-content" style="width: 450px;">
            <h3 id="modal-title" style="margin-top:0; color: #1e293b;">Chọn Giảng viên</h3>
            <form action="../backend/actions.php" method="post">
                <input type="hidden" name="action" value="assign_gv">
                <input type="hidden" name="maDeTai" id="modal_madetai">
                <input type="hidden" name="role_assign" id="modal_role">
                <div class="form-group">
                    <label>Giảng viên phụ trách:</label>
                    <select name="maGV" id="select_gv" required>
                        <option value="">-- Chọn Giảng viên --</option>
                        <?php foreach ($lecturers as $gv): ?>
                            <option value="<?= $gv['maGV'] ?>"><?= htmlspecialchars($gv['tenGV']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <p id="modal-warning" style="margin: 5px 0 0 0; font-size: 11px; color: #ef4444; font-style: italic; display: none;">* GVHD của nhóm này đã bị khóa.</p>
                </div>
                <div class="modal-actions">
                    <button type="button" class="btn-cancel" onclick="closeModal('assign-modal')">Hủy</button>
                    <button type="submit" class="btn-save">Lưu lại</button>
                </div>
            </form>
        </div>
    </div>

    <div id="add-modal" class="modal-overlay">
        <div class="modal-content">
            <h3 style="margin-top:0; color: #10b981;">Tạo Nhóm & Phân công GVHD</h3>
            <form action="../backend/actions.php" method="post">
                <input type="hidden" name="action" value="create_group_assign">
                
                <div style="background: #f0fdf4; padding: 10px; border-radius: 6px; margin-bottom: 15px; border: 1px dashed #10b981;">
                    <label style="color: #166534; margin-bottom: 10px;">Thành viên nhóm (SV chưa có nhóm):</label>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                        <select name="student_1" required>
                            <option value="">-- Chọn SV 1 --</option>
                            <?php foreach ($freeStudents as $sv): ?>
                                <option value="<?= $sv['mssv'] ?>"><?= htmlspecialchars($sv['hoTen']) ?> (<?= $sv['mssv'] ?>)</option>
                            <?php endforeach; ?>
                        </select>
                        <select name="student_2">
                            <option value="">-- Chọn SV 2 (nếu có) --</option>
                            <?php foreach ($freeStudents as $sv): ?>
                                <option value="<?= $sv['mssv'] ?>"><?= htmlspecialchars($sv['hoTen']) ?> (<?= $sv['mssv'] ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label>Mã Nhóm (Số):</label>
                    <input type="text" name="maMH" required placeholder="VD: 01, 02...">
                </div>

                <div class="form-group">
                    <label>GV Hướng dẫn:</label>
                    <select name="maGV_HD" required>
                        <option value="">-- Chọn GVHD --</option>
                        <?php foreach ($lecturers as $gv): ?>
                            <option value="<?= $gv['maGV'] ?>"><?= htmlspecialchars($gv['tenGV']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="modal-actions">
                    <button type="button" class="btn-cancel" onclick="closeModal('add-modal')">Hủy</button>
                    <button type="submit" class="btn-save" style="background: #10b981;">Tạo Nhóm</button>
                </div>
            </form>
        </div>
    </div>
    <script>
        const assignModal = document.getElementById('assign-modal');
        const addModal = document.getElementById('add-modal');
        const selectBox = document.getElementById('select_gv');
        const warningText = document.getElementById('modal-warning');

        function openModal(maDeTai, mode, currentGVHD, currentSelection) {
            document.getElementById('modal_madetai').value = maDeTai;
            document.getElementById('modal_role').value = mode;
            document.getElementById('modal-title').innerText = (mode === 'HD') ? 'Phân công Hướng dẫn' : 'Phân công Phản biện';
            
            const options = selectBox.options;
            let hasDisabled = false;
            for (let i = 0; i < options.length; i++) {
                options[i].disabled = false;
                options[i].text = options[i].text.replace(' (GVHD - Không chọn)', '');
                options[i].style.color = '#000';
                if (mode === 'PB' && currentGVHD && options[i].value == currentGVHD) {
                    options[i].disabled = true; 
                    options[i].text += ' (GVHD - Không chọn)'; 
                    options[i].style.color = '#94a3b8'; 
                    hasDisabled = true;
                }
            }
            warningText.style.display = hasDisabled ? 'block' : 'none';
            selectBox.value = currentSelection || "";
            assignModal.classList.add('active');
        }

        function openAddModal() { addModal.classList.add('active'); }
        function closeModal(id) { document.getElementById(id).classList.remove('active'); }
        window.onclick = function(event) {
            if (event.target == assignModal) closeModal('assign-modal');
            if (event.target == addModal) closeModal('add-modal');
        }
    </script>
</body>
</html>