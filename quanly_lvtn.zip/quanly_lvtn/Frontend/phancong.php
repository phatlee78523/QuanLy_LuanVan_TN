<?php
session_start();
if (!isset($_SESSION["dangnhap"]) || $_SESSION["dangnhap"] !== true) {
    header("location: dangnhap.html");
    exit;
}

if (isset($_SESSION['role']) && $_SESSION['role'] != 'admin') {
    header("location: ds_sinhvien_gv.php");
    exit;
}

require '../backend/db.php';

$sql = "
    SELECT 
        dt.maDeTai, dt.tenDeTai, dt.maGV_HD, 
        gv.tenGV, 
        dt.diemGiuaKy, dt.trangThaiGiuaKy, dt.nhanXetGiuaKy,
        (SELECT GROUP_CONCAT(sv.hoTen SEPARATOR '\n') FROM SinhVien sv WHERE sv.maDeTai = dt.maDeTai) AS thanhVien,
        (SELECT GROUP_CONCAT(sv.mssv SEPARATOR '\n') FROM SinhVien sv WHERE sv.maDeTai = dt.maDeTai) AS mssv_list,
        (SELECT GROUP_CONCAT(sv.lop SEPARATOR '\n') FROM SinhVien sv WHERE sv.maDeTai = dt.maDeTai) AS lop_list
    FROM DeTai dt
    LEFT JOIN GiangVien gv ON dt.maGV_HD = gv.maGV
    ORDER BY dt.maDeTai ASC;
";
$stmt = $pdo->query($sql);
$theses = $stmt->fetchAll();

$lecturers = $pdo->query("SELECT maGV, tenGV FROM GiangVien")->fetchAll();
$students_no_group = $pdo->query("SELECT sv.mssv, sv.hoTen FROM SinhVien sv WHERE sv.maDeTai IS NULL ORDER BY sv.mssv ASC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản lý Phân công</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="icon" type="image/png" href="../images/STU.webp" />
    <link rel="stylesheet" href="../style/style.css">
</head>
<body>
    <div class="app-layout">

        <header class="header">
            <div class="header-logo" onclick="window.location.href='index.php'">
                <img src="../images/STU.webp" alt="Logo" style="height: 38px;">
                <h1 style="font-size: 18px; margin: 0; font-weight: 700; color: #1e293b; text-transform: uppercase;">Quản lý Phân công</h1>
            </div>
            <div class="user-actions">
                <span style="font-size: 12px; color: #64748b; margin-right: 5px;">Xin chào, <strong><?= $_SESSION["username"]; ?></strong></span>
                <a href="hoso.php" class="button" style="height: 32px; padding: 0 12px; font-size: 11px; border: 1px solid #cbd5e1;">Hồ sơ</a>
                <a href="../backend/dangxuat.php" class="button danger" style="height: 32px; padding: 0 12px; font-size: 11px;">Thoát</a>
            </div>
        </header>

        <div class="main-content-wrapper">
            <main class="content">
                
                <div class="page-header">
                    <h2>Quản lý Nhóm & Đề tài</h2>
                    <div class="toolbar">
                        <button type="button" id="add-group-btn" class="button primary">
                            <i class="fa-solid fa-plus"></i> Tạo Nhóm / Đề tài
                        </button>
                        <a href="../backend/export_sv.php" class="button success" style="color: white; text-decoration: none;">
                            <i class="fa-solid fa-file-excel"></i> Xuất Excel
                        </a>
                        <form action="../backend/actions.php" method="post" style="display:inline-block; margin: 0;" onsubmit="return confirm('CẢNH BÁO: Bạn có chắc muốn xóa TẤT CẢ đề tài không?');">
                            <input type="hidden" name="action" value="delete_all_detai">
                            <button type="submit" class="button danger">
                                <i class="fa-solid fa-trash-can"></i> Xóa tất cả
                            </button>
                        </form>
                    </div>
                </div>

                <div class="table-wrapper">
                    <table> 
                        <thead>
                            <tr>
                                <th class="col-code">Nhóm</th>
                                <th class="col-wrap" style="width: 120px;">MSSV</th>
                                <th class="col-wrap">Họ tên Sinh viên</th>
                                <th class="col-code">Lớp</th>
                                <th class="col-wrap">Tên đề tài</th>
                                <th class="col-wrap">GVHD</th>
                                <th class="col-status">Tiến độ GK</th>
                                <th class="col-status">Quyết định</th>
                                <th class="col-wrap">Ghi chú</th>
                                <th class="col-action">Hành động</th>
                            </tr>
                        </thead>
                        <?php $nhomCounter = 1; ?>
                        <tbody>
                            <?php foreach ($theses as $thesis): ?>
                            <tr>
                                <td class="col-code" style="font-weight: bold; color: #64748b;"><?= $nhomCounter ?></td>
                                <td><?php echo nl2br(htmlspecialchars($thesis['mssv_list'])); ?></td>
                                <td><?php echo nl2br(htmlspecialchars($thesis['thanhVien'])); ?></td>
                                <td class="col-code"><?php echo nl2br(htmlspecialchars($thesis['lop_list'])); ?></td>
                                <td style="font-weight: 500; color: #1e293b;"><?= htmlspecialchars($thesis['tenDeTai']) ?></td>
                                <td><?= htmlspecialchars($thesis['tenGV'] ?? '---') ?></td>
                                
                                <td class="col-status" style="color: #2563eb; font-weight: bold;">
                                    <?= isset($thesis['diemGiuaKy']) ? htmlspecialchars($thesis['diemGiuaKy']) . '%' : '-' ?>
                                </td>
                                
                                <td class="col-status">
                                    <?php 
                                        $status = $thesis['trangThaiGiuaKy'];
                                        if ($status == 'Được làm tiếp') echo '<span class="status-ok">Được làm tiếp</span>';
                                        elseif ($status == 'Đình chỉ') echo '<span class="status-bad">Đình chỉ</span>';
                                        else echo '-';
                                    ?>
                                </td>
                                
                                <td><?= htmlspecialchars($thesis['nhanXetGiuaKy'] ?? '') ?></td>
                                
                                <td class="col-action">
                                    <div style="display: flex; gap: 5px; justify-content: center;">
                                        <button type="button" class="midterm-btn button" style="padding: 4px 8px; font-size: 11px; background: #e0f2fe; color: #0284c7; border: 1px solid #bae6fd;"
                                            data-madetai="<?= $thesis['maDeTai'] ?>"
                                            data-diemgk="<?= $thesis['diemGiuaKy'] ?? '' ?>"
                                            data-trangthai="<?= $thesis['trangThaiGiuaKy'] ?? '' ?>"
                                            data-ghichu="<?= htmlspecialchars($thesis['nhanXetGiuaKy'] ?? '') ?>"
                                            title="Đánh giá Giữa kỳ">
                                            <i class="fa-solid fa-pen-to-square"></i>
                                        </button>
                                        <form action="../backend/actions.php" method="post" onsubmit="return confirm('Xóa nhóm này?');" style="margin: 0;">
                                            <input type="hidden" name="action" value="delete_detai">
                                            <input type="hidden" name="maDeTai" value="<?= $thesis['maDeTai'] ?>">
                                            <button type="submit" class="button danger" style="padding: 4px 8px; font-size: 11px; height: 28px;" title="Xóa">
                                                <i class="fa-solid fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php $nhomCounter++; ?>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </main>
        </div>
    </div>

<div id="add-modal" class="modal-overlay" style="display: none;">
        <div class="modal-content">
            <h2>Tạo Nhóm & Phân công GV</h2>
            <form action="../backend/actions.php" method="post">
                <input type="hidden" name="action" value="add_detai">
                
                <input type="hidden" name="maMH" value="TBA">
                <input type="hidden" name="tenMonHoc" value="Khóa luận tốt nghiệp">
                <input type="hidden" name="tenDeTai" value="Chưa có tên"> 

                <div class="form-group">
                    <label style="color: #2563eb; font-weight: bold;">1. Chọn Giảng viên Hướng dẫn</label>
                    <select name="maGV_HD" required>
                        <option value="">-- Chọn giảng viên --</option>
                        <?php foreach($lecturers as $lecturer): ?>
                            <option value="<?= htmlspecialchars($lecturer['maGV']) ?>"><?= htmlspecialchars($lecturer['tenGV']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label style="color: #2563eb; font-weight: bold;">2. Chọn Sinh viên vào nhóm</label>
                    <input type="text" id="student-search-input" placeholder="Tìm tên hoặc MSSV..." style="margin-bottom: 5px;">
                    <select id="student-select-list" name="mssv_list[]" multiple size="8" style="height: 150px; width: 100%; padding: 5px; border: 1px solid #ccc;">
                        <?php foreach($students_no_group as $student): ?>
                            <option value="<?= htmlspecialchars($student['mssv']) ?>">
                                <?= htmlspecialchars($student['hoTen']) ?> (<?= htmlspecialchars($student['mssv']) ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <p style="font-size: 11px; color: #64748b; margin-top: 5px;">* Giữ phím Ctrl (Windows) hoặc Command (Mac) để chọn nhiều sinh viên.</p>
                </div>

                <div class="modal-actions">
                    <button type="button" class="cancel-btn button">Hủy</button>
                    <button type="submit" class="button primary">Tạo nhóm & Phân công</button>
                </div>
            </form>
        </div>
    </div>

    <div id="midterm-modal" class="modal-overlay" style="display: none;">
        <div class="modal-content">
            <h2>Đánh giá kết quả giữa kỳ</h2>
            <form action="../backend/actions.php" method="post">
                <input type="hidden" name="action" value="update_midterm">
                <input type="hidden" id="midterm_madetai" name="maDeTai">
                
                <div class="form-group">
                    <label>Tiến độ (0-100%)</label>
                    <input type="number" id="midterm_diem" name="diemGiuaKy" min="0" max="100" step="1" required>
                </div>
                
                <div class="form-group">
                    <label>Kết quả đánh giá</label>
                    <select id="midterm_trangthai" name="trangThaiGiuaKy" required>
                        <option value="Được làm tiếp">Được làm tiếp</option>
                        <option value="Đình chỉ">Đình chỉ</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Ghi chú / Nhận xét</label>
                    <input type="text" id="midterm_ghichu" name="nhanXetGiuaKy">
                </div>
                
                <div class="modal-actions">
                    <button type="button" class="cancel-btn button">Hủy</button>
                    <button type="submit" class="button primary">Cập nhật</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        const addModal = document.getElementById('add-modal');
        const midtermModal = document.getElementById('midterm-modal');
        const btnAddGroup = document.getElementById('add-group-btn');
        const searchInput = document.getElementById('student-search-input');

        function openModal(modal) {
            if(modal) {
                modal.style.display = 'flex';
                setTimeout(() => modal.classList.add('active'), 10);
            }
        }

        function closeModal() {
            [addModal, midtermModal].forEach(m => {
                if(m) {
                    m.classList.remove('active');
                    setTimeout(() => m.style.display = 'none', 300);
                }
            });
        }

        if(btnAddGroup) btnAddGroup.addEventListener('click', () => openModal(addModal));

        document.querySelectorAll('.midterm-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.getElementById('midterm_madetai').value = btn.dataset.madetai;
                document.getElementById('midterm_diem').value = btn.dataset.diemgk;
                document.getElementById('midterm_ghichu').value = btn.dataset.ghichu;
                
                if (btn.dataset.trangthai) {
                    document.getElementById('midterm_trangthai').value = btn.dataset.trangthai;
                }
                openModal(midtermModal);
            });
        });

        document.querySelectorAll('.cancel-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                closeModal();
            });
        });

        window.addEventListener('click', (e) => {
            if (e.target == addModal || e.target == midtermModal) closeModal();
        });

        if(searchInput) {
            searchInput.addEventListener('input', function() {
                let filter = this.value.toLowerCase().trim();
                let options = document.getElementById('student-select-list').getElementsByTagName('option');
                for (let i = 0; i < options.length; i++) {
                    let text = options[i].textContent || options[i].innerText;
                    options[i].style.display = text.toLowerCase().indexOf(filter) > -1 ? "" : "none";
                }
            });
        }
    </script>
</body>
</html>