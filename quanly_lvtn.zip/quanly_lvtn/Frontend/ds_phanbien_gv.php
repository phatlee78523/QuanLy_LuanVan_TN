<?php
session_start();
if (!isset($_SESSION["dangnhap"]) || $_SESSION["dangnhap"] !== true) {
    header("location: dangnhap.html");
    exit;
}
require '../backend/db.php';

$maGV = $_SESSION['maGV'] ?? '';
$isAdmin = (isset($_SESSION['role']) && $_SESSION['role'] == 'admin');

if ($isAdmin) {
    $sql = "
        SELECT 
            dt.maDeTai, dt.tenDeTai, dt.maMH,
            gv_hd.tenGV AS tenGV_HD,
            gv_pb.tenGV AS tenGV_PB,
            (SELECT GROUP_CONCAT(sv.hoTen SEPARATOR '<br>') FROM SinhVien sv WHERE sv.maDeTai = dt.maDeTai) AS thanhVien,
            (SELECT GROUP_CONCAT(sv.mssv SEPARATOR '<br>') FROM SinhVien sv WHERE sv.maDeTai = dt.maDeTai) AS mssv_list,
            (SELECT GROUP_CONCAT(sv.lop SEPARATOR '<br>') FROM SinhVien sv WHERE sv.maDeTai = dt.maDeTai) AS lop_list
        FROM DeTai dt
        LEFT JOIN GiangVien gv_hd ON dt.maGV_HD = gv_hd.maGV
        LEFT JOIN GiangVien gv_pb ON dt.maGV_PB = gv_pb.maGV
        WHERE dt.maGV_PB IS NOT NULL
        ORDER BY gv_pb.tenGV ASC, dt.tenDeTai ASC
    ";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
} else {
    $sql = "
        SELECT 
            dt.maDeTai, dt.tenDeTai, dt.maMH,
            gv_hd.tenGV AS tenGV_HD,
            (SELECT GROUP_CONCAT(sv.hoTen SEPARATOR '<br>') FROM SinhVien sv WHERE sv.maDeTai = dt.maDeTai) AS thanhVien,
            (SELECT GROUP_CONCAT(sv.mssv SEPARATOR '<br>') FROM SinhVien sv WHERE sv.maDeTai = dt.maDeTai) AS mssv_list,
            (SELECT GROUP_CONCAT(sv.lop SEPARATOR '<br>') FROM SinhVien sv WHERE sv.maDeTai = dt.maDeTai) AS lop_list
        FROM DeTai dt
        LEFT JOIN GiangVien gv_hd ON dt.maGV_HD = gv_hd.maGV
        WHERE dt.maGV_PB = ? 
        ORDER BY dt.tenDeTai ASC
    ";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$maGV]);
}

$review_projects = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Danh sách Phản biện</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="icon" type="image/png" href="../images/STU.webp" />
    <link rel="stylesheet" href="../style/style.css">
    <link rel="stylesheet" href="../style/ds_sinhvien_gv.css">
</head>
<body>
    <div class="app-layout">
        
        <aside class="sidebar">
            <div class="sidebar-header"><img src="../images/Logo_STU.png" alt="Logo STU" class="sidebar-logo"></div>
            <nav class="sidebar-nav">
                
                <a href="index.php" class="nav-item <?php echo (basename($_SERVER['PHP_SELF']) == 'index.php') ? 'active' : ''; ?>">
                    <i class="fa-solid fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>                
                <?php if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin'): ?>
                    
                    <?php
                        $isSV = (basename($_SERVER['PHP_SELF']) == 'sinhvien.php' 
                                    || basename($_SERVER['PHP_SELF']) == 'chuadangky.php'
                                    || basename($_SERVER['PHP_SELF']) == 'phancong.php');
                    ?>
                    <div class="nav-item-dropdown">
                        <button type="button" class="nav-item-toggle <?php echo $isSV ? 'active' : ''; ?>">
                            <span><i class="fa-solid fa-users"></i><span>Quản lý Sinh viên</span></span>
                            <span class="arrow">&#9662;</span>
                        </button>
                        <div class="nav-submenu" <?php echo $isSV ? 'style="display: block;"' : 'style="display: none;"'; ?>>
                            <a href="sinhvien.php" class="nav-sub-item <?php echo (basename($_SERVER['PHP_SELF']) == 'sinhvien.php') ? 'active' : ''; ?>">Danh sách sinh viên</a>
                            <a href="phancong.php" class="nav-sub-item <?php echo (basename($_SERVER['PHP_SELF']) == 'phancong.php') ? 'active' : ''; ?>">Phân công sinh viên</a>
                            <a href="chuadangky.php" class="nav-sub-item <?php echo (basename($_SERVER['PHP_SELF']) == 'chuadangky.php') ? 'active' : ''; ?>">Sinh viên chưa đăng ký</a>
                        </div>
                    </div>

                    <?php
                        $isGV = (basename($_SERVER['PHP_SELF']) == 'giangvien.php'
                                        || basename($_SERVER['PHP_SELF']) == 'phancong_pb.php'); 
                    ?>
                    <div class="nav-item-dropdown">
                        <button type="button" class="nav-item-toggle <?php echo $isGV ? 'active' : ''; ?>">
                            <span><i class="fa-solid fa-chalkboard-teacher"></i><span>Quản lý Giảng viên</span></span>
                            <span class="arrow">&#9662;</span>
                        </button>
                        <div class="nav-submenu" <?php echo $isGV ? 'style="display: block;"' : 'style="display: none;"'; ?>>
                            <a href="giangvien.php" class="nav-sub-item <?php echo (basename($_SERVER['PHP_SELF']) == 'giangvien.php') ? 'active' : ''; ?>">Danh sách Giảng viên</a>
                            <a href="phancong_pb.php" class="nav-sub-item <?php echo (basename($_SERVER['PHP_SELF']) == 'phancong_pb.php') ? 'active' : ''; ?>">Phân công Phản biện</a>
                        </div>
                    </div>

                    <a href="hoidong.php" class="nav-item <?php echo (basename($_SERVER['PHP_SELF']) == 'hoidong.php') ? 'active' : ''; ?>">
                        <i class="fa-solid fa-landmark"></i>
                        <span>Hội đồng LVTN</span>
                    </a>

                <?php else: ?>
                    <a href="ds_sinhvien_gv.php" class="nav-item <?php echo (basename($_SERVER['PHP_SELF']) == 'ds_sinhvien_gv.php') ? 'active' : ''; ?>">
                        <i class="fa-solid fa-users"></i>
                        <span>Sinh viên Hướng dẫn</span>
                    </a>

                    <a href="ds_phanbien_gv.php" class="nav-item <?php echo (basename($_SERVER['PHP_SELF']) == 'ds_phanbien_gv.php') ? 'active' : ''; ?>">
                        <i class="fa-solid fa-gavel"></i>
                        <span>Danh sách Phản biện</span>
                    </a>

                    <?php
                        $isNhapLieu = (basename($_SERVER['PHP_SELF']) == 'chamdiem.php'
                                    || basename($_SERVER['PHP_SELF']) == 'nhaplieu_sv.php'
                                    || basename($_SERVER['PHP_SELF']) == 'chamdiem_pb.php'); 
                    ?>
                    <div class="nav-item-dropdown">
                        <button type="button" class="nav-item-toggle <?php echo $isNhapLieu ? 'active' : ''; ?>">
                            <span><i class="fa-solid fa-file-pen"></i><span>Nhập Liệu</span></span>
                            <span class="arrow">&#9662;</span>
                        </button>
                        <div class="nav-submenu" <?php echo $isNhapLieu ? 'style="display: block;"' : 'style="display: none;"'; ?>>
                            <a href="nhaplieu_sv.php" class="nav-sub-item <?php echo (basename($_SERVER['PHP_SELF']) == 'nhaplieu_sv.php') ? 'active' : ''; ?>">Tạo Phiếu Giao Đề Tài</a>
                            <a href="chamdiem.php" class="nav-sub-item <?php echo (basename($_SERVER['PHP_SELF']) == 'chamdiem.php') ? 'active' : ''; ?>">GVHD Chấm Điểm</a>
                            <a href="chamdiem_pb.php" class="nav-sub-item <?php echo (basename($_SERVER['PHP_SELF']) == 'chamdiem_pb.php') ? 'active' : ''; ?>">GVPB Chấm Điểm</a>
                        </div>
                    </div>
                <?php endif; ?>
                
            </nav>
        </aside>

        <div class="main-content-wrapper">
            <header class="header">
                <h1>Hệ thống Quản lý Luận văn Tốt nghiệp</h1>
                <div class="user-actions">
                    <span>Chào, <strong><?= $_SESSION["username"]; ?></strong></span>
                    
                    <a href="hoso.php" class="button" style="background-color: #64748b; color: white;">
                        <i class="fa-solid fa-user"></i> Hồ sơ
                    </a>
                    <a href="../backend/dangxuat.php" class="button danger">
                        <i class="fa-solid fa-door-open"></i> Đăng xuất
                    </a>
                </div>
            </header>

            <main class="content">
                <h2>Danh sách Đề tài Phản biện</h2>
                <?php if ($isAdmin): ?>
                    <p>Danh sách <strong>TẤT CẢ</strong> đề tài đã được phân công phản biện.</p>
                <?php else: ?>
                    <p>Danh sách các đề tài bạn được phân công phản biện.</p>
                <?php endif; ?>

                <div class="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th class="col-code">STT</th>
                                <th class="col-code">MSSV</th>
                                <th class="col-wrap">Họ và Tên</th>
                                <th class="col-code">Lớp</th>
                                <th class="col-wrap">Tên Đề tài</th>
                                <th class="col-code">Mã MH</th>
                                <th class="col-wrap">GV Hướng dẫn</th>
                                <?php if ($isAdmin): ?><th class="col-wrap">GV Phản biện</th><?php endif; ?>
                                <th class="col-action">Hành động</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($review_projects) > 0): 
                                $stt = 1;
                                foreach ($review_projects as $project): ?>
                                <tr>
                                    <td style="text-align: center;"><?= $stt++ ?></td>
                                    
                                    <td><?= $project['mssv_list'] ?></td>
                                    <td><?= $project['thanhVien'] ?></td>
                                    <td><?= $project['lop_list'] ?></td>
                                    
                                    <td><b><?= htmlspecialchars($project['tenDeTai']) ?></b></td>
                                    <td><?= htmlspecialchars($project['maMH']) ?></td>
                                    <td><?= htmlspecialchars($project['tenGV_HD']) ?></td>
                                    
                                    <?php if ($isAdmin): ?>
                                        <td style="color: #1677ff; font-weight: bold;">
                                            <?= htmlspecialchars($project['tenGV_PB']) ?>
                                        </td>
                                    <?php endif; ?>
                                    <td class="col-action">
                                        <button class="button primary grade-btn" 
                                            data-madetai="<?= $project['maDeTai'] ?>"
                                            data-tendetai="<?= htmlspecialchars($project['tenDeTai']) ?>">
                                            <i class="fa-solid fa-pen-to-square"></i> Chấm điểm
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="<?= $isAdmin ? 9 : 8 ?>" style="text-align: center; padding: 20px;">
                                        Chưa có đề tài nào được phân công phản biện.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </main>
        </div>
    </div>

    <div id="pb-modal" class="modal-overlay hidden">
        <div class="modal-content" style="width: 700px;">
            <h2 id="modal-title">Chấm điểm Phản biện</h2>
            <form action="../backend/export_word_gvpb.php" method="post" target="_blank">
                <input type="hidden" id="pb_madetai" name="maDeTai">
                
                <div class="student-divider">
                    <h4>Sinh viên 1</h4>
                    <div class="grade-grid">
                         <div class="form-group"> <label>1. Phân tích (Max 2)</label> <input type="number" name="diemPhanTich1_PB" class="grade-input-1-pb" min="0" max="2" step="0.1" required> </div>
                         <div class="form-group"> <label>2. Thiết kế (Max 2)</label> <input type="number" name="diemThietKe1_PB" class="grade-input-1-pb" min="0" max="2" step="0.1" required> </div>
                         <div class="form-group"> <label>3. Hiện thực (Max 3)</label> <input type="number" name="diemHienThuc1_PB" class="grade-input-1-pb" min="0" max="3" step="0.1" required> </div>
                         <div class="form-group"> <label>4. Báo cáo (Max 3)</label> <input type="number" name="diemBaoCao1_PB" class="grade-input-1-pb" min="0" max="3" step="0.1" required> </div>
                    </div>
                    <div class="grade-grid">
                         <div class="form-group"> <label>Tổng (%)</label> <input type="text" id="diemTongCong1_PB" name="diemTongCong1_PB" readonly style="background: #eee;"> </div>
                         <div class="form-group"> <label>Điểm (10)</label> <input type="number" id="diemFinal1_PB" name="diemFinal1_PB" readonly> </div>
                    </div>
                </div>
                <div class="student-divider">
                    <h4>Sinh viên 2 (Nếu có)</h4>
                    <div class="grade-grid">
                         <div class="form-group"> <label>1. Phân tích (Max 2)</label> <input type="number" name="diemPhanTich2_PB" class="grade-input-2-pb" min="0" max="2" step="0.1"> </div>
                         <div class="form-group"> <label>2. Thiết kế (Max 2)</label> <input type="number" name="diemThietKe2_PB" class="grade-input-2-pb" min="0" max="2" step="0.1"> </div>
                         <div class="form-group"> <label>3. Hiện thực (Max 3)</label> <input type="number" name="diemHienThuc2_PB" class="grade-input-2-pb" min="0" max="3" step="0.1"> </div>
                         <div class="form-group"> <label>4. Báo cáo (Max 3)</label> <input type="number" name="diemBaoCao2_PB" class="grade-input-2-pb" min="0" max="3" step="0.1"> </div>
                    </div>
                    <div class="grade-grid">
                         <div class="form-group"> <label>Tổng (%)</label> <input type="text" id="diemTongCong2_PB" name="diemTongCong2_PB" readonly style="background: #eee;"> </div>
                         <div class="form-group"> <label>Điểm (10)</label> <input type="number" id="diemFinal2_PB" name="diemFinal2_PB" readonly> </div>
                    </div>
                </div>
                
                <hr>
                <div class="form-group"><label>Nhận xét tổng quát</label><textarea name="nxTongQuat_PB" rows="2" style="width: 100%;"></textarea></div>
                <div class="form-group"><label>Các câu hỏi</label><textarea name="cauHoi_PB" rows="2" style="width: 100%;"></textarea></div>
                <div class="form-group radio-group">
                    <label>Đề nghị:</label>
                    <label><input type="radio" name="deNghi_PB" value="duoc" checked> Được bảo vệ</label>
                    <label><input type="radio" name="deNghi_PB" value="khong"> Không</label>
                    <label><input type="radio" name="deNghi_PB" value="bosung"> Bổ sung</label>
                </div>

                <div class="modal-actions">
                    <button type="button" class="cancel-btn">Đóng</button>
                    <button type="submit" class="primary">Xuất Phiếu</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        document.querySelectorAll('.nav-item-toggle').forEach(button => {
            button.addEventListener('click', (e) => {
                e.preventDefault(); 
                const submenu = button.nextElementSibling;
                const isVisible = submenu.style.display === 'block';
                submenu.style.display = isVisible ? 'none' : 'block';
            });
        });
        const pbModal = document.getElementById('pb-modal');
        const modalTitle = document.getElementById('modal-title');

        document.querySelectorAll('.grade-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                let maDeTai = btn.dataset.madetai;
                let tenDeTai = btn.dataset.tendetai;
                document.getElementById('pb_madetai').value = maDeTai;
                modalTitle.innerText = "Chấm điểm: " + tenDeTai;
                pbModal.classList.remove('hidden');
            });
        });

        document.querySelectorAll('.cancel-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                pbModal.classList.add('hidden');
            });
        });
        const inputs1 = document.querySelectorAll('.grade-input-1-pb');
        const total1 = document.getElementById('diemTongCong1_PB');
        const final1 = document.getElementById('diemFinal1_PB');
        
        function calc1() {
            let sum = 0;
            inputs1.forEach(i => sum += parseFloat(i.value) || 0);
            final1.value = sum.toFixed(1);
            total1.value = (sum * 10).toFixed(0) + '%';
        }
        inputs1.forEach(i => i.addEventListener('input', calc1));
        const inputs2 = document.querySelectorAll('.grade-input-2-pb');
        const total2 = document.getElementById('diemTongCong2_PB');
        const final2 = document.getElementById('diemFinal2_PB');
        
        function calc2() {
            let sum = 0;
            inputs2.forEach(i => sum += parseFloat(i.value) || 0);
            final2.value = sum.toFixed(1);
            total2.value = (sum * 10).toFixed(0) + '%';
        }
        inputs2.forEach(i => i.addEventListener('input', calc2));
    </script>
</body>
</html>