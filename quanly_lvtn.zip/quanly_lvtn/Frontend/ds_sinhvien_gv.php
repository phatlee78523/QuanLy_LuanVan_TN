<?php
session_start();
if (!isset($_SESSION["dangnhap"]) || $_SESSION["dangnhap"] !== true) {
    header("location: dangnhap.html");
    exit;
}

require '../backend/db.php';

$statusGK = $pdo->query("SELECT trangThaiChamGK FROM CauHinh WHERE id = 1")->fetchColumn();

$currentUser = $_SESSION['username']; 
$sql_find_gv = "SELECT maGV, tenGV FROM GiangVien WHERE maGV = ? OR tenGV = ? OR email = ?";
$stmt_find = $pdo->prepare($sql_find_gv);
$stmt_find->execute([$currentUser, $currentUser, $currentUser]);
$gv_info = $stmt_find->fetch();

if ($gv_info) { $maGV_Current = $gv_info['maGV']; $tenGV_Display = $gv_info['tenGV']; } 
else { $maGV_Current = $currentUser; $tenGV_Display = $currentUser; }

$sql = "SELECT dt.*, (SELECT GROUP_CONCAT(CONCAT(sv.hoTen, ' (', sv.mssv, ')') SEPARATOR '<br>') FROM SinhVien sv WHERE sv.maDeTai = dt.maDeTai) AS thanhVien FROM DeTai dt WHERE dt.maGV_HD = ? OR dt.maGV_PB = ? ORDER BY dt.maDeTai ASC";
$stmt = $pdo->prepare($sql);
$stmt->execute([$maGV_Current, $maGV_Current]);
$assigned_groups = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Chấm điểm Giữa kỳ</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="icon" type="image/png" href="../images/STU.webp" />
    <link rel="stylesheet" href="../style/style.css">
    <link rel="stylesheet" href="../style/ds_sinhvien_gv.css">
</head>
<body>
    <div class="app-layout">
        <div class="main-content-wrapper">
            <main class="content">
                <div style="margin-bottom: 20px;">
                    <h2 style="margin: 0; color: #1e293b;">Quản lý Nhóm & Đề tài</h2>
                    <p style="color: #64748b; margin: 5px 0 0 0;">
                        <?php if($statusGK == 1): ?>
                            <span style="color: #16a34a; font-weight: bold;"><i class="fa-solid fa-lock-open"></i> HỆ THỐNG ĐANG MỞ</span>
                        <?php else: ?>
                            <span style="color: #ef4444; font-weight: bold;"><i class="fa-solid fa-lock"></i> HỆ THỐNG ĐÃ KHÓA</span>
                        <?php endif; ?>
                    </p>
                </div>

                <div class="card-container">
                    <?php foreach ($assigned_groups as $group): ?>
                    <div class="group-card">
                        <div class="group-header">
                            <div style="flex: 1;">
                                <span class="group-badge">NHÓM <?= htmlspecialchars($group['maMH'] ?? '?') ?></span>
                                <div class="topic-title"><?= htmlspecialchars($group['tenDeTai'] ?? 'Chưa nhập đề tài') ?></div>
                            </div>
                            <div style="text-align: right;">
                                <?php if(isset($group['diemGiuaKy']) && $group['diemGiuaKy'] !== ''): ?>
                                    <div style="font-size: 24px; font-weight: 700; color: #2563eb;"><?= $group['diemGiuaKy'] ?>%</div>
                                    
                                    <?php 
                                        $statusText = $group['trangThaiGiuaKy'];
                                        
                                        if (empty($statusText)) {
                                            $statusText = "Được làm tiếp";
                                        }

                                        $badgeClass = 'score-ok'; 
                                        if ($statusText == 'Cảnh cáo') {
                                            $badgeClass = 'score-warning';
                                        } elseif ($statusText == 'Đình chỉ') {
                                            $badgeClass = 'score-fail';
                                        }
                                    ?>
                                    <span class="score-badge <?= $badgeClass ?>"><?= htmlspecialchars($statusText) ?></span>

                                <?php else: ?>
                                    <span style="font-size: 12px; color: #94a3b8;">Chưa chấm</span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="student-list">
                            <strong><i class="fa-solid fa-user-group"></i> Thành viên:</strong><br><?= $group['thanhVien'] ?>
                        </div>
                        
                        <?php if(!empty($group['nhanXetGiuaKy'])): ?>
                            <div style="margin-top:10px; padding:10px; background:#f8fafc; border:1px solid #e2e8f0; border-radius:6px; font-size:13px; color:#475569;">
                                <strong><i class="fa-solid fa-comment-dots"></i> Nhận xét:</strong><br>
                                <?= nl2br(htmlspecialchars($group['nhanXetGiuaKy'])) ?>
                            </div>
                        <?php endif; ?>

                        <div class="actions">
                            <button class="btn-update" 
                                data-id="<?= $group['maDeTai'] ?>" data-ten="<?= htmlspecialchars($group['tenDeTai']) ?>" data-nhom="<?= htmlspecialchars($group['maMH'] ?? '') ?>">
                                <i class="fa-solid fa-pen-to-square"></i> Sửa Đề tài
                            </button>
                            
                            <?php if($statusGK == 1): ?>
                                <button class="btn-grade"
                                    data-id="<?= $group['maDeTai'] ?>" 
                                    data-diem="<?= $group['diemGiuaKy'] ?? '' ?>" 
                                    
                                    /* Gán trạng thái vào đây để Javascript đọc */
                                    data-trangthai="<?= !empty($group['trangThaiGiuaKy']) ? $group['trangThaiGiuaKy'] : 'Được làm tiếp' ?>" 
                                    
                                    data-nhanxet="<?= htmlspecialchars($group['nhanXetGiuaKy'] ?? '') ?>">
                                    <i class="fa-solid fa-star"></i> Chấm điểm GK
                                </button>
                            <?php else: ?>
                                <button class="btn-grade btn-disabled" disabled><i class="fa-solid fa-lock"></i> Đã khóa</button>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </main>
        </div>
    </div>

    <div id="topic-modal" class="modal-overlay">
        <div class="modal-content">
            <h2>Cập nhật Đề tài</h2>
            <form action="../backend/actions.php" method="post">
                <input type="hidden" name="action" value="update_topic_name_gv">
                <input type="hidden" id="modal_madetai" name="maDeTai">
                <div class="form-group"><label>Nhóm số</label><input type="text" id="modal_nhom" name="nhom" required></div>
                <div class="form-group"><label>Tên Đề tài</label><input type="text" id="modal_tendetai" name="tenDeTai" required></div>
                <div style="text-align: right;"><button type="button" onclick="document.getElementById('topic-modal').classList.remove('active')">Hủy</button> <button type="submit" class="btn-save">Lưu</button></div>
            </form>
        </div>
    </div>

    <div id="grade-modal" class="modal-overlay">
        <div class="modal-content">
            <h2>Chấm điểm Giữa kỳ</h2>
            <form action="../backend/actions.php" method="post">
                <input type="hidden" name="action" value="update_midterm">
                <input type="hidden" name="redirect_url" value="../frontend/ds_sinhvien_gv.php">
                <input type="hidden" id="grade_madetai" name="maDeTai">
                
                <div class="form-group">
                    <label>Tiến độ (0-100%)</label>
                    <input type="number" id="grade_diem" name="diemGiuaKy" min="0" max="100" required placeholder="Nhập %">
                </div>
                
                <div class="form-group">
                    <label>Kết luận</label>
                    <select id="grade_trangthai" name="trangThaiGiuaKy">
                        <option value="Được làm tiếp">Được làm tiếp</option>
                        <option value="Cảnh cáo" style="color:#c2410c; font-weight:bold;">Cảnh cáo</option>
                        <option value="Đình chỉ" style="color:red; font-weight:bold;">Đình chỉ</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Nhận xét chung</label>
                    <textarea id="grade_nhanxet" name="nhanXetGiuaKy" rows="3" placeholder="Nhập nhận xét (nếu có)..."></textarea>
                </div>

                <div style="text-align: right;">
                    <button type="button" onclick="document.getElementById('grade-modal').classList.remove('active')">Hủy</button> 
                    <button type="submit" class="btn-save">Lưu điểm</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        const topicModal = document.getElementById('topic-modal');
        const gradeModal = document.getElementById('grade-modal');

        document.querySelectorAll('.btn-update').forEach(btn => {
            btn.addEventListener('click', () => {
                document.getElementById('modal_madetai').value = btn.dataset.id;
                document.getElementById('modal_nhom').value = btn.dataset.nhom;
                document.getElementById('modal_tendetai').value = (btn.dataset.ten === 'Chưa có tên') ? '' : btn.dataset.ten;
                topicModal.classList.add('active');
            });
        });

        document.querySelectorAll('.btn-grade:not(.btn-disabled)').forEach(btn => {
            btn.addEventListener('click', () => {
                document.getElementById('grade_madetai').value = btn.dataset.id;
                document.getElementById('grade_diem').value = btn.dataset.diem;
                
                const trangThai = btn.dataset.trangthai;
                document.getElementById('grade_trangthai').value = trangThai;
                
                document.getElementById('grade_nhanxet').value = btn.dataset.nhanxet;
                gradeModal.classList.add('active');
            });
        });
    </script>
</body>
</html>