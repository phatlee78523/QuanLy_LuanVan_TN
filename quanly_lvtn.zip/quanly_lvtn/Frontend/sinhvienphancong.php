<?php
session_start();
if (!isset($_SESSION["dangnhap"]) || $_SESSION["dangnhap"] !== true) {
    header("location: dangnhap.html");
    exit;
}

require '../backend/db.php';

$currentUser = $_SESSION['username']; 
$sql_find_gv = "SELECT maGV, tenGV FROM GiangVien WHERE maGV = ? OR tenGV = ? OR email = ?";
$stmt_find = $pdo->prepare($sql_find_gv);
$stmt_find->execute([$currentUser, $currentUser, $currentUser]);
$gv_info = $stmt_find->fetch();

if ($gv_info) {
    $maGV_Current = $gv_info['maGV'];
    $tenGV_Display = $gv_info['tenGV'];
} else {
    $maGV_Current = $currentUser;
    $tenGV_Display = $currentUser;
}

$sql = "
    SELECT 
        dt.maDeTai, dt.tenDeTai, dt.maMH, dt.tenMonHoc,
        (SELECT GROUP_CONCAT(CONCAT(sv.hoTen, ' (', sv.mssv, ')') SEPARATOR '<br>') 
         FROM SinhVien sv WHERE sv.maDeTai = dt.maDeTai) AS thanhVien
    FROM DeTai dt
    WHERE dt.maGV_HD = ? OR dt.maGV_PB = ? 
    ORDER BY dt.maDeTai ASC
";
$stmt = $pdo->prepare($sql);
$stmt->execute([$maGV_Current, $maGV_Current]);
$assigned_groups = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Cập nhật Đề tài</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="icon" type="image/png" href="../images/STU.webp" />
    <link rel="stylesheet" href="../style/style.css">
    <link rel="stylesheet" href="../style/sinhvienphancong.css">
</head>
<body>
    <div class="app-layout">
        <div class="main-content-wrapper">
            <main class="content">
                <div style="margin-bottom: 20px;">
                    <h2 style="margin: 0; color: #1e293b;">Cập nhật Đề tài</h2>
                    <p style="color: #64748b; font-size: 13px;">Vui lòng nhập tên đề tài cho các nhóm sinh viên.</p>
                </div>

                <div class="card-container">
                    <?php foreach ($assigned_groups as $group): ?>
                    <div class="group-card">
                        <div class="group-header">
                            <div style="flex: 1;">
                                <span class="group-badge">NHÓM <?= htmlspecialchars($group['maMH'] ?? '?') ?></span>
                                <div class="topic-title">
                                    <?php if(empty($group['tenDeTai']) || $group['tenDeTai'] == 'Chưa có tên'): ?>
                                        <div class="topic-empty"><i class="fa-solid fa-circle-exclamation"></i> <span>Chưa nhập tên đề tài</span></div>
                                    <?php else: ?>
                                        <i class="fa-solid fa-book" style="color: #2563eb;"></i> <?= htmlspecialchars($group['tenDeTai']) ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="student-list">
                            <strong style="color: #1e293b; display:block; margin-bottom:5px;"><i class="fa-solid fa-user-group"></i> Thành viên:</strong>
                            <?= $group['thanhVien'] ?>
                        </div>

                        <div class="actions">
                            <button class="btn-update" 
                                data-id="<?= $group['maDeTai'] ?>"
                                data-ten="<?= htmlspecialchars($group['tenDeTai']) ?>"
                                data-nhom="<?= ($group['maMH'] == 'TBA') ? '' : htmlspecialchars($group['maMH']) ?>">
                                <i class="fa-solid fa-pen-to-square"></i> Cập nhật Đề tài
                            </button>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </main>
        </div>
    </div>

    <div id="topic-modal" class="modal-overlay">
        <div class="modal-content">
            <h2>Cập nhật thông tin</h2>
            <form action="../backend/actions.php" method="post">
                <input type="hidden" name="action" value="update_topic_name_gv">
                <input type="hidden" name="redirect_url" value="../frontend/sinhvienphancong.php">
                <input type="hidden" id="modal_madetai" name="maDeTai">
                
                <div class="form-group">
                    <label>Nhóm số</label>
                    <input type="text" id="modal_nhom" name="nhom" required>
                </div>

                <div style="background: #f8fafc; padding: 10px; border-radius: 6px; margin-bottom: 15px;">
                    <div class="form-group" style="margin-bottom: 5px;">
                        <label style="font-size: 11px; color: #64748b;">Mã Môn</label>
                        <input type="text" value="CS03153" readonly style="background: #e2e8f0; font-weight: bold; color: #475569;">
                    </div>
                    <div class="form-group" style="margin-bottom: 0;">
                        <label style="font-size: 11px; color: #64748b;">Môn Học</label>
                        <input type="text" value="Đồ án / Khóa luận tốt nghiệp" readonly style="background: #e2e8f0; font-weight: bold; color: #475569;">
                    </div>
                </div>

                <div class="form-group">
                    <label>Tên Đề tài</label>
                    <input type="text" id="modal_tendetai" name="tenDeTai" required placeholder="Nhập tên đề tài...">
                </div>

                <div style="text-align: right; margin-top: 25px;">
                    <button type="button" onclick="document.getElementById('topic-modal').classList.remove('active')" style="padding: 8px 15px; border: 1px solid #ccc; background: white; border-radius: 5px; cursor: pointer;">Hủy</button>
                    <button type="submit" class="btn-save">Lưu thay đổi</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        const modal = document.getElementById('topic-modal');
        document.querySelectorAll('.btn-update').forEach(btn => {
            btn.addEventListener('click', () => {
                document.getElementById('modal_madetai').value = btn.dataset.id;
                document.getElementById('modal_nhom').value = btn.dataset.nhom; 
                let tenDT = btn.dataset.ten;
                if (tenDT === 'Chưa có tên') tenDT = '';
                document.getElementById('modal_tendetai').value = tenDT;
                modal.classList.add('active');
            });
        });
        window.onclick = function(event) { if (event.target == modal) modal.classList.remove('active'); }
    </script>
</body>
</html>